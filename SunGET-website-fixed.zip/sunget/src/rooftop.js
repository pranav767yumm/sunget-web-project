// =========================================
// SERVICE PAGE SCRIPT (src/rooftop.js)
// - Tabs (used on every service page and the careers page)
// - Estimator forms never submit / reload the page
// - Rooftop "What size do I need?" estimator
// =========================================

// ---------- Tabs ----------
(function () {
  "use strict";
  var tabs = Array.prototype.slice.call(document.querySelectorAll(".rt-tab"));
  if (!tabs.length) return;

  function activate(tab) {
    // only switch the tabs that belong to the same tab list
    var list = tab.closest('[role="tablist"]');
    tabs.forEach(function (t) {
      if (t.closest('[role="tablist"]') !== list) return;
      var on = t === tab;
      t.classList.toggle("active", on);
      t.setAttribute("aria-selected", String(on));
      t.tabIndex = on ? 0 : -1;
      var panel = document.getElementById(t.getAttribute("aria-controls"));
      if (panel) {
        panel.classList.toggle("active", on);
        panel.hidden = !on;
      }
    });
  }

  tabs.forEach(function (tab) {
    tab.setAttribute("type", "button");
    tab.addEventListener("click", function () { activate(tab); });
    // Arrow-key navigation for accessibility
    tab.addEventListener("keydown", function (e) {
      var group = tabs.filter(function (t) { return t.closest('[role="tablist"]') === tab.closest('[role="tablist"]'); });
      var i = group.indexOf(tab), next = null;
      if (e.key === "ArrowRight") next = group[(i + 1) % group.length];
      if (e.key === "ArrowLeft") next = group[(i - 1 + group.length) % group.length];
      if (e.key === "Home") next = group[0];
      if (e.key === "End") next = group[group.length - 1];
      if (next) {
        e.preventDefault();
        next.focus();
        activate(next);
      }
    });
  });
})();

// ---------- Estimators are calculators, not forms: pressing Enter must not reload the page ----------
(function () {
  "use strict";
  Array.prototype.forEach.call(document.querySelectorAll("form.rt-est"), function (f) {
    f.addEventListener("submit", function (e) { e.preventDefault(); });
  });
})();

// ---------- Quick size estimator (solar-rooftop.html) ----------
(function () {
  "use strict";
  var bill = document.getElementById("rtBill");
  var range = document.getElementById("rtBillRange");
  if (!bill || !range) return;

  var TARIFF = 9;          // ₹ per unit (approx.)
  var UNITS_PER_KW = 120;  // units generated per kW per month (approx., Pune)
  var SQFT_PER_KW = 100;   // shadow-free roof area per kW

  var out = {
    kw: document.getElementById("rtKw"),
    area: document.getElementById("rtArea"),
    units: document.getElementById("rtUnits"),
    sub: document.getElementById("rtSub")
  };

  // PM Surya Ghar (residential): ₹30,000 per kW for the first 2 kW,
  // ₹18,000 for the 3rd kW, maximum ₹78,000. Pro-rata for part kW
  // (e.g. 1.5 kW = ₹45,000). Previously 1.5 kW was rounded down to 1 kW.
  function subsidy(kw) {
    if (kw <= 0) return 0;
    var s = Math.min(kw, 2) * 30000 + Math.max(0, Math.min(kw, 3) - 2) * 18000;
    return Math.min(Math.round(s), 78000);
  }

  function inr(n) {
    return "₹" + Math.round(n).toLocaleString("en-IN");
  }

  function update(value) {
    var amount = Math.max(0, Number(value) || 0);
    var unitsUsed = amount / TARIFF;
    // Round up to the nearest 0.5 kW, minimum 1 kW
    var kw = Math.max(1, Math.ceil((unitsUsed / UNITS_PER_KW) * 2) / 2);

    out.kw.textContent = kw + " kW";
    out.area.textContent = Math.round(kw * SQFT_PER_KW) + " sq ft";
    out.units.textContent = Math.round(kw * UNITS_PER_KW).toLocaleString("en-IN");
    // Subsidy applies to home systems up to 10 kW
    out.sub.textContent = kw <= 10 ? inr(subsidy(kw)) : "Commercial";
  }

  bill.addEventListener("input", function () {
    range.value = bill.value;
    update(bill.value);
  });
  range.addEventListener("input", function () {
    bill.value = range.value;
    update(range.value);
  });

  update(bill.value);
})();
