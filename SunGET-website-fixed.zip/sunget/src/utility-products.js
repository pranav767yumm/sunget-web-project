/* =========================================================
   utility-products.js — pgs/solar-utility-products.html only
   Product catalogue (utility_products, utility_categories,
   utility_product_images) and enquiries (utility_product_enquiries).

   Changes from the old inline script:
   - uses the shared src/sg-config.js and plain fetch() against the
     Supabase REST API, instead of loading the whole supabase-js SDK from
     an unpinned CDN URL (@supabase/supabase-js@2 — any future 2.x release
     would have been executed on the site without review)
   - image URLs from the database must be http(s) or relative
   - the detail view no longer shows a broken <img src=""> for products
     without photos
   - enquiry form validates the phone number in JS, shows errors, and
     announces success with the shared "sunget:lead-sent" event so the
     marketing pop-ups stop
   - Escape / close return keyboard focus to the button that opened the dialog
   - the page's own copy of the mobile-menu code was removed (script.js
     already handles the menu; running both toggled it twice)
   ========================================================= */
(function () {
  "use strict";

  var CFG = window.SG_CONFIG || {};
  var URL = CFG.SUPABASE_URL, KEY = CFG.SUPABASE_ANON_KEY;
  var hasConfig = /^https:\/\//.test(URL || "") && !!KEY;

  var products = [], categories = [], activeCategory = "all", lastFocus = null;

  function $(id) { return document.getElementById(id); }
  if (!$("upGrid")) return;

  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (ch) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
    });
  }
  function arr(v) {
    if (Array.isArray(v)) return v;
    return typeof v === "string" ? v.split("\n").map(function (x) { return x.trim(); }).filter(Boolean) : [];
  }
  function listHTML(v) { return arr(v).map(function (x) { return "<li>" + esc(x) + "</li>"; }).join(""); }
  function safeImg(u) {
    u = String(u || "").trim();
    if (/^https?:\/\//i.test(u)) return u;
    if (!u || /^[a-z][a-z0-9+.-]*:/i.test(u) || u.indexOf("//") === 0) return "";
    return u.charAt(0) === "/" ? ".." + u : u; // site-relative → works from /pgs/
  }
  function catName(p) {
    var c = categories.filter(function (c) { return String(c.id) === String(p.category_id); })[0];
    return (c && c.name) || "Solar Utility Product";
  }
  function headers(extra) {
    var h = { apikey: KEY, Authorization: "Bearer " + KEY };
    for (var k in extra) h[k] = extra[k];
    return h;
  }
  function get(path) {
    return fetch(URL + "/rest/v1/" + path, { headers: headers({}) }).then(function (r) {
      if (!r.ok) throw new Error(path.split("?")[0] + " " + r.status);
      return r.json();
    });
  }

  /* ---------- overlays ---------- */
  function openOverlay(id) {
    if (!document.querySelector(".up-overlay.open")) lastFocus = document.activeElement;
    Array.prototype.forEach.call(document.querySelectorAll(".up-overlay.open"), function (x) { x.classList.remove("open"); });
    var o = $(id);
    o.classList.add("open");
    document.body.classList.add("up-lock");
    var f = o.querySelector(".up-close");
    if (f) f.focus();
  }
  function closeOverlays() {
    var open = document.querySelectorAll(".up-overlay.open");
    if (!open.length) return;
    Array.prototype.forEach.call(open, function (x) { x.classList.remove("open"); });
    document.body.classList.remove("up-lock");
    if (lastFocus && document.contains(lastFocus) && lastFocus.focus) lastFocus.focus({ preventScroll: true });
    lastFocus = null;
  }

  document.addEventListener("keydown", function (e) {
    var o = document.querySelector(".up-overlay.open");
    if (!o) return;
    if (e.key === "Escape") { e.stopPropagation(); closeOverlays(); return; }
    if (e.key === "Tab") { // keep focus inside the open dialog
      var f = Array.prototype.filter.call(
        o.querySelectorAll("button, input:not([type=hidden]), textarea, select, a[href]"),
        function (el) { return !el.disabled && el.offsetParent !== null && el.tabIndex !== -1; }
      );
      if (!f.length) return;
      var first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });

  /* ---------- load ---------- */
  function showError(message) {
    $("upCount").textContent = "Products unavailable";
    $("upGrid").innerHTML = '<div class="up-error">' + esc(message) +
      ' You can still <a href="#" data-contact="">send us an enquiry</a> or call <a href="tel:+919881855770">+91 98818 55770</a>.</div>';
  }

  function loadProducts() {
    if (!hasConfig || !window.fetch) { showError("Products could not be loaded right now."); return; }
    Promise.all([
      get("utility_products?select=*&is_published=eq.true&order=sort_order.asc"),
      get("utility_categories?select=*&is_active=eq.true&order=sort_order.asc"),
      get("utility_product_images?select=*&order=sort_order.asc")
    ]).then(function (res) {
      categories = res[1] || [];
      var images = res[2] || [];
      products = (res[0] || []).map(function (p) {
        p.images = images.filter(function (i) { return i.product_id === p.id && safeImg(i.image_url); });
        return p;
      });
      renderCategories();
      renderProducts();
    }).catch(function () {
      showError("Products could not be loaded right now.");
    });
  }

  function renderCategories() {
    var all = [{ id: "all", name: "All Products" }].concat(categories);
    $("upCategories").innerHTML = all.map(function (c) {
      var on = String(activeCategory) === String(c.id);
      return '<button type="button" class="up-cat' + (on ? " active" : "") + '" aria-pressed="' + on + '" data-category="' + esc(c.id) + '">' + esc(c.name) + "</button>";
    }).join("");
  }

  function productImage(p) {
    return (p.images && p.images[0] && safeImg(p.images[0].image_url)) || safeImg(p.image_url);
  }

  function filteredProducts() {
    var q = $("upSearch").value.trim().toLowerCase();
    return products.filter(function (p) {
      return (activeCategory === "all" || String(p.category_id) === String(activeCategory)) &&
        (!q || [p.name, p.short_description, p.description].join(" ").toLowerCase().indexOf(q) !== -1);
    });
  }

  function renderProducts() {
    var rows = filteredProducts();
    $("upCount").textContent = "Showing " + rows.length + " of " + products.length + " products";
    if (!rows.length) {
      $("upGrid").innerHTML = '<div class="up-empty">' + (products.length ? "No products found. Please try another search or category." : "Products will be listed here soon. Ask us about what you need.") + "</div>";
      return;
    }
    $("upGrid").innerHTML = rows.map(function (p) {
      var img = productImage(p);
      return '<article class="up-card"><button class="up-photo" type="button" data-details="' + esc(p.id) + '" aria-label="View ' + esc(p.name) + '">' +
        (img ? '<img src="' + esc(img) + '" alt="' + esc(p.name) + '" loading="lazy">' : '<span class="up-photo-fallback" aria-hidden="true">☀</span>') +
        '</button><div class="up-card-content"><span class="up-tag">' + esc(catName(p)) + "</span><h2>" + esc(p.name) + "</h2><p>" +
        esc(p.short_description || p.description || "") + '</p><div class="up-card-actions">' +
        '<button class="up-btn up-secondary" type="button" data-details="' + esc(p.id) + '">View Details</button>' +
        '<button class="up-btn up-primary" type="button" data-contact="' + esc(p.id) + '">Enquire</button></div></div></article>';
    }).join("");
  }

  /* ---------- details ---------- */
  function specRowsOf(p) {
    var s = p.specifications || {};
    if (typeof s === "string") { try { s = JSON.parse(s); } catch (e) { s = {}; } }
    if (Array.isArray(s)) return s.map(function (x) { return Array.isArray(x) ? x : [x && x.label, x && x.value]; });
    return Object.keys(s).map(function (k) { return [k, s[k]]; });
  }

  function tabHTML(p, tab) {
    var html = "";
    if (tab === "features") html = listHTML(p.features) ? '<ul class="up-list">' + listHTML(p.features) + "</ul>" : "";
    if (tab === "applications") html = listHTML(p.applications) ? '<ul class="up-list">' + listHTML(p.applications) + "</ul>" : "";
    if (tab === "specs") {
      var rows = specRowsOf(p);
      html = rows.length ? '<table class="up-specs">' + rows.map(function (r) {
        return "<tr><td>" + esc(r[0]) + "</td><td>" + esc(r[1]) + "</td></tr>";
      }).join("") + "</table>" : "";
    }
    return html || "Details will be updated soon.";
  }

  function openDetails(id) {
    var p = products.filter(function (x) { return String(x.id) === String(id); })[0];
    if (!p) return;
    var images = p.images && p.images.length ? p.images : (safeImg(p.image_url) ? [{ image_url: p.image_url, alt_text: p.name }] : []);
    var main = images[0] ? safeImg(images[0].image_url) : "";
    var hl = listHTML(p.highlights);

    $("upDetailContent").innerHTML =
      '<div class="up-detail-grid"><div>' +
      (main ? '<img class="up-detail-image" id="upMainImage" src="' + esc(main) + '" alt="' + esc(p.name) + '">' : '<div class="up-detail-noimg" aria-hidden="true">☀</div>') +
      (images.length > 1 ? '<div class="up-thumbs">' + images.map(function (im, i) {
        return '<button type="button" class="' + (i === 0 ? "active" : "") + '" data-image-index="' + i + '" aria-label="Show photo ' + (i + 1) + '"><img src="' + esc(safeImg(im.image_url)) + '" alt=""></button>';
      }).join("") + "</div>" : "") +
      '</div><div><span class="up-tag">' + esc(catName(p)) + '</span><h2 id="upDetailTitle">' + esc(p.name) + "</h2><p>" + esc(p.description || p.short_description || "") + "</p>" +
      (hl ? '<h3>Key highlights</h3><ul class="up-list">' + hl + "</ul>" : "") +
      '<button class="up-btn up-primary" type="button" data-contact="' + esc(p.id) + '">Enquire About This Product →</button></div></div>' +
      '<div class="up-tabs" role="tablist" aria-label="Product information">' +
      '<button type="button" class="up-tab active" role="tab" aria-selected="true" data-tab="features">Features</button>' +
      '<button type="button" class="up-tab" role="tab" aria-selected="false" data-tab="specs">Specifications</button>' +
      '<button type="button" class="up-tab" role="tab" aria-selected="false" data-tab="applications">Applications</button></div>' +
      '<div class="up-tab-panel" id="upTabPanel" role="tabpanel">' + tabHTML(p, "features") + "</div>";

    var box = $("upDetailContent");
    Array.prototype.forEach.call(box.querySelectorAll("[data-image-index]"), function (b) {
      b.addEventListener("click", function () {
        var im = images[Number(b.getAttribute("data-image-index"))];
        if ($("upMainImage") && im) $("upMainImage").src = safeImg(im.image_url);
        Array.prototype.forEach.call(box.querySelectorAll("[data-image-index]"), function (x) { x.classList.toggle("active", x === b); });
      });
    });
    Array.prototype.forEach.call(box.querySelectorAll("[data-tab]"), function (b) {
      b.addEventListener("click", function () {
        Array.prototype.forEach.call(box.querySelectorAll("[data-tab]"), function (x) {
          x.classList.toggle("active", x === b);
          x.setAttribute("aria-selected", x === b ? "true" : "false");
        });
        $("upTabPanel").innerHTML = tabHTML(p, b.getAttribute("data-tab"));
      });
    });
    openOverlay("upDetailOverlay");
  }

  /* ---------- enquiry ---------- */
  function setMsg(text, cls) {
    var m = $("upFormMsg");
    m.textContent = text;
    m.className = "up-form-msg " + (cls || "");
  }

  function openContact(id) {
    var p = products.filter(function (x) { return String(x.id) === String(id); })[0];
    var form = $("upEnquiryForm");
    form.reset();
    $("upProductId").value = (p && p.id) || "";
    $("upProductName").value = (p && p.name) || "General Product Enquiry";
    $("upFormProduct").textContent = p ? "Enquiry for: " + p.name : "Tell us what solar utility product or solution you need.";
    setMsg("");
    var btn = $("upSubmit");
    btn.disabled = false;
    btn.textContent = "Submit Enquiry";
    openOverlay("upContactOverlay");
    setTimeout(function () { $("upName").focus(); }, 30);
  }

  document.addEventListener("click", function (e) {
    if (e.target.closest("[data-close]") || e.target.classList.contains("up-overlay")) { closeOverlays(); return; }
    var d = e.target.closest("[data-details]");
    if (d) { openDetails(d.getAttribute("data-details")); return; }
    var c = e.target.closest("[data-contact]");
    if (c) { e.preventDefault(); openContact(c.getAttribute("data-contact") || ""); }
  });

  $("upCategories").addEventListener("click", function (e) {
    var b = e.target.closest("[data-category]");
    if (!b) return;
    activeCategory = b.getAttribute("data-category");
    renderCategories();
    renderProducts();
  });
  $("upSearch").addEventListener("input", renderProducts);

  $("upEnquiryForm").addEventListener("submit", function (e) {
    e.preventDefault();
    var form = e.currentTarget, f = form.elements;
    if (f.website.value) return; // honeypot

    var name = f.name.value.trim();
    var phone = f.phone.value.replace(/[\s()-]/g, "");
    var email = f.email.value.trim();
    if (name.length < 2) { f.name.focus(); return setMsg("Please enter your name.", "err"); }
    if (/^\+?91/.test(phone) && phone.replace(/^\+?91/, "").length === 10) phone = phone.replace(/^\+?91/, "");
    if (!/^\+?\d{10,15}$/.test(phone)) { f.phone.focus(); return setMsg("Please enter a valid 10-digit mobile number.", "err"); }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) { f.email.focus(); return setMsg("Please enter a valid email address.", "err"); }
    if (!hasConfig) return setMsg("We could not submit your enquiry. Please call +91 98818 55770.", "err");

    var btn = $("upSubmit");
    btn.disabled = true;
    btn.textContent = "Submitting…";
    setMsg("");

    var payload = {
      product_id: $("upProductId").value || null,
      product_name: $("upProductName").value,
      name: name,
      phone: phone,
      email: email || null,
      message: f.message.value.trim() || null,
      status: "new",
      source: "utility-products-page"
    };

    fetch(URL + "/rest/v1/utility_product_enquiries", {
      method: "POST",
      headers: headers({ "Content-Type": "application/json", Prefer: "return=minimal" }),
      body: JSON.stringify(payload)
    }).then(function (r) {
      if (!r.ok) throw new Error("save " + r.status);
      form.reset();
      setMsg("Thank you! Your enquiry has been submitted successfully.", "ok");
      btn.textContent = "Submitted ✓";
      try { document.dispatchEvent(new CustomEvent("sunget:lead-sent", { detail: { source: "utility-products" } })); } catch (er) { /* old browsers */ }
      setTimeout(closeOverlays, 2200);
    }).catch(function () {
      setMsg("We could not submit your enquiry. Please try again or call +91 98818 55770.", "err");
      btn.disabled = false;
      btn.textContent = "Submit Enquiry";
    });
  });

  loadProducts();
})();
