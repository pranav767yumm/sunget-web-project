// =========================================================
// ABOUT PAGE DATA  (src/team-data.js)
// Everything on pgs/about_us.html that is a list lives here:
// hero slides, culture photos, timeline, team, values, certificates.
//
// PHOTOS: save team photos in  images/team/  (portrait 800x1000,
// WebP or JPG) and set  photo: "images/team/your-file.webp"
// Leave photo: "" to show the placeholder silhouette.
//
// LINKEDIN: put the person's real profile URL, or "" to hide the icon.
//
// category must match one of the ids in `categories` below,
// otherwise the person only appears under "All team members".
//
// demo: true shows a yellow "Demo content" bar at the top of the page.
// =========================================================
window.ABOUT_DATA = {
  demo: false,

  // ---------- Hero image carousel ----------
  hero: [
    { img: "images/our-team-images/presentation.webp", caption: "Rooftop installations across Maharashtra" },
    { img: "images/our-team-images/understanding.webp", caption: "Engineering that is built to last" },
    { img: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1400&q=75", caption: "Skilled crews on every site" },
    { img: "https://images.unsplash.com/photo-1497440001374-f26997328c1b?auto=format&fit=crop&w=1400&q=75", caption: "Clean energy for homes and businesses" }
  ],

  // ---------- Culture photo grid (7 tiles) ----------
  culture: [
    { label: "Team collaboration", img: "images/our-team-images/understanding.webp" },
    { label: "Creative brainstorming", img: "images/our-team-images/guide.webp" },
    { label: "Learning and development", img: "images/our-team-images/meeting.webp" },
    { label: "Office environment", img: "images/our-team-images/meet.webp" },
    { label: "Team celebrations", img: "images/our-team-images/image.jpg" },
    { label: "Team activities", img: "images/our-team-images/presentation2.webp" },
    { label: "Company events", img: "images/our-team-images/presentation.webp" }
  ],

  // ---------- Timeline (sample years, edit freely) ----------
  timeline: [
    { year: "2015", title: "The Beginning", text: "SunGET starts with a small team and a clear goal: make solar simple and dependable for Pune.", img: "https://images.unsplash.com/photo-1509391366360-2e959784a276?auto=format&fit=crop&w=800&q=70" },
    { year: "2017", title: "Building Our Foundation", text: "First large projects delivered, and a standard process for survey, design and installation is set.", img: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=800&q=70" },
    { year: "2019", title: "Growing Our Team", text: "Engineers, project managers and service technicians join, and work expands across Maharashtra.", img: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=800&q=70" },
    { year: "2021", title: "Expanding Our Services", text: "Solar water heating, heat pumps and maintenance contracts join the rooftop offering.", img: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=800&q=70" },
    { year: "2023", title: "New Opportunities", text: "Turnkey EPC for factories and institutions, with energy audits to size every plant precisely.", img: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=70" },
    { year: "2025", title: "Building Bigger Things", text: "Larger plants, CSR drives and awareness programmes that bring clean energy to more communities.", img: "https://images.unsplash.com/photo-1466611653911-95081537e5b7?auto=format&fit=crop&w=800&q=70" },
    { year: "2026", title: "Moving Forward", text: "A growing team, a stronger service network and the same promise: power that pays you back.", img: "https://images.unsplash.com/photo-1497440001374-f26997328c1b?auto=format&fit=crop&w=800&q=70" }
  ],

  // ---------- Team ----------
  categories: [
    { id: "all", label: "All team members" },
    { id: "leadership", label: "Leadership & Mentors" },
    { id: "engineering", label: "Engineering & Projects" },
    { id: "sales", label: "Sales & Customer Care" },
    { id: "operations", label: "Operations & O&M" }
  ],

  team: [
    { name: "Swami Vivekananda", role: "Spiritual Mentor", category: "leadership", photo: "images/team/Swami_Vivekananda.jpg",
      bio: "Our spiritual guide and inspiration, whose teachings on self-reliance and service to humanity shape our mission.",
      skills: [], linkedin: "" },

    { name: "Subhash (Vinayak Deshpande)", role: "Mentor", category: "leadership", photo: "images/team/subhash.jpg",
      bio: "Guides the team with his experience in solar energy, project management and business strategy.",
      skills: ["Planning", "Team leadership"], linkedin: "https://www.linkedin.com/in/subhash-deshpande-19294638/" },

    { name: "Arvind Karandikar", role: "Mentor", category: "leadership", photo: "images/team/karandikar.jpg",
      bio: "Provides strategic guidance and insights on solar technology, market trends and business development.",
      skills: ["Operations", "Process design"], linkedin: "https://www.linkedin.com/in/arvindkarandikar/" },

    { name: "Yogesh Thite", role: "Mentor", category: "engineering", photo: "images/team/thite.jpg",
      bio: "Offers technical expertise in solar system design, structural analysis and PV modelling to ensure optimal performance.",
      skills: ["System design", "Structural review"], linkedin: "https://www.linkedin.com/in/startupconsultantyogeshthite/" },

    { name: "Dipak Kotkar", role: "Founder", category: "leadership", photo: "images/team/sir.jpg",
      bio: "Sets the company direction and keeps every project aligned with SunGET's quality promise.",
      skills: ["Strategy", "Client relations", "Business growth"], linkedin: "https://www.linkedin.com/in/dipakkotkar/" },

    // ----- PLACEHOLDERS: replace with real names and photos -----
    { name: "Team Member 05", role: "Senior Solar Design Engineer", category: "engineering", photo: "",
      bio: "Prepares layouts, electrical drawings and generation estimates for each proposal.",
      skills: ["AutoCAD", "Single line diagrams", "Shadow analysis"], linkedin: "" },

    { name: "Team Member 06", role: "Project Manager", category: "engineering", photo: "",
      bio: "Coordinates crews, deliveries and approvals so projects finish on schedule.",
      skills: ["Scheduling", "Site safety", "Vendor coordination"], linkedin: "" },

    { name: "Team Member 07", role: "Site Supervisor", category: "engineering", photo: "",
      bio: "Checks quality at each stage of installation, testing and commissioning.",
      skills: ["Quality checks", "Testing", "Commissioning"], linkedin: "" },

    { name: "Team Member 08", role: "Head of Sales", category: "sales", photo: "",
      bio: "Guides customers to the right system and a clear, honest proposal.",
      skills: ["Solar consulting", "Proposals", "Financing options"], linkedin: "" },

    { name: "Team Member 09", role: "Solar Consultant", category: "sales", photo: "",
      bio: "Visits homes and businesses, reviews bills and explains subsidy and savings.",
      skills: ["Site surveys", "Subsidy guidance", "Bill analysis"], linkedin: "" },

    { name: "Team Member 10", role: "Customer Care Lead", category: "sales", photo: "",
      bio: "First point of contact for questions, updates and service requests.",
      skills: ["Communication", "Follow-up", "Problem solving"], linkedin: "" },

    { name: "Team Member 11", role: "O&M Manager", category: "operations", photo: "",
      bio: "Runs maintenance contracts, health checks and repairs to keep plants at peak output.",
      skills: ["Preventive maintenance", "Thermal imaging", "String testing"], linkedin: "" },

    { name: "Team Member 12", role: "Approvals & Net-Metering Officer", category: "operations", photo: "",
      bio: "Handles DISCOM applications, inspections and net-metering paperwork for customers.",
      skills: ["DISCOM process", "Documentation", "Net-metering"], linkedin: "" }
  ],

  // ---------- Values ----------
  // icon: one of  people, bulb, spark, shield, eye, star
  values: [
    { icon: "people", title: "Collaboration", text: "Engineers, consultants and crews work as one team, because good solar needs all of them." },
    { icon: "bulb", title: "Innovation", text: "We keep learning new technology and methods, and use what truly helps customers." },
    { icon: "spark", title: "Creativity", text: "Every roof and every site is different, so we design for it instead of copying a template." },
    { icon: "shield", title: "Trust", text: "We do what we say, stand behind our work and stay after the installation is done." },
    { icon: "eye", title: "Transparency", text: "Clear proposals, honest numbers and no hidden costs from the first call onwards." },
    { icon: "star", title: "Excellence", text: "Careful design, quality equipment and safe installation on every project." }
  ],

  // ---------- Certificates & approvals ----------
  certs: [
    { name: "Certificate 1", note: "Add name and year", img: "images/cert/img1.png" },
    { name: "Certificate 2", note: "Add name and year", img: "images/cert/img2.png" },
    { name: "Certificate 3", note: "Add name and year", img: "images/cert/img3.png" },
    { name: "Certificate 4", note: "Add name and year", img: "images/cert/img4.png" }
  ]
};
