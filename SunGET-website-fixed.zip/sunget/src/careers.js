/* =========================================================
   careers.js — careers.html only
   - Loads open roles from Supabase (career_roles)
   - Candidate form  -> career_applications (+ resume upload to "resumes" bucket)
   - Placement form  -> placement_requests
   Needs src/sg-config.js loaded first.
   ========================================================= */
(function () {
  "use strict";

  var CFG = window.SG_CONFIG || {};
  var URL = CFG.SUPABASE_URL;
  var KEY = CFG.SUPABASE_ANON_KEY;
  var MAX = 5 * 1024 * 1024; // 5 MB
  var OK_EXT = ["pdf", "doc", "docx"];
  var CONTACT = "Please email hr@sungetsolarinfra.com or call +91 98818 55770.";

  function esc(t) {
    return String(t == null ? "" : t).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function clean(v) { return String(v || "").trim() || null; }
  function headers(extra) {
    var h = { apikey: KEY, Authorization: "Bearer " + KEY };
    for (var k in extra) h[k] = extra[k];
    return h;
  }

  /* ---------- open a tab from hero buttons / #placement ---------- */
  function openTab(id) { var t = document.getElementById(id); if (t) t.click(); }
  Array.prototype.forEach.call(document.querySelectorAll("[data-open-tab]"), function (a) {
    a.addEventListener("click", function () { openTab(a.getAttribute("data-open-tab")); });
  });
  if (location.hash === "#placement") openTab("t-place");

  /* ---------- open roles ---------- */
  var grid = document.getElementById("rolesGrid");
  var roleSelect = document.querySelector('#careerForm select[name="role"]');

  function gridNote(text) {
    if (grid) grid.innerHTML = '<p class="roles-note">' + esc(text) + "</p>";
  }

  if (grid) {
    if (!URL || !KEY) {
      gridNote('Open roles could not be loaded. You can still apply below under "Other / General application".');
    } else {
      fetch(URL + "/rest/v1/career_roles?select=*&is_open=eq.true&order=sort_order.asc,created_at.desc", { headers: headers({}) })
        .then(function (r) { if (!r.ok) throw new Error("roles " + r.status); return r.json(); })
        .then(function (rows) {
          rows = Array.isArray(rows) ? rows : [];
          if (!rows.length) {
            gridNote('No openings right now. Apply under "Other / General application" and we will keep your profile.');
          } else {
            grid.innerHTML = rows.map(function (r) {
              var reqs = String(r.requirements || "").split("\n").map(function (s) { return s.trim(); }).filter(Boolean);
              return '<article class="rt-seg"><h3>' + esc(r.title) + "</h3>" +
                (r.department ? '<p class="rt-seg-size">' + esc(r.department) + "</p>" : "") +
                (r.summary ? "<p>" + esc(r.summary) + "</p>" : "") +
                (reqs.length ? "<ul>" + reqs.map(function (q) { return "<li>" + esc(q) + "</li>"; }).join("") + "</ul>" : "") +
                "</article>";
            }).join("");
            if (roleSelect) {
              roleSelect.innerHTML = '<option value="">Role you are applying for *</option>' +
                rows.map(function (r) { return '<option value="' + esc(r.title) + '">' + esc(r.title) + "</option>"; }).join("") +
                "<option>Trainee / Intern</option><option>Other / General application</option>";
            }
          }
        })
        .catch(function () {
          // previously the page stayed on "Loading open roles…" forever
          gridNote('Open roles could not be loaded right now. You can still apply below under "Other / General application".');
        });
    }
  }

  /* ---------- forms ---------- */
  function msg(form, text, cls) {
    var m = form.querySelector(".sg-msg");
    if (!m) return;
    m.textContent = text;
    m.className = "full sg-msg " + (cls || "");
  }

  function post(table, row) {
    return fetch(URL + "/rest/v1/" + table, {
      method: "POST",
      headers: headers({ "Content-Type": "application/json", Prefer: "return=minimal" }),
      body: JSON.stringify(row)
    }).then(function (r) { if (!r.ok) throw new Error("save " + r.status); });
  }

  function extOf(file) {
    return (file.name.split(".").pop() || "").toLowerCase().replace(/[^a-z0-9]/g, "");
  }

  function upload(file) {
    var path = Date.now() + "-" + Math.random().toString(36).slice(2, 10) + "." + extOf(file);
    return fetch(URL + "/storage/v1/object/resumes/" + path, {
      method: "POST",
      headers: headers({ "Content-Type": file.type || "application/octet-stream" }),
      body: file
    }).then(function (r) { if (!r.ok) throw new Error("upload " + r.status); return path; });
  }

  function wire(id, table, build) {
    var form = document.getElementById(id);
    if (!form) return;
    var sent = false;

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var f = form.elements;
      if (f.website && f.website.value) return; // honeypot
      if (sent) return msg(form, "Already submitted. Thank you!", "ok");

      for (var i = 0; i < f.length; i++) {
        var el = f[i];
        if (el.required && el.type !== "checkbox" && !String(el.value).trim()) {
          el.focus();
          return msg(form, "Please fill the required fields marked *.", "err");
        }
      }
      var phone = f.phone.value.replace(/[\s()-]/g, "");
      if (!/^\+?\d{10,15}$/.test(phone)) { f.phone.focus(); return msg(form, "Enter a valid phone number (at least 10 digits).", "err"); }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(f.email.value.trim())) { f.email.focus(); return msg(form, "Enter a valid email address.", "err"); }
      if (f.passing_year && f.passing_year.value.trim() && !/^(19|20)\d{2}$/.test(f.passing_year.value.trim())) {
        f.passing_year.focus(); return msg(form, "Enter the year of passing as four digits, e.g. 2025.", "err");
      }
      if (f.consent && !f.consent.checked) { f.consent.focus(); return msg(form, "Please tick the consent box.", "err"); }

      var file = f.resume && f.resume.files && f.resume.files[0];
      if (file) {
        if (OK_EXT.indexOf(extOf(file)) === -1) return msg(form, "Please attach your resume as a PDF or Word file (.pdf, .doc, .docx).", "err");
        if (file.size > MAX) return msg(form, "Resume is larger than 5 MB.", "err");
      }
      if (!URL || !KEY) return msg(form, "Online applications are unavailable right now. " + CONTACT, "err");

      var btn = form.querySelector('button[type="submit"]');
      var label = btn.textContent;
      btn.disabled = true;
      btn.textContent = "Sending...";
      msg(form, "");

      (file ? upload(file) : Promise.resolve(null))
        .then(function (path) { return post(table, build(f, path, phone)); })
        .then(function () {
          sent = true;
          form.reset();
          msg(form, "Thank you! Our HR team will contact you soon.", "ok");
          btn.textContent = "Submitted";
        })
        .catch(function () {
          msg(form, "Sorry, we could not send this. " + CONTACT, "err");
          btn.disabled = false;
          btn.textContent = label;
        });
    });
  }

  wire("careerForm", "career_applications", function (f, path, phone) {
    return {
      name: f.name.value.trim(), phone: phone, email: f.email.value.trim(), city: clean(f.city.value),
      qualification: clean(f.qualification.value), college: clean(f.college.value), passing_year: clean(f.passing_year.value),
      role: clean(f.role.value), experience: clean(f.experience.value), message: clean(f.message.value),
      resume_path: path, status: "new"
    };
  });

  wire("placementForm", "placement_requests", function (f, path, phone) {
    return {
      institution: f.institution.value.trim(), inst_type: clean(f.inst_type.value), contact_name: f.contact_name.value.trim(),
      designation: clean(f.designation.value), phone: phone, email: f.email.value.trim(), city: clean(f.city.value),
      courses: clean(f.courses.value), students: clean(f.students.value), mode: clean(f.mode.value),
      message: clean(f.message.value), status: "new"
    };
  });
})();
