/* =========================================================
   ENQUIRY SAVER  (src/sg-enquiry.js)
   Saves website enquiry forms into the admin panel (Enquiries table).

   Load after sg-config.js. It does not listen to forms by itself:
   src/script.js validates any <form data-sg-enquiry> and then calls
   SungetEnquiry.save(form), which returns a Promise that only
   resolves when Supabase really stored the row.

   Optional form attributes:
     data-sg-type="ESG Enquiry"   forces the enquiry type
   ========================================================= */
(function () {
  "use strict";

  var BILL = {
    less_1500: "Less than Rs 1500",
    "1500_2500": "Rs 1500 - 2500",
    "2500_4000": "Rs 2500 - 4000",
    "4000_8000": "Rs 4000 - 8000",
    more_8000: "More than Rs 8000"
  };
  var PAGE_TYPE = {
    "solar-rooftop": "Rooftop Solar Enquiry",
    "solar-epc": "Solar Installation Enquiry",
    "solar-water-heater": "Solar Water Heater Enquiry",
    "heat-pump": "Heat Pump Enquiry",
    "solar-utility-products": "Solar Utility Products Enquiry",
    "o-and-m-repair": "O&M Service Enquiry",
    "energy-audit": "Energy Audit Enquiry",
    "csr-and-awareness": "CSR Enquiry",
    esg: "ESG Enquiry"
  };

  function cfg() {
    return window.SG_CONFIG || {};
  }

  // Builds the database row from the form fields
  function buildRow(form) {
    var d = {};
    new FormData(form).forEach(function (v, k) {
      if (typeof v === "string" && v.trim()) d[k] = v.trim();
    });
    delete d.terms_agree;
    delete d.website; // honeypot

    var bill = d.bill ? BILL[d.bill] || d.bill : "";
    delete d.bill;

    // The page decides the enquiry type first; the visitor's own words only
    // refine a general rooftop/EPC enquiry into residential / commercial / industrial.
    var page = (location.pathname.split("/").pop() || "index").replace(/\.html?$/i, "") || "index";
    var all = Object.keys(d).map(function (k) { return d[k]; }).join(" ");
    var guess = /industr|factory|warehouse/i.test(all)
      ? "Industrial Solar Enquiry"
      : /commercial|shop|office|business/i.test(all)
        ? "Commercial Solar Enquiry"
        : /residential|home|bungalow|house|society|flat/i.test(all)
          ? "Residential Solar Enquiry"
          : "";
    var type =
      form.getAttribute("data-sg-type") ||
      (page === "solar-rooftop" || page === "solar-epc" ? guess || PAGE_TYPE[page] : PAGE_TYPE[page]) ||
      guess ||
      "General Enquiry";

    function pick(re) {
      for (var k in d) {
        if (re.test(k)) {
          var v = d[k];
          delete d[k];
          return v;
        }
      }
      return "";
    }

    var row = {
      name: pick(/name/i),
      phone: pick(/phone|mobile|whats|tel|number/i),
      email: pick(/mail/i),
      city: pick(/city|location|area|place|pin/i),
      message: pick(/message|msg|comment|detail|query/i),
      requirement: pick(/requirement|capacity|kw|system|load|interest/i),
      enquiry_type: type,
      source: page + " form",
      status: "new"
    };
    if (bill) row.requirement = (row.requirement ? row.requirement + " | " : "") + "Monthly bill: " + bill;
    var rest = Object.keys(d).map(function (k) { return k + ": " + d[k]; }).join(" | ");
    if (rest) row.extra = rest;
    return row;
  }

  // Sends a row to the "enquiries" table. Resolves only on HTTP 2xx.
  function post(row) {
    var c = cfg();
    if (!c.SUPABASE_URL || !c.SUPABASE_ANON_KEY) {
      return Promise.reject(new Error("SG_CONFIG is missing. Load src/sg-config.js first."));
    }
    return fetch(c.SUPABASE_URL + "/rest/v1/enquiries", {
      method: "POST",
      keepalive: true,
      headers: {
        apikey: c.SUPABASE_ANON_KEY,
        Authorization: "Bearer " + c.SUPABASE_ANON_KEY,
        "Content-Type": "application/json",
        Prefer: "return=minimal"
      },
      body: JSON.stringify(row)
    }).then(function (r) {
      if (!r.ok) throw new Error("Enquiry could not be saved (HTTP " + r.status + ")");
    });
  }

  window.SungetEnquiry = {
    buildRow: buildRow,
    post: post,
    save: function (form) {
      return post(buildRow(form));
    }
  };
})();
