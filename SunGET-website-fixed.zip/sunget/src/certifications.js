/* =========================================================
   certifications.js — pgs/certifications.html only
   Lightbox for certificates + press clippings, and the
   "paper swipe stack" for press coverage.
   Moved out of the page's inline script. Changes:
   - certificate previews are <button data-full> handled by one delegated
     listener (no inline onclick; keyboard users can open them)
   - lightbox returns focus to the opener and traps Tab on the close button
   - Escape only acts while the lightbox is open
   ========================================================= */
(function () {
  "use strict";

  /* ---------- Lightbox ---------- */
  var modal = document.getElementById("lightboxModal");
  var modalImg = document.getElementById("lightboxImg");
  var closeBtn = modal ? modal.querySelector(".lightbox-close") : null;
  var lastFocus = null;

  function openLightbox(src, alt) {
    if (!modal || !modalImg || !src) return;
    lastFocus = document.activeElement;
    modalImg.src = src;
    modalImg.alt = alt || "Enlarged view";
    modal.classList.add("active");
    document.body.style.overflow = "hidden";
    if (closeBtn) closeBtn.focus();
  }

  function closeLightbox() {
    if (!modal || !modal.classList.contains("active")) return;
    modal.classList.remove("active");
    document.body.style.overflow = "";
    modalImg.removeAttribute("src");
    if (lastFocus && lastFocus.focus) lastFocus.focus({ preventScroll: true });
  }

  if (modal) {
    modal.addEventListener("click", function (e) {
      if (e.target === modal || e.target.closest(".lightbox-close")) closeLightbox();
    });
  }

  document.addEventListener("keydown", function (e) {
    if (!modal || !modal.classList.contains("active")) return;
    if (e.key === "Escape") { e.stopPropagation(); closeLightbox(); }
    else if (e.key === "Tab") { e.preventDefault(); if (closeBtn) closeBtn.focus(); }
  });

  document.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest(".cert-preview-box[data-full]");
    if (!b) return;
    var img = b.querySelector("img");
    openLightbox(b.getAttribute("data-full"), img ? img.alt : "");
  });

  /* ---------- Paper swipe stack ----------
     Drag the top paper left or right to throw it away.
     Also: arrow buttons, dots, left/right arrow keys.
     Tap / click / Enter on the top paper opens it large. */
  var wrap = document.getElementById("paperStack");
  if (!wrap) return;

  var stage = wrap.querySelector(".ps-stage");
  var els = Array.prototype.slice.call(stage.querySelectorAll(".ps-card"));
  if (!els.length) return;

  var items = els.map(function (el) {
    var img = el.querySelector("img");
    var h = el.querySelector("h3");
    return { src: img.getAttribute("src"), title: h ? h.textContent.trim() : (img.alt || "Article") };
  });

  var dotsBox = wrap.querySelector(".ps-dots");
  dotsBox.innerHTML = items.map(function (it, i) {
    return '<button type="button" data-go="' + i + '" aria-label="Show article ' + (i + 1) + ": " + it.title.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;") + '"></button>';
  }).join("");
  var dots = Array.prototype.slice.call(dotsBox.querySelectorAll("button"));
  var count = wrap.querySelector(".ps-count");

  var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var FLY_MS = reduce ? 120 : 520;
  var order = items.map(function (_, i) { return i; }); // order[0] = paper on top
  var busy = false;

  var PILE = [
    { x: 0, y: 0, r: 0, s: 1, o: 1 },
    { x: 20, y: 14, r: 3.2, s: 0.965, o: 1 },
    { x: -18, y: 26, r: -3.6, s: 0.93, o: 1 },
    { x: 0, y: 36, r: 0, s: 0.9, o: 0 }
  ];

  function setVars(el, p) {
    el.style.setProperty("--tx", p.x + "px");
    el.style.setProperty("--ty", p.y + "px");
    el.style.setProperty("--rot", p.r + "deg");
    el.style.setProperty("--sc", p.s);
    el.style.opacity = p.o;
  }
  function reflow(el) { void el.offsetWidth; }

  function layout() {
    order.forEach(function (idx, pos) {
      var el = els[idx];
      setVars(el, PILE[Math.min(pos, PILE.length - 1)]);
      el.style.zIndex = String(20 - pos);
      var top = pos === 0;
      el.classList.toggle("is-top", top);
      el.classList.toggle("is-hidden", pos > 2);
      el.setAttribute("aria-hidden", top ? "false" : "true");
      if (top) {
        el.setAttribute("tabindex", "0");
        el.setAttribute("role", "button");
        el.setAttribute("aria-label", items[idx].title + ". Press Enter to expand.");
      } else {
        el.removeAttribute("tabindex");
        el.removeAttribute("role");
        el.removeAttribute("aria-label");
      }
    });
    var cur = order[0];
    dots.forEach(function (d, i) { d.classList.toggle("on", i === cur); });
    count.textContent = "Article " + (cur + 1) + " of " + items.length;
  }

  function throwTop(dir, fromX, fromY) {
    if (busy || items.length < 2) return;
    busy = true;
    var el = els[order[0]];
    el.classList.remove("is-drag");
    order.push(order.shift());
    layout();
    el.style.zIndex = "40";
    el.classList.add("is-fly");
    el.classList.remove("is-hidden");
    var w = Math.max(window.innerWidth, 600);
    setVars(el, { x: (fromX || 0) + dir * w * 0.85, y: (fromY || 0) - 30, r: dir * 26, s: 1, o: 0 });
    setTimeout(function () {
      el.classList.add("no-anim");
      el.classList.remove("is-fly");
      layout();
      reflow(el);
      el.classList.remove("no-anim");
      busy = false;
    }, FLY_MS);
  }

  function bringBack(dir) {
    if (busy || items.length < 2) return;
    busy = true;
    var idx = order.pop();
    order.unshift(idx);
    var el = els[idx];
    el.classList.add("no-anim");
    var w = Math.max(window.innerWidth, 600);
    setVars(el, { x: dir * w * 0.85, y: -30, r: dir * 26, s: 1, o: 0 });
    el.style.zIndex = "40";
    reflow(el);
    el.classList.remove("no-anim");
    layout();
    setTimeout(function () { busy = false; }, FLY_MS);
  }

  function goTo(i) {
    if (busy || order[0] === i) return;
    var steps = order.indexOf(i);
    var k;
    if (steps <= items.length / 2) { for (k = 0; k < steps; k++) order.push(order.shift()); }
    else { for (k = 0; k < items.length - steps; k++) order.unshift(order.pop()); }
    layout();
  }

  function openTop() { var it = items[order[0]]; openLightbox(it.src, it.title); }

  var drag = null;

  stage.addEventListener("pointerdown", function (e) {
    if (e.button !== undefined && e.button !== 0) return;
    var el = e.target.closest(".ps-card");
    if (!el || !el.classList.contains("is-top") || busy) return;
    var now = performance.now();
    drag = { el: el, id: e.pointerId, x0: e.clientX, y0: e.clientY, dx: 0, dy: 0, t0: now, moved: false, lastX: e.clientX, lastT: now, vx: 0 };
    try { el.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
  });

  stage.addEventListener("pointermove", function (e) {
    if (!drag || e.pointerId !== drag.id) return;
    drag.dx = e.clientX - drag.x0;
    drag.dy = e.clientY - drag.y0;
    if (!drag.moved && Math.abs(drag.dx) < 6 && Math.abs(drag.dy) < 6) return;
    drag.moved = true;
    var now = performance.now();
    drag.vx = (e.clientX - drag.lastX) / Math.max(1, now - drag.lastT);
    drag.lastX = e.clientX; drag.lastT = now;

    drag.el.classList.add("is-drag");
    setVars(drag.el, { x: drag.dx, y: drag.dy * 0.25, r: drag.dx * 0.055, s: 1, o: 1 });

    var p = Math.min(1, Math.abs(drag.dx) / 180);
    var next = els[order[1]];
    if (next && order.length > 1) {
      setVars(next, { x: PILE[1].x * (1 - p), y: PILE[1].y * (1 - p), r: PILE[1].r * (1 - p), s: PILE[1].s + (1 - PILE[1].s) * p * 0.8, o: 1 });
    }
  });

  function endDrag(e, cancelled) {
    if (!drag || (e && e.pointerId !== drag.id)) return;
    var d = drag; drag = null;
    try { d.el.releasePointerCapture(d.id); } catch (err) { /* ignore */ }
    d.el.classList.remove("is-drag");

    if (!d.moved) {
      if (!cancelled && performance.now() - d.t0 < 600) openTop();
      return;
    }
    var far = Math.abs(d.dx) > 110;
    var fast = Math.abs(d.vx) > 0.6 && Math.abs(d.dx) > 30;
    if (!cancelled && (far || fast)) throwTop(d.dx >= 0 ? 1 : -1, d.dx, d.dy * 0.25);
    else layout();
  }
  stage.addEventListener("pointerup", function (e) { endDrag(e, false); });
  stage.addEventListener("pointercancel", function (e) { endDrag(e, true); });
  stage.addEventListener("dragstart", function (e) { e.preventDefault(); });

  wrap.addEventListener("click", function (e) {
    var b = e.target.closest("button");
    if (!b || !wrap.contains(b)) return;
    if (b.getAttribute("data-act") === "next") throwTop(-1);
    else if (b.getAttribute("data-act") === "prev") bringBack(-1);
    else if (b.hasAttribute("data-go")) goTo(Number(b.getAttribute("data-go")));
  });

  stage.addEventListener("keydown", function (e) {
    if (e.key === "ArrowRight") { e.preventDefault(); throwTop(-1); }
    else if (e.key === "ArrowLeft") { e.preventDefault(); bringBack(-1); }
    else if ((e.key === "Enter" || e.key === " ") && e.target.classList.contains("is-top")) { e.preventDefault(); openTop(); }
  });

  layout();
})();
