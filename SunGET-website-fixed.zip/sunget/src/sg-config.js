/* =========================================================
   SITE CONFIGURATION  (src/sg-config.js)
   Load this FIRST on every page, before any other SunGET script.

   SUPABASE_ANON_KEY is the *publishable* (anon) key. It is designed
   to be used in the browser and is safe to publish, but ONLY if Row
   Level Security (RLS) is switched on for every table and storage
   bucket. See supabase/schema.sql and README.md.

   NEVER put the service_role / secret key in this file or anywhere
   else in this website.
   ========================================================= */
window.SG_CONFIG = {
  SUPABASE_URL: "https://lsfwdoyqxlblvxlxwmbi.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_CjdM1_XUqYWaPeTxs6AmJA_5qBtSW9u",
  WHATSAPP_NUMBER: "919881855770",
  PHONE_DISPLAY: "+91 98818 55770"
};
