// =========================================================
// SHARED SITE SCRIPT  (src/script.js)
// Loaded on every page. Contains:
//   1. Solar calculator popup (opened by any .open-calc-btn)
//   2. Mobile navigation (hamburger + sub-menus)
//   3. Toast notification + enquiry forms (<form data-sg-enquiry>)
//   4. Home page hero slider + mobile hero form popup
// Every block checks that its elements exist, so the same file is
// safe on pages that do not have them.
// =========================================================

// =========================================
// 1. GLOBAL SOLAR CALCULATOR INJECTION & LOGIC
// =========================================
(function () {
  "use strict";

  var isCalculatorInjected = false;
  var lastFocus = null;

  var CONFIG = {
    whatsappNumber: (window.SG_CONFIG && window.SG_CONFIG.WHATSAPP_NUMBER) || "919881855770",
    gstRate: 0,
    slabs: [
      { maxUnits: 150, kw: 1 },
      { maxUnits: 250, kw: 2 }
    ],
    aboveSlabs: {
      baseKw: 3,
      unitsPerExtraKw: 100
    },
    fixedPrices: {
      1: 120000,
      2: 160000
    },
    pricePerKw: 70000,
    commercialPricePerKw: 55000, // fixed commercial rate (₹ per kW)
    subsidy: {
      1: 30000,
      2: 60000,
      max: 78000
    }
  };

  // Popup modal HTML structure
  var modalHTML = `
  <div class="calc-modal" id="calcModal" role="dialog" aria-modal="true" aria-labelledby="calcTitle" aria-hidden="true">
    <div class="calc-modal-overlay" id="calcModalOverlay"></div>
    <div class="calc-modal-content">
      <button type="button" class="calc-close" id="calcCloseBtn" aria-label="Close calculator">&times;</button>

      <div class="calc-layout">
        <!-- Left Side: Calculator Form -->
        <div class="calc-card">
          <h2 id="calcTitle" style="font-size: 24px; margin-bottom: 8px; color: var(--ink);">Solar Savings Calculator</h2>
          <p style="color: var(--muted); font-size: 14px; margin: 0 0 20px 0; line-height: 1.6;">
            Find the right rooftop solar system size, indicative cost &amp; PM Surya Ghar subsidy for your setup.
          </p>

          <form id="calcForm" class="calc-form" novalidate>
            <span style="display: block; font-weight: 600; margin-bottom: 8px;" id="calcTypeLabel">Connection Category</span>
            <div class="type-selector" id="typeSelector" role="group" aria-labelledby="calcTypeLabel" style="display: flex; gap: 8px; margin-bottom: 16px; background: #f1f6f2; padding: 4px; border-radius: 12px; border: 1px solid var(--line);">
              <button type="button" class="type-btn active" data-type="residential" aria-pressed="true" style="flex: 1; padding: 10px; border: none; background: #ffffff; color: var(--green); border-radius: 8px; font-weight: 700; cursor: pointer; box-shadow: 0 2px 6px rgba(0,0,0,0.06);">Residential</button>
              <button type="button" class="type-btn" data-type="commercial" aria-pressed="false" style="flex: 1; padding: 10px; border: none; background: transparent; color: var(--muted); border-radius: 8px; font-weight: 600; cursor: pointer;">Commercial</button>
            </div>

            <label for="calcMonthlyUnits" style="display: block; font-weight: 600; margin-bottom: 8px;">Monthly electricity units consumed (kWh)</label>
            <input type="number" id="calcMonthlyUnits" inputmode="decimal" min="1" step="1" placeholder="e.g. 200" required style="width: 100%; font-size: 1.1rem; padding: 12px 14px; border: 2px solid var(--line); border-radius: 12px; outline: none;">
            <small style="color: var(--muted); font-size: 12px; margin-top: 4px; display: block;">Find this number on your monthly electricity bill.</small>

            <div id="calcError" role="alert" style="display: none; margin-top: 10px; padding: 10px 12px; border-radius: 10px; background: #fdecea; color: #b3261e; font-size: 0.9rem;"></div>

            <div style="display: flex; gap: 10px; margin-top: 20px;">
              <button type="submit" class="btn full" style="flex: 2; margin: 0;">Calculate Solar Estimate &rarr;</button>
              <button type="button" id="calcResetBtn" class="btn light" style="flex: 1; margin: 0;">Reset</button>
            </div>
          </form>
        </div>

        <!-- Right Side: Dynamic Estimate Results Card -->
        <div class="calc-card" style="padding: 0; border: none; background: transparent;">
          <div class="calc-result-box theme-residential" id="calcResultContainer" aria-live="polite" style="position: relative; overflow: hidden; padding: 24px; border-radius: 18px;">

            <!-- Semi-transparent overlay keeps text legible over the background image -->
            <div style="position: absolute; inset: 0; background: rgba(255, 255, 255, 0.85); backdrop-filter: blur(2px); z-index: 1;"></div>

            <div class="watermark-stamp" aria-hidden="true" style="position: absolute; right: 10px; bottom: 10px; opacity: 0.05; font-size: 28px; font-weight: 900; pointer-events: none; z-index: 2;">SunGET Solar Infra</div>

            <div class="calc-res-head" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; position: relative; z-index: 2;">
              <strong style="color: var(--ink); font-size: 15px;" id="resHeadTitle">Preliminary Estimate</strong>
              <span class="calc-pill" id="resTypePill" style="background: #eaf4ed; color: var(--green); padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 800; text-transform: uppercase;">RESIDENTIAL</span>
            </div>

            <div class="calc-big-val" id="resSystemSize" style="font-size: 36px; font-weight: 800; color: var(--green); line-height: 1.1; position: relative; z-index: 2;">0 kW</div>
            <div class="calc-muted" id="resMutedText" style="color: var(--muted); font-size: 13px; margin-bottom: 18px; position: relative; z-index: 2;">Recommended Solar System Size</div>

            <div class="calc-metrics" style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 18px; position: relative; z-index: 2;">
              <div class="calc-metric" style="background: rgba(255, 255, 255, 0.95); padding: 12px; border-radius: 12px; border: 1px solid var(--line);">
                <small style="display: block; font-size: 11px; color: var(--muted); text-transform: uppercase; font-weight: 700;">Base System Price</small>
                <strong id="resCost" style="font-size: 16px; color: var(--ink);">₹0</strong>
              </div>
              <div class="calc-metric" style="background: rgba(255, 255, 255, 0.95); padding: 12px; border-radius: 12px; border: 1px solid var(--line);">
                <small style="display: block; font-size: 11px; color: var(--muted); text-transform: uppercase; font-weight: 700;">Govt. Subsidy (PM Surya Ghar)</small>
                <strong id="resSubsidy" style="font-size: 16px; color: var(--green);">₹0</strong>
              </div>
            </div>

            <div style="background: rgba(255, 255, 255, 0.95); padding: 16px; border-radius: 14px; border: 1.5px solid var(--green); margin-bottom: 16px; text-align: center; position: relative; z-index: 2;">
              <small style="display: block; font-size: 12px; color: var(--muted); text-transform: uppercase; font-weight: 700;">Effective Net Cost (Approx.)</small>
              <strong id="resFinalPrice" style="font-size: 26px; font-weight: 800; color: var(--green); display: block; margin-top: 2px;">₹0</strong>
            </div>

            <!-- WhatsApp Direct Action Button (enabled after a calculation) -->
            <a id="calcWaBtn" href="#" target="_blank" rel="noopener noreferrer" class="btn" aria-disabled="true" style="background: #25d366; color: #ffffff; width: 100%; text-align: center; display: block; text-decoration: none; font-weight: 700; border-radius: 12px; padding: 14px; box-shadow: 0 4px 12px rgba(37, 211, 102, 0.25); position: relative; z-index: 2;">
              💬 Get Detailed Quote on WhatsApp &rarr;
            </a>

            <p class="calc-note" style="margin-top: 14px; text-align: center; color: var(--muted); font-size: 11px; line-height: 1.4; position: relative; z-index: 2;">
              Indicative estimate. Final quote &amp; subsidy claims are subject to DISCOM site survey &amp; grid feasibility.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
  `;

  function injectCalculatorModal() {
    if (isCalculatorInjected) return;
    document.body.insertAdjacentHTML("beforeend", modalHTML);
    isCalculatorInjected = true;
    initCalculatorLogic();
  }

  function getSystemKw(units) {
    for (var i = 0; i < CONFIG.slabs.length; i++) {
      if (units <= CONFIG.slabs[i].maxUnits) return CONFIG.slabs[i].kw;
    }
    var lastMax = CONFIG.slabs[CONFIG.slabs.length - 1].maxUnits;
    var extra = Math.floor((units - lastMax - 1) / CONFIG.aboveSlabs.unitsPerExtraKw);
    return CONFIG.aboveSlabs.baseKw + extra;
  }

  function getPrice(kw) {
    if (CONFIG.fixedPrices[kw] !== undefined) return CONFIG.fixedPrices[kw];
    return kw * CONFIG.pricePerKw;
  }

  function getSubsidyAmount(kw, category) {
    if (category === "commercial") return 0;
    if (kw === 1) return CONFIG.subsidy[1];
    if (kw === 2) return CONFIG.subsidy[2];
    return CONFIG.subsidy.max;
  }

  function formatINR(n) {
    return "₹" + Math.round(n).toLocaleString("en-IN");
  }

  function initCalculatorLogic() {
    var calcModal = document.getElementById("calcModal");
    var calcModalOverlay = document.getElementById("calcModalOverlay");
    var calcCloseBtn = document.getElementById("calcCloseBtn");
    var calcForm = document.getElementById("calcForm");
    var calcResetBtn = document.getElementById("calcResetBtn");
    var calcMonthlyUnits = document.getElementById("calcMonthlyUnits");
    var calcError = document.getElementById("calcError");
    var resTypePill = document.getElementById("resTypePill");
    var calcResultContainer = document.getElementById("calcResultContainer");
    var typeBtns = document.querySelectorAll("#typeSelector .type-btn");
    var resSystemSize = document.getElementById("resSystemSize");
    var resCost = document.getElementById("resCost");
    var resSubsidy = document.getElementById("resSubsidy");
    var resFinalPrice = document.getElementById("resFinalPrice");

    var selectedCategory = "residential";

    // ---- Commercial calculator (fixed rate per kW) ----
    // Reuses the same form and result cards; only the labels change.
    var RATE = CONFIG.commercialPricePerKw;
    var commercialCalculated = false; // after the first calculation, values follow the input live
    var unitsLabel = calcForm.querySelector('label[for="calcMonthlyUnits"]');
    var unitsHint = calcMonthlyUnits.nextElementSibling;
    var resMutedText = document.getElementById("resMutedText");
    var labelCost = resCost.previousElementSibling;
    var labelFinal = resFinalPrice.previousElementSibling;
    var calcSubmitBtn = calcForm.querySelector('button[type="submit"]');
    var calcWaBtn = document.getElementById("calcWaBtn");

    var RES_TEXT = {
      unitsLabel: unitsLabel.textContent,
      unitsHint: unitsHint.textContent,
      placeholder: calcMonthlyUnits.placeholder,
      muted: resMutedText.textContent,
      labelCost: labelCost.textContent,
      labelFinal: labelFinal.textContent,
      submit: calcSubmitBtn.innerHTML
    };
    var COMM_TEXT = {
      unitsLabel: "Required solar capacity (kW)",
      unitsHint: "Enter the system size you need. The price updates instantly.",
      placeholder: "e.g. 10",
      muted: "Solar Capacity",
      labelCost: "Price Per kW",
      labelFinal: "Estimated Total Investment",
      submit: "Get Estimate &rarr;"
    };

    function setWhatsApp(msg) {
      if (msg) {
        calcWaBtn.href = "https://wa.me/" + CONFIG.whatsappNumber + "?text=" + encodeURIComponent(msg);
        calcWaBtn.removeAttribute("aria-disabled");
      } else {
        calcWaBtn.href = "#";
        calcWaBtn.setAttribute("aria-disabled", "true");
      }
    }

    // Until a calculation is made the WhatsApp button does nothing
    calcWaBtn.addEventListener("click", function (e) {
      if (calcWaBtn.getAttribute("aria-disabled") === "true") {
        e.preventDefault();
        showError(selectedCategory === "commercial"
          ? "Enter the solar capacity first, then press Get Estimate."
          : "Enter your monthly units first, then press Calculate.");
        calcMonthlyUnits.focus();
      }
    });

    function showError(text) {
      calcError.textContent = text;
      calcError.style.display = "block";
    }
    function hideError() {
      calcError.style.display = "none";
    }

    function resetOutputs(commercial) {
      resSystemSize.textContent = "0 kW";
      resCost.textContent = commercial ? formatINR(RATE) : "₹0";
      resSubsidy.textContent = commercial ? "₹0 (N/A)" : "₹0";
      resFinalPrice.textContent = "₹0";
      setWhatsApp(null);
    }

    function setCommercialMode(on) {
      var t = on ? COMM_TEXT : RES_TEXT;
      unitsLabel.textContent = t.unitsLabel;
      unitsHint.textContent = t.unitsHint;
      calcMonthlyUnits.placeholder = t.placeholder;
      calcMonthlyUnits.step = on ? "any" : "1";
      resMutedText.textContent = t.muted;
      labelCost.textContent = t.labelCost;
      labelFinal.textContent = t.labelFinal;
      calcSubmitBtn.innerHTML = t.submit;
      calcMonthlyUnits.value = "";
      hideError();
      commercialCalculated = false;
      resetOutputs(on);
      // swap the result card background theme (styles in style.css)
      calcResultContainer.classList.toggle("theme-residential", !on);
      calcResultContainer.classList.toggle("theme-commercial", on);
    }

    function updateCommercial(showErr) {
      hideError();
      var raw = calcMonthlyUnits.value.trim();
      var kw = Number(raw);

      if (raw === "" || !isFinite(kw) || kw <= 0) {
        resetOutputs(true);
        if (showErr) showError("Please enter a solar capacity greater than 0 kW.");
        return false;
      }

      var total = Math.round(kw * RATE);
      resSystemSize.textContent = kw + " kW";
      resCost.textContent = formatINR(RATE);
      resSubsidy.textContent = "₹0 (N/A)";
      resFinalPrice.textContent = formatINR(total);

      setWhatsApp(
        "Hello SunGET Solar Infra, I generated a commercial solar estimate on your website.\n\n" +
        "• Category: COMMERCIAL\n" +
        "• Solar Capacity: " + kw + " kW\n" +
        "• Price Per kW: " + formatINR(RATE) + "\n" +
        "• Estimated Total Investment: " + formatINR(total) + "\n\n" +
        "Please provide a detailed site feasibility inspection and quote."
      );
      return true;
    }

    function calculateResidential() {
      hideError();
      var raw = calcMonthlyUnits.value.trim();
      var units = Math.round(Number(raw));

      if (raw === "" || !isFinite(units) || units <= 0) {
        showError("Please enter a valid number of units greater than 0.");
        return false;
      }

      var kw = getSystemKw(units);
      var basePrice = getPrice(kw);
      var subsidy = getSubsidyAmount(kw, "residential");
      var gstAmount = Math.round(basePrice * CONFIG.gstRate);
      var netEffectivePrice = Math.max(0, basePrice + gstAmount - subsidy);

      resSystemSize.textContent = kw + " kW";
      resCost.textContent = formatINR(basePrice) + " + GST";
      resSubsidy.textContent = formatINR(subsidy);
      resFinalPrice.textContent = formatINR(netEffectivePrice) + " + GST*";

      setWhatsApp(
        "Hello SunGET Solar Infra, I generated a solar estimate on your website.\n\n" +
        "• Category: RESIDENTIAL\n" +
        "• Monthly Usage: " + units + " kWh/units\n" +
        "• Recommended System: " + kw + " kW\n" +
        "• Base Price: " + formatINR(basePrice) + " + GST\n" +
        "• Govt. Subsidy: " + formatINR(subsidy) + "\n" +
        "• Estimated Net Cost: " + formatINR(netEffectivePrice) + " + GST\n\n" +
        "Please provide a detailed site feasibility inspection and quote."
      );
      return true;
    }

    // After the first commercial calculation, keep the values in sync while typing
    calcMonthlyUnits.addEventListener("input", function () {
      if (selectedCategory === "commercial" && commercialCalculated) updateCommercial(false);
    });

    // Category toggle (Residential / Commercial)
    Array.prototype.forEach.call(typeBtns, function (btn) {
      btn.addEventListener("click", function () {
        Array.prototype.forEach.call(typeBtns, function (b) {
          b.classList.remove("active");
          b.setAttribute("aria-pressed", "false");
          b.style.background = "transparent";
          b.style.color = "var(--muted)";
          b.style.fontWeight = "600";
          b.style.boxShadow = "none";
        });
        btn.classList.add("active");
        btn.setAttribute("aria-pressed", "true");
        btn.style.background = "#ffffff";
        btn.style.color = "var(--green)";
        btn.style.fontWeight = "700";
        btn.style.boxShadow = "0 2px 6px rgba(0,0,0,0.06)";

        selectedCategory = btn.dataset.type;
        resTypePill.textContent = selectedCategory.toUpperCase();
        setCommercialMode(selectedCategory === "commercial");
        calcMonthlyUnits.focus();
      });
    });

    function closeCalculator() {
      calcModal.classList.remove("active");
      calcModal.setAttribute("aria-hidden", "true");
      document.body.style.overflow = "";
      if (lastFocus && typeof lastFocus.focus === "function") lastFocus.focus();
    }
    window.SungetCalc = window.SungetCalc || {};
    window.SungetCalc.close = closeCalculator;

    calcCloseBtn.addEventListener("click", closeCalculator);
    calcModalOverlay.addEventListener("click", closeCalculator);

    // Escape closes, Tab stays inside the dialog
    calcModal.addEventListener("keydown", function (e) {
      if (e.key === "Escape") {
        e.stopPropagation();
        closeCalculator();
        return;
      }
      if (e.key !== "Tab") return;
      var f = Array.prototype.filter.call(
        calcModal.querySelectorAll("button, input, a[href]"),
        function (el) { return el.offsetParent !== null && !el.disabled; }
      );
      if (!f.length) return;
      var first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    });

    calcForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var ok;
      if (selectedCategory === "commercial") {
        commercialCalculated = true;
        ok = updateCommercial(true);
      } else {
        ok = calculateResidential();
      }
      // On phones the results sit below the form, so bring them into view
      if (ok && window.innerWidth <= 900) {
        calcResultContainer.scrollIntoView({ behavior: "smooth", block: "nearest" });
      }
    });

    calcResetBtn.addEventListener("click", function () {
      calcMonthlyUnits.value = "";
      hideError();
      commercialCalculated = false;
      resetOutputs(selectedCategory === "commercial");
      calcMonthlyUnits.focus();
    });
  }

  // Open the calculator from any element with `.open-calc-btn`
  document.addEventListener("click", function (e) {
    var triggerBtn = e.target.closest(".open-calc-btn");
    if (!triggerBtn) return;
    e.preventDefault();

    lastFocus = triggerBtn;
    injectCalculatorModal();

    var calcModal = document.getElementById("calcModal");
    if (calcModal) {
      calcModal.classList.add("active");
      calcModal.setAttribute("aria-hidden", "false");
      document.body.style.overflow = "hidden";
      setTimeout(function () {
        var input = document.getElementById("calcMonthlyUnits");
        if (input) input.focus();
      }, 80);
    }

    // close the mobile menu if the button was inside it
    if (window.SungetNav) window.SungetNav.close();
  });
})();

// =========================================
// 2. MOBILE NAVIGATION
// =========================================
(function () {
  "use strict";

  var menuToggle = document.getElementById("menuToggle");
  var mobileMenu = document.getElementById("mobileMenu");
  if (!menuToggle || !mobileMenu) return;

  function closeMobileMenu() {
    menuToggle.classList.remove("active");
    mobileMenu.classList.remove("active");
    menuToggle.setAttribute("aria-expanded", "false");
    Array.prototype.forEach.call(mobileMenu.querySelectorAll(".mobile-group"), function (g) {
      g.classList.remove("open");
      var sub = g.querySelector(".mobile-sub");
      var btn = g.querySelector(".mobile-sub-toggle");
      if (sub) sub.style.maxHeight = null;
      if (btn) btn.setAttribute("aria-expanded", "false");
    });
  }
  window.SungetNav = { close: closeMobileMenu };

  menuToggle.addEventListener("click", function () {
    var isActive = menuToggle.classList.toggle("active");
    mobileMenu.classList.toggle("active", isActive);
    menuToggle.setAttribute("aria-expanded", String(isActive));
    if (!isActive) closeMobileMenu();
  });

  // Close the menu when a real link is clicked
  Array.prototype.forEach.call(
    mobileMenu.querySelectorAll("a[href]"),
    function (link) { link.addEventListener("click", closeMobileMenu); }
  );

  // Expand / collapse sub-menus. The group heading (when it has no link)
  // and the arrow button both toggle it.
  Array.prototype.forEach.call(mobileMenu.querySelectorAll(".mobile-group"), function (group) {
    var btn = group.querySelector(".mobile-sub-toggle");
    var sub = group.querySelector(".mobile-sub");
    var head = group.querySelector(".mobile-group-head .mobile-link:not([href])");
    if (!btn || !sub) return;

    function toggle() {
      var isOpen = group.classList.toggle("open");
      sub.style.maxHeight = isOpen ? sub.scrollHeight + "px" : null;
      btn.setAttribute("aria-expanded", String(isOpen));
    }
    btn.addEventListener("click", toggle);
    if (head) {
      head.setAttribute("role", "button");
      head.setAttribute("tabindex", "0");
      head.addEventListener("click", toggle);
      head.addEventListener("keydown", function (e) {
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggle(); }
      });
    }
  });

  // Escape closes the menu
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && mobileMenu.classList.contains("active")) {
      closeMobileMenu();
      menuToggle.focus();
    }
  });

  // Returning to desktop width closes the open mobile menu
  window.addEventListener("resize", function () {
    if (window.innerWidth > 900 && mobileMenu.classList.contains("active")) closeMobileMenu();
  });
})();

// =========================================
// 3. TOAST + ENQUIRY FORMS
// =========================================

// Shows the pop-up message at the bottom right. Pass isError = true for a red message.
function showToastNotification(message, isError) {
  var toast = document.getElementById("toast");
  if (!toast) return;
  if (!toast.dataset.defaultText) toast.dataset.defaultText = toast.textContent.trim();
  clearTimeout(showToastNotification._t);
  toast.textContent = message || toast.dataset.defaultText;
  toast.classList.toggle("is-error", !!isError);
  toast.style.display = "block";
  showToastNotification._t = setTimeout(function () {
    toast.style.display = "none";
    toast.classList.remove("is-error");
    toast.textContent = toast.dataset.defaultText;
  }, isError ? 6000 : 4000);
}

// Validates a <form data-sg-enquiry>, saves it with src/sg-enquiry.js and
// shows success only when the database really stored it.
(function () {
  "use strict";

  var PHONE_MSG = "Please enter a valid 10-digit mobile number.";
  var phoneDisplay = (window.SG_CONFIG && window.SG_CONFIG.PHONE_DISPLAY) || "+91 98818 55770";

  // Accepts 10 digits, optionally written as +91 / 91 / 0 followed by 10 digits
  function normalisePhone(v) {
    var d = String(v || "").replace(/\D/g, "");
    if (d.length === 12 && d.indexOf("91") === 0) d = d.slice(2);
    if (d.length === 11 && d.charAt(0) === "0") d = d.slice(1);
    return /^[6-9]\d{9}$/.test(d) ? d : "";
  }

  function fail(form, field, text) {
    if (field) field.focus();
    showToastNotification(text, true);
  }

  function handle(form) {
    form.setAttribute("novalidate", "");
    form.addEventListener("submit", function (e) {
      e.preventDefault();

      // honeypot: bots fill hidden fields, people do not
      if (form.elements.website && form.elements.website.value) return;

      // required fields
      for (var i = 0; i < form.elements.length; i++) {
        var el = form.elements[i];
        if (el.required && el.type !== "checkbox" && !String(el.value).trim()) {
          return fail(form, el, "Please fill in all required fields.");
        }
        if (el.required && el.type === "checkbox" && !el.checked) {
          return fail(form, el, "Please tick the consent box.");
        }
      }
      var phone = form.querySelector('input[type="tel"]');
      if (phone) {
        var clean = normalisePhone(phone.value);
        if (!clean) return fail(form, phone, PHONE_MSG);
        phone.value = clean;
      }
      var email = form.querySelector('input[type="email"]');
      if (email && email.value.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {
        return fail(form, email, "Please enter a valid email address.");
      }

      if (!window.SungetEnquiry) {
        console.error("src/sg-enquiry.js is not loaded on this page.");
        return showToastNotification("Sorry, we could not send your enquiry. Please call " + phoneDisplay + ".", true);
      }

      var btn = form.querySelector('button[type="submit"]');
      var btnText = btn ? btn.textContent : "";
      if (btn) {
        btn.disabled = true;
        btn.textContent = "Sending...";
      }

      window.SungetEnquiry.save(form)
        .then(function () {
          form.reset();
          showToastNotification("Thanks! Your enquiry has been received. Our team will call you shortly.");
          document.dispatchEvent(new CustomEvent("sunget:lead-sent", { detail: { form: form.id } }));
        })
        .catch(function (err) {
          console.error("Enquiry could not be sent:", err);
          showToastNotification("Sorry, we could not send your enquiry. Please call " + phoneDisplay + ".", true);
        })
        .then(function () {
          if (btn) {
            btn.disabled = false;
            btn.textContent = btnText;
          }
        });
    });
  }

  Array.prototype.forEach.call(document.querySelectorAll("form[data-sg-enquiry]"), handle);
})();

// =========================================
// 4. HOME PAGE HERO SLIDER + MOBILE FORM POPUP
// =========================================
(function () {
  "use strict";

  var slides = document.querySelectorAll(".hero-slide");
  var dotsBox = document.getElementById("heroDots");
  var hero = document.querySelector(".hero");
  // Only run on pages that really have the home-page hero slider
  if (!slides.length || !dotsBox || !hero) return;

  var reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var DELAY = 4000;
  var current = 0;
  var timer = null;
  var formOpen = false;

  // build dots
  Array.prototype.forEach.call(slides, function (_, i) {
    var d = document.createElement("button");
    d.type = "button";
    d.className = "hero-dot" + (i === 0 ? " active" : "");
    d.setAttribute("aria-label", "Go to slide " + (i + 1));
    d.addEventListener("click", function () {
      goTo(i);
      restart();
    });
    dotsBox.appendChild(d);
  });
  var dots = dotsBox.querySelectorAll(".hero-dot");

  function goTo(n) {
    slides[current].classList.remove("active");
    dots[current].classList.remove("active");
    current = (n + slides.length) % slides.length;
    slides[current].classList.add("active");
    dots[current].classList.add("active");
  }

  function start() {
    if (reduceMotion || formOpen) return;
    clearInterval(timer);
    timer = setInterval(function () {
      goTo(current + 1);
    }, DELAY);
  }
  function stop() {
    clearInterval(timer);
    timer = null;
  }
  function restart() {
    stop();
    start();
  }

  var nextBtn = document.getElementById("heroNext");
  var prevBtn = document.getElementById("heroPrev");
  if (nextBtn) nextBtn.addEventListener("click", function () { goTo(current + 1); restart(); });
  if (prevBtn) prevBtn.addEventListener("click", function () { goTo(current - 1); restart(); });

  // pause on hover (mouse devices only, so touch screens never get stuck paused)
  if (window.matchMedia("(hover: hover)").matches) {
    hero.addEventListener("mouseenter", stop);
    hero.addEventListener("mouseleave", start);
  }

  // pause when the tab is hidden
  document.addEventListener("visibilitychange", function () {
    if (document.hidden) stop();
    else restart();
  });

  // preload the other slide images so they don't flash blank
  Array.prototype.forEach.call(slides, function (s) {
    var url = s.style.backgroundImage.replace(/^url\(["']?|["']?\)$/g, "");
    if (url) new Image().src = url;
  });

  // ----- Mobile: open / close the enquiry form popup -----
  var formCard = document.getElementById("heroFormCard");
  var backdrop = document.getElementById("heroFormBackdrop");
  var openBtn = document.getElementById("openHeroForm");
  var closeBtn = document.getElementById("closeHeroForm");

  if (formCard && backdrop && openBtn && closeBtn) {
    var openForm = function () {
      formOpen = true;
      formCard.classList.add("open");
      backdrop.classList.add("show");
      hero.classList.add("form-open");
      document.body.style.overflow = "hidden";
      stop();
      var first = formCard.querySelector("input");
      if (first) setTimeout(function () { first.focus(); }, 60);
    };
    var closeForm = function () {
      if (!formOpen) return;
      formOpen = false;
      formCard.classList.remove("open");
      backdrop.classList.remove("show");
      hero.classList.remove("form-open");
      document.body.style.overflow = "";
      start();
      openBtn.focus();
    };
    openBtn.addEventListener("click", openForm);
    closeBtn.addEventListener("click", closeForm);
    backdrop.addEventListener("click", closeForm);
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") closeForm();
    });
    // if the screen is resized back to desktop, reset the popup state
    window.addEventListener("resize", function () {
      if (window.innerWidth > 768) closeForm();
    });
  }

  start();
})();
