/* =========================================================
   gallery.js — pgs/gallery.html only
   1. Loads published photos + categories from Supabase (asynchronously;
      the old page used three *synchronous* XHR calls that froze the page).
   2. If the admin has not imported the built-in photos (page_content
      _gallery/imported flag), the 30 built-in photos are shown after the
      admin photos — the same 30 files the admin "Import" button refers to.
      If Supabase cannot be reached, the built-in photos are shown alone.
   3. Filters, lightbox (keyboard, swipe, focus trap), preloading.
   Needs src/sg-config.js loaded first.
   ========================================================= */
(function () {
  "use strict";

  var CFG = window.SG_CONFIG || {};
  var BUILT_IN_COUNT = 30;

  var CATEGORIES = [
    { id: "all", label: "All photos" },
    { id: "residential", label: "Homes & Bungalows" },
    { id: "society", label: "Housing Societies" },
    { id: "commercial", label: "Commercial & Industrial" },
    { id: "thermal", label: "Water Heating & Heat Pumps" },
    { id: "events", label: "Team, CSR & Events" },
    { id: "project", label: "Projects" }
  ];

  function $(id) { return document.getElementById(id); }
  var grid = $("gGrid");
  if (!grid) return;

  function esc(t) {
    return String(t == null ? "" : t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  /* Photo paths saved by the admin look like "/images/gallery/ (1).jpg".
     A leading "/" only works when the site sits at the domain root, so
     site-relative paths are turned into "../images/..." (this page is in /pgs/).
     Only http(s) and relative paths are allowed. */
  function safeSrc(p) {
    p = String(p || "").trim();
    if (!p) return "";
    if (/^https?:\/\//i.test(p)) return p;
    if (/^[a-z][a-z0-9+.-]*:/i.test(p) || p.indexOf("//") === 0) return ""; // javascript:, data:, protocol-relative
    if (p.charAt(0) === "/") p = ".." + p;
    return p.replace(/ /g, "%20");
  }

  function card(p) {
    var full = safeSrc(p.src);
    var thumb = safeSrc(p.thumb) || full;
    if (!full) return "";
    return '<button type="button" class="g-item" data-cat="' + esc(p.cat || "project") + '" data-full="' + esc(full) + '">' +
      '<img src="' + esc(thumb) + '" alt="' + esc(p.alt || p.title || "SunGET project photo") + '" loading="lazy" decoding="async" />' +
      '<span class="g-zoom" aria-hidden="true">+</span>' +
      '<span class="g-cap"><strong>' + esc(p.title || "SunGET project") + "</strong><em>" + esc(p.description || p.place || "") + "</em></span></button>";
  }

  function builtIn() {
    var rows = [];
    for (var i = 1; i <= BUILT_IN_COUNT; i++) {
      rows.push({ src: "/images/gallery/ (" + i + ").jpg", cat: "project", title: "SunGET project", alt: "SunGET project photo " + i });
    }
    return rows;
  }

  function getJSON(path) {
    return fetch(CFG.SUPABASE_URL + path, { headers: { apikey: CFG.SUPABASE_ANON_KEY } })
      .then(function (r) { if (!r.ok) throw new Error(String(r.status)); return r.json(); });
  }

  function load() {
    if (!CFG.SUPABASE_URL || !CFG.SUPABASE_ANON_KEY || !window.fetch) return Promise.resolve(builtIn());
    var photos = getJSON("/rest/v1/photos?select=*&published=eq.true&order=sort_order.asc,created_at.desc");
    var flag = getJSON("/rest/v1/page_content?page=eq._gallery&key=eq.imported&select=value").catch(function () { return []; });
    var cats = getJSON("/rest/v1/gallery_categories?select=*&order=sort_order.asc").catch(function () { return []; });
    return Promise.all([photos, flag, cats]).then(function (res) {
      var rows = Array.isArray(res[0]) ? res[0] : [];
      var imported = Array.isArray(res[1]) && res[1].length > 0;
      if (Array.isArray(res[2]) && res[2].length) {
        CATEGORIES = [CATEGORIES[0]].concat(res[2].map(function (c) { return { id: c.slug, label: c.name }; }));
      }
      return imported ? rows : rows.concat(builtIn());
    }).catch(function () {
      return builtIn(); // database not ready / offline: built-in photos still show
    });
  }

  $("gStatus").textContent = "Loading photos…";

  load().then(function (rows) {
    grid.insertAdjacentHTML("beforeend", rows.map(card).join(""));
    init();
  });

  function init() {
    var items = Array.prototype.slice.call(grid.querySelectorAll(".g-item"));
    var cat = "all", visible = items.slice();

    items.forEach(function (b, i) {
      b.style.setProperty("--n", Math.min(i, 12));
      var img = b.querySelector("img");
      var cap = b.querySelector(".g-cap strong");
      b.setAttribute("aria-label", "Open photo: " + (cap ? cap.textContent : "project"));
      img.addEventListener("load", function () { b.classList.add("loaded"); });
      img.addEventListener("error", function () { b.classList.add("broken"); img.style.display = "none"; });
      if (img.complete && img.naturalWidth) b.classList.add("loaded");
    });

    /* ---------- filter buttons (shown only when 2+ categories are used) ---------- */
    function count(id) { return items.filter(function (b) { return id === "all" || b.getAttribute("data-cat") === id; }).length; }
    var used = CATEGORIES.filter(function (c) { return c.id !== "all" && count(c.id) > 0; });
    if (used.length > 1) {
      $("gFilters").innerHTML = [CATEGORIES[0]].concat(used).map(function (c) {
        return '<button type="button" class="g-chip" data-cat="' + esc(c.id) + '" aria-pressed="' + (c.id === "all") + '">' + esc(c.label) + " <small>" + count(c.id) + "</small></button>";
      }).join("");
    }

    function applyFilter() {
      visible = [];
      items.forEach(function (b) {
        var ok = cat === "all" || b.getAttribute("data-cat") === cat;
        b.hidden = !ok;
        b.style.display = ok ? "" : "none";
        if (ok) visible.push(b);
      });
      $("gStatus").textContent = visible.length ? visible.length + " photo" + (visible.length === 1 ? "" : "s") : "";
      $("gEmpty").hidden = visible.length > 0;
    }

    $("gFilters").addEventListener("click", function (e) {
      var b = e.target.closest(".g-chip"); if (!b) return;
      cat = b.getAttribute("data-cat");
      Array.prototype.forEach.call($("gFilters").querySelectorAll(".g-chip"), function (x) {
        x.setAttribute("aria-pressed", x === b ? "true" : "false");
      });
      applyFilter();
    });

    grid.addEventListener("click", function (e) {
      var b = e.target.closest(".g-item");
      if (b) openLB(visible.indexOf(b), b);
    });

    /* ---------- lightbox ---------- */
    var lb = $("lb"), lbImg = $("lbImg"), lbSpin = $("lbSpin"), cur = 0, lastFocus = null, isOpen = false;

    function info(b) {
      var img = b.querySelector("img"), t = b.querySelector(".g-cap strong"), pl = b.querySelector(".g-cap em");
      return {
        src: b.getAttribute("data-full") || img.getAttribute("src"),
        thumb: img.currentSrc || img.getAttribute("src"),
        title: t ? t.textContent : "",
        place: pl ? pl.textContent : "",
        cat: b.getAttribute("data-cat")
      };
    }

    /* full-size images: downloaded once, kept in memory and decoded before they are shown */
    var fullCache = {}, token = 0;
    function loadFull(src) {
      if (fullCache[src]) return fullCache[src].p;
      var im = new Image(), rec = { im: im, done: false };
      rec.p = new Promise(function (res) {
        im.decoding = "async";
        im.onload = function () {
          var fin = function () { rec.done = true; res(); };
          if (im.decode) im.decode().then(fin, fin); else fin();
        };
        im.onerror = function () { res(); };
        im.src = src;
      });
      fullCache[src] = rec;
      return rec.p;
    }
    function preload(i) { if (i >= 0 && i < visible.length) loadFull(info(visible[i]).src); }

    function show(i) {
      if (!visible.length) return;
      cur = (i + visible.length) % visible.length;
      var p = info(visible[cur]), t = ++token;
      var ready = fullCache[p.src] && fullCache[p.src].done;

      if (!ready && p.thumb && p.thumb !== p.src) {
        // show the small picture straight away, sharpen when the full one arrives
        lbImg.classList.add("low");
        lbImg.src = p.thumb;
        loadFull(p.src).then(function () {
          if (t !== token || !isOpen) return; // visitor already moved on
          lbImg.src = p.src;
          lbImg.classList.remove("low");
        });
      } else {
        lbImg.classList.remove("low");
        lbImg.src = p.src;
      }
      lbImg.classList.add("on");
      lbSpin.hidden = true;
      lbImg.alt = p.title;

      $("lbTitle").textContent = p.title;
      $("lbMeta").textContent = p.place || (CATEGORIES.filter(function (c) { return c.id === p.cat; })[0] || {}).label || "";
      $("lbCount").textContent = (cur + 1) + " / " + visible.length;
      var multi = visible.length > 1;
      $("lbPrev").style.display = multi ? "" : "none";
      $("lbNext").style.display = multi ? "" : "none";
      preload(cur + 1); preload(cur - 1); preload(cur + 2);
    }
    function openLB(i, from) {
      if (i < 0) return;
      lastFocus = from || document.activeElement;
      isOpen = true; lb.classList.add("open"); document.body.style.overflow = "hidden";
      show(i); $("lbClose").focus();
    }
    function closeLB() {
      if (!isOpen) return;
      isOpen = false; token++; lb.classList.remove("open"); document.body.style.overflow = "";
      lbImg.classList.remove("on", "low");
      lbImg.removeAttribute("src");
      if (lastFocus && lastFocus.focus) lastFocus.focus({ preventScroll: true });
    }

    /* start downloading the full image when the visitor shows interest */
    function warm(e) {
      var b = e.target.closest && e.target.closest(".g-item");
      if (b) loadFull(info(b).src);
    }
    grid.addEventListener("mouseover", warm);
    grid.addEventListener("touchstart", warm, { passive: true });
    grid.addEventListener("focusin", warm);

    $("lbClose").addEventListener("click", closeLB);
    $("lbPrev").addEventListener("click", function () { show(cur - 1); });
    $("lbNext").addEventListener("click", function () { show(cur + 1); });
    $("lbStage").addEventListener("click", function (e) { if (e.target === this) closeLB(); });

    document.addEventListener("keydown", function (e) {
      if (!isOpen) return;
      if (e.key === "Escape") { e.stopPropagation(); closeLB(); }
      else if (e.key === "ArrowRight") show(cur + 1);
      else if (e.key === "ArrowLeft") show(cur - 1);
      else if (e.key === "Tab") {
        var f = [$("lbClose"), $("lbPrev"), $("lbNext")].filter(function (b) { return b.style.display !== "none"; });
        var first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    });

    var sx = null, sy = null;
    $("lbStage").addEventListener("touchstart", function (e) { sx = e.touches[0].clientX; sy = e.touches[0].clientY; }, { passive: true });
    $("lbStage").addEventListener("touchend", function (e) {
      if (sx === null) return;
      var dx = e.changedTouches[0].clientX - sx, dy = e.changedTouches[0].clientY - sy;
      if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.3) show(cur + (dx < 0 ? 1 : -1));
      sx = null;
    }, { passive: true });

    applyFilter();
  }
})();
