/* =========================================================
   ADMIN PAGE TEXT/IMAGE OVERRIDES  (src/sg-content.js)

   STATUS: DISABLED (it was already commented out in the project you
   uploaded, so edits made in Admin > "Pages: content & images" are
   NOT shown on the live site).

   Why it is off: it matches elements by their position on the page
   (e.g. "p:12"). Any change to a page's HTML shifts the numbers and an
   admin edit would land on the wrong heading/paragraph. Several pages
   were corrected in this review, so any edits saved earlier would now
   point at different elements.

   To switch it on: set ENABLED to true below, then open each page in
   Admin > Pages and re-check every saved edit.
   ========================================================= */
(function () {
  "use strict";
  var ENABLED = false;
  window.SG_CONTENT_ENABLED = ENABLED; // read by the admin page to show a notice
  if (!ENABLED) return;
  if (document.getElementById("pgList")) return; // never run on the admin page itself

  var C = window.SG_CONFIG || {};
  if (!C.SUPABASE_URL || !C.SUPABASE_ANON_KEY) return;

  var page = (location.pathname.split("/").pop() || "index").replace(/\.html?$/i, "") || "index";
  var root = document.querySelector("main") || document.body;
  var els = [].filter.call(root.querySelectorAll("h1,h2,h3,h4,p,img"), function (e) {
    return e.tagName === "IMG" || (e.children.length === 0 && e.textContent.trim());
  });

  fetch(C.SUPABASE_URL + "/rest/v1/page_content?page=eq." + encodeURIComponent(page) + "&select=key,value", {
    headers: { apikey: C.SUPABASE_ANON_KEY }
  })
    .then(function (r) { return r.ok ? r.json() : []; })
    .then(function (rows) {
      var m = {};
      rows.forEach(function (r) { m[r.key] = r.value; });
      els.forEach(function (e, i) {
        var v = m[e.tagName.toLowerCase() + ":" + i];
        if (v == null) return;
        if (e.tagName === "IMG") {
          // only accept http(s) image URLs from the database
          if (!/^https?:\/\//i.test(v)) return;
          e.removeAttribute("srcset");
          e.removeAttribute("loading");
          e.src = v;
        } else {
          e.textContent = v; // textContent: never inject HTML from the database
        }
      });
    })
    .catch(function () {});
})();
