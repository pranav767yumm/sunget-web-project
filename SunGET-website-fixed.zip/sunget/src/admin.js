/* =========================================================
   admin.js — pgs/sun.html (admin panel)
   Moved out of the page's inline <script>. Behaviour is unchanged except
   for the fixes listed here:
   - config comes from src/sg-config.js (no second copy of the keys)
   - login is a real <form>: Enter key submits; button disabled while signing in
   - dashboard cards are <button>s (keyboard accessible)
   - site-relative photo paths ("/images/...") display correctly from /pgs/
   - product form: invalid JSON no longer leaves the Save button stuck on
     "Saving..." with an uncaught error; CSV import waits for every row and
     reports how many rows were saved / failed instead of guessing
   - burger button reports aria-expanded; sidebar groups report aria-expanded
   - notice in "Pages" when live content editing is switched off
   - messages that pointed to SETUP-2.md / SETUP-3.md / sg-careers.sql (files
     that are not in the project) now point to supabase/schema.sql
   Security note: everything here runs with the logged-in user's JWT. What a
   user can read/change is decided ONLY by Supabase Row Level Security
   policies — see supabase/schema.sql. Hiding this page is not protection.
   ========================================================= */
(function () {
  "use strict";
  var C = window.SG_CONFIG || {}, $ = function (i) { return document.getElementById(i); };
  if (!C.SUPABASE_URL || !C.SUPABASE_ANON_KEY) { $("setup").hidden = false; return; }
  var SQL_HINT = "Check the table and its policies (supabase/schema.sql).";

  /* Login is kept in memory only: reload, change page or close the tab = logged out. */
  var session = null;
  try { localStorage.removeItem("sg_admin"); sessionStorage.removeItem("sg_admin"); } catch (e) { /* storage blocked */ }

  function esc(t) { return String(t == null ? "" : t).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  /* "/images/x.jpg" (site-relative, as saved by the gallery import) → "../images/x.jpg" from /pgs/ */
  function rel(u) { u = String(u || ""); return u.charAt(0) === "/" && u.charAt(1) !== "/" ? ".." + u : u; }
  function hdr(extra) {
    var h = { apikey: C.SUPABASE_ANON_KEY };
    if (session) h.Authorization = "Bearer " + session.access_token;
    for (var k in extra) h[k] = extra[k];
    return h;
  }
  function api(path, opt) {
    opt = opt || {}; opt.headers = hdr(opt.headers || {});
    return fetch(C.SUPABASE_URL + path, opt).then(function (r) {
      if (r.status === 401) { $("logout").click(); throw new Error("Session expired. Please login again."); }
      return r;
    });
  }
  function say(id, text, cls) { var e = $(id); if (!e) return; e.textContent = text; e.className = "msg " + (cls || ""); }

  /* ---------- login / logout ---------- */
  function show() {
    $("login").hidden = !!session; $("app").hidden = !session;
    if (session) { view("home"); startPoll(); } else { stopPoll(); }
  }
  $("login").addEventListener("submit", function (ev) {
    ev.preventDefault();
    var email = $("em").value.trim(), pw = $("pw").value, btn = $("loginBtn");
    if (!email || !pw) return say("loginMsg", "Enter your email and password.", "err");
    btn.disabled = true;
    say("loginMsg", "Signing in...");
    fetch(C.SUPABASE_URL + "/auth/v1/token?grant_type=password", {
      method: "POST", headers: { apikey: C.SUPABASE_ANON_KEY, "Content-Type": "application/json" },
      body: JSON.stringify({ email: email, password: pw })
    }).then(function (r) { return r.json(); }).then(function (d) {
      if (!d.access_token) return say("loginMsg", "Login failed: " + (d.error_description || d.msg || d.message || "check your email and password"), "err");
      session = d; $("pw").value = ""; say("loginMsg", ""); show();
    }).catch(function (e) {
      say("loginMsg", "Could not reach the login server: " + (e && e.message ? e.message : e), "err");
    }).then(function () { btn.disabled = false; });
  });
  function serverLogout() {
    if (!session) return;
    try { fetch(C.SUPABASE_URL + "/auth/v1/logout?scope=local", { method: "POST", keepalive: true, headers: { apikey: C.SUPABASE_ANON_KEY, Authorization: "Bearer " + session.access_token } }); } catch (e) { /* ignore */ }
  }
  $("logout").onclick = function () { serverLogout(); session = null; $("pw").value = ""; show(); };
  window.addEventListener("pagehide", serverLogout);
  window.addEventListener("pageshow", function (e) { if (e.persisted) location.reload(); });

  /* ---------- sidebar + routing ---------- */
  var VIEWS = ["home", "enq", "gal", "pages", "products", "product-enquiries", "careers", "roles"];
  function view(v) {
    VIEWS.forEach(function (x) { $("v-" + x).hidden = x !== v; });
    Array.prototype.forEach.call(document.querySelectorAll("aside .mi[data-v]"), function (b) {
      b.classList.toggle("on", b.dataset.v === v && !b.dataset.act && (!b.dataset.tab || b.dataset.tab === eTab));
    });
    $("side").classList.remove("open"); $("burger").setAttribute("aria-expanded", "false");
    if (v === "home") return Promise.all([loadEnq(true), loadGal()]).then(renderHome);
    if (v === "enq") return loadEnq();
    if (v === "gal") return loadGal();
    if (v === "pages" && !$("pageSel").options.length) initPages();
    if (v === "careers") return loadCareers();
    if (v === "roles") return loadRoles();
    if (v === "products") return loadUtilityProducts();
    if (v === "product-enquiries") return loadUtilityEnquiries();
  }
  Array.prototype.forEach.call(document.querySelectorAll("aside .mi[data-v]"), function (b) {
    b.onclick = function () {
      if (b.dataset.tab) { eTab = b.dataset.tab; ePage = 1; }
      Promise.resolve(view(b.dataset.v)).then(function () { if (b.dataset.act === "add") $("gAdd").click(); else if (b.dataset.act === "cats") $("gCats").click(); });
    };
  });
  Array.prototype.forEach.call(document.querySelectorAll("aside .gh"), function (b) {
    b.onclick = function () {
      var s = b.nextElementSibling; s.hidden = !s.hidden;
      b.querySelector("em").textContent = s.hidden ? "+" : "−";
      b.setAttribute("aria-expanded", s.hidden ? "false" : "true");
    };
  });
  $("burger").onclick = function () {
    var open = $("side").classList.toggle("open");
    this.setAttribute("aria-expanded", open ? "true" : "false");
  };

  /* ---------- dashboard home ---------- */
  function renderHome() {
    var c = { total: ENQ.length, new: 0, pending: 0, contacted: 0, completed: 0, old: 0 };
    ENQ.forEach(function (x) { if (c[x.status] != null) c[x.status]++; if (isOld(x)) c.old++; });
    var pub = GP.filter(function (p) { return p.published !== false; }).length;
    var cards = [["Total Enquiries", c.total, "💬", "#2b5a0b", "enq", "all"], ["New Enquiries", c.new, "💬", "#f44336", "enq", "new"], ["Pending Enquiries", c.pending, "💬", "#ff9800", "enq", "pending"],
      ["Contacted Enquiries", c.contacted, "💬", "#2196f3", "enq", "contacted"], ["Completed Enquiries", c.completed, "💬", "#8bc34a", "enq", "completed"], ["Old Enquiries", c.old, "💬", "#795548", "enq", "old"],
      ["Total Gallery Images", GP.length, "🖼", "#9c27b0", "gal", ""], ["Published Images", pub, "🖼", "#2196f3", "gal", ""], ["Draft Images", GP.length - pub, "🖼", "#ff9800", "gal", ""], ["Gallery Categories", GC.length, "🖼", "#795548", "gal", ""]];
    $("homeCards").innerHTML = cards.map(function (k) {
      return '<button type="button" class="hc" style="background:' + k[3] + '" data-v="' + k[4] + '" data-tab="' + k[5] + '"><span class="hi" aria-hidden="true">' + k[2] + '</span><span class="ht"><small>' + k[0] + "</small><b>" + k[1] + "</b></span></button>";
    }).join("");
  }
  $("homeCards").onclick = function (e) { var b = e.target.closest(".hc"); if (!b) return; if (b.dataset.tab) { eTab = b.dataset.tab; ePage = 1; } view(b.dataset.v); };

  /* ---------- shared: image resize + storage ---------- */
  function resize(file, maxW, q) {
    return new Promise(function (res, rej) {
      var img = new Image(), u = URL.createObjectURL(file);
      img.onload = function () {
        var s = Math.min(1, maxW / img.width), w = Math.round(img.width * s), h = Math.round(img.height * s);
        var cv = document.createElement("canvas"); cv.width = w; cv.height = h;
        cv.getContext("2d").drawImage(img, 0, 0, w, h);
        cv.toBlob(function (b) { URL.revokeObjectURL(u); if (!b) return rej(new Error("Cannot convert " + file.name)); res({ blob: b, w: w, h: h }); }, "image/webp", q);
      };
      img.onerror = function () { URL.revokeObjectURL(u); rej(new Error("Cannot read " + file.name)); };
      img.src = u;
    });
  }
  function storageUpload(path, blob) {
    return api("/storage/v1/object/gallery/" + path, { method: "POST", headers: { "Content-Type": "image/webp" }, body: blob })
      .then(function (r) { if (!r.ok) throw new Error("Upload failed (" + r.status + ")"); return C.SUPABASE_URL + "/storage/v1/object/public/gallery/" + path; });
  }

  /* ---------- shared helpers: toast + modal ---------- */
  function toast(m, t) {
    var d = document.createElement("div"); d.className = t || ""; d.textContent = m; d.onclick = function () { d.remove(); };
    $("toast").appendChild(d); while ($("toast").children.length > 3) $("toast").firstChild.remove();
    setTimeout(function () { d.remove(); }, 4200);
  }
  var modalReturn = null;
  function openModal(html) {
    modalReturn = document.activeElement;
    $("modalBox").innerHTML = html; $("modalBg").hidden = false;
    var f = $("modalBox").querySelector("input:not([type=file]), textarea, select, button:not(.mclose)") || $("modalBox").querySelector("button");
    if (f) setTimeout(function () { f.focus(); }, 20);
  }
  function closeModal() {
    $("modalBg").hidden = true; $("modalBox").innerHTML = "";
    if (modalReturn && document.contains(modalReturn) && modalReturn.focus) modalReturn.focus();
    modalReturn = null;
  }
  $("modalBg").onmousedown = function (e) { if (e.target === this) closeModal(); };
  document.addEventListener("click", function (e) { if (e.target.closest(".mclose")) closeModal(); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && !$("modalBg").hidden) closeModal(); });
  function busy(btn, on, label) { btn.disabled = on; if (on) { btn.dataset.l = btn.innerHTML; btn.innerHTML = '<span class="spin"></span> ' + esc(label || "Please wait..."); } else if (btn.dataset.l) btn.innerHTML = btn.dataset.l; }
  function when(t) { try { return new Date(t).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }); } catch (e) { return t; } }
  function whenShort(t) { try { return new Date(t).toLocaleString("en-IN", { day: "numeric", month: "short", year: "2-digit", hour: "numeric", minute: "2-digit" }); } catch (e) { return t; } }
  function ymd(d) { var m = d.getMonth() + 1, dd = d.getDate(); return d.getFullYear() + "-" + (m < 10 ? "0" : "") + m + "-" + (dd < 10 ? "0" : "") + dd; }
  function fetchAll(path) {
    var out = [];
    function next(off) {
      return api(path + "&limit=1000&offset=" + off).then(function (r) { return r.json(); }).then(function (rows) {
        if (!Array.isArray(rows)) throw new Error((rows && rows.message) || "Database error");
        out = out.concat(rows); return rows.length === 1000 ? next(off + 1000) : out;
      });
    }
    return next(0);
  }

  /* =====================  ENQUIRY MANAGEMENT  ===================== */
  var ENQ = [], eTab = "all", ePage = 1, ePer = 15, sel = {}, lastCount = null, pollT = null, OLD_DAYS = 7;
  var STATUSES = ["new", "pending", "contacted", "completed"];
  var PRESET = ["Residential Solar Enquiry", "Commercial Solar Enquiry", "Industrial Solar Enquiry", "Rooftop Solar Enquiry", "Solar Installation Enquiry", "General Enquiry"];
  function isOld(x) { return Date.now() - new Date(x.created_at).getTime() > OLD_DAYS * 864e5; }
  function cap(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : ""; }

  function loadEnq(silent) {
    return fetchAll("/rest/v1/enquiries?select=*&order=created_at.desc").then(function (rows) {
      if (lastCount !== null && rows.length > lastCount) toast((rows.length - lastCount) + " new enquiry received", "ok");
      lastCount = rows.length; ENQ = rows;
      var n = rows.filter(function (x) { return x.status === "new"; }).length; $("badge").hidden = !n; $("badge").textContent = n;
      if (!$("v-enq").hidden) renderEnq(); if (!$("v-home").hidden) renderHome();
    }).catch(function (e) { if (!silent) $("enqBody").innerHTML = '<tr><td colspan="8" class="msg err">' + esc(e.message) + " - " + esc(SQL_HINT) + "</td></tr>"; });
  }
  function startPoll() { stopPoll(); loadEnq(true); pollT = setInterval(function () { if (session && !document.hidden) loadEnq(true); }, 20000); }
  function stopPoll() { if (pollT) clearInterval(pollT); pollT = null; lastCount = null; }

  function allTypes() { var t = PRESET.slice(); ENQ.forEach(function (x) { if (x.enquiry_type && t.indexOf(x.enquiry_type) < 0) t.push(x.enquiry_type); }); return t; }
  function renderEnq() {
    var c = { total: ENQ.length, new: 0, pending: 0, contacted: 0, completed: 0, old: 0 };
    ENQ.forEach(function (x) { if (c[x.status] != null) c[x.status]++; if (isOld(x)) c.old++; });
    $("enqStats").innerHTML = [["Total Enquiries", c.total, ""], ["New Enquiries", c.new, "new"], ["Pending", c.pending, "pend"], ["Contacted", c.contacted, "cont"], ["Completed", c.completed, ""], ["Old Enquiries (" + OLD_DAYS + "+ days)", c.old, "old"]]
      .map(function (s) { return '<div class="stat ' + s[2] + '"><b>' + s[1] + "</b><span>" + s[0] + "</span></div>"; }).join("");
    var types = allTypes(), cnt = {}; ENQ.forEach(function (x) { var k = x.enquiry_type || "General Enquiry"; cnt[k] = (cnt[k] || 0) + 1; });
    $("enqTypes").innerHTML = types.map(function (t) { return '<button type="button" class="tchip" data-t="' + esc(t) + '">' + esc(t) + "<b>" + (cnt[t] || 0) + "</b></button>"; }).join("");
    var cur = $("ftype").value;
    $("ftype").innerHTML = '<option value="">All enquiry types</option>' + types.map(function (t) { return '<option value="' + esc(t) + '">' + esc(t) + "</option>"; }).join(""); $("ftype").value = cur;
    var tabs = [["all", "All Enquiries", c.total], ["new", "New", c.new], ["old", "Old", c.old], ["pending", "Pending", c.pending], ["contacted", "Contacted", c.contacted], ["completed", "Completed", c.completed]];
    $("enqTabs").innerHTML = tabs.map(function (t) { return '<button type="button" class="tab ' + (eTab === t[0] ? "on" : "") + '" data-tab="' + t[0] + '">' + t[1] + "<small>" + t[2] + "</small></button>"; }).join("");
    renderTable();
  }
  function getFiltered() {
    var q = $("fq").value.trim().toLowerCase(), qd = q.replace(/[\s-]/g, ""), ft = $("ftype").value, fs = $("fstat").value, d1 = $("fd1").value, d2 = $("fd2").value, so = $("fsort").value;
    var list = ENQ.filter(function (x) {
      if (eTab === "new" && x.status !== "new") return false;
      if (eTab === "old" && !isOld(x)) return false;
      if (["pending", "contacted", "completed"].indexOf(eTab) > -1 && x.status !== eTab) return false;
      if (q && (x.name || "").toLowerCase().indexOf(q) < 0 && (!qd || (x.phone || "").replace(/[\s-]/g, "").indexOf(qd) < 0)) return false;
      if (ft && (x.enquiry_type || "General Enquiry") !== ft) return false;
      if (fs && x.status !== fs) return false;
      var dt = ymd(new Date(x.created_at)); if (d1 && dt < d1) return false; if (d2 && dt > d2) return false;
      return true;
    });
    list.sort(function (a, b) { return so === "old" ? new Date(a.created_at) - new Date(b.created_at) : new Date(b.created_at) - new Date(a.created_at); });
    return list;
  }
  function renderTable() {
    var list = getFiltered(), pages = Math.max(1, Math.ceil(list.length / ePer)); if (ePage > pages) ePage = pages;
    var rows = list.slice((ePage - 1) * ePer, ePage * ePer);
    $("enqCount").textContent = list.length + " enquiries shown";
    $("selAll").checked = rows.length > 0 && rows.every(function (x) { return sel[x.id]; });
    $("enqBody").innerHTML = rows.map(function (x) {
      var id = esc(x.id);
      return '<tr class="' + (x.status === "new" ? "isnew" : "") + '"><td><input type="checkbox" class="sc" data-id="' + id + '" aria-label="Select enquiry from ' + esc(x.name || "customer") + '" ' + (sel[x.id] ? "checked" : "") + "></td>" +
        "<td><b>" + esc(x.name || "-") + "</b>" + (isOld(x) ? ' <span class="pill old">Old</span>' : "") + '<br><small class="muted">' + esc(x.city || "-") + "</small></td><td>" + esc(x.phone || "-") + '<br><small class="muted">' + esc(x.email || "") + "</small></td>" +
        "<td>" + esc(x.enquiry_type || "General Enquiry") + "</td><td>" + esc(x.requirement || "-") + "</td><td>" + esc(whenShort(x.created_at)) + "</td>" +
        '<td><span class="pill ' + esc(x.status) + '">' + esc(cap(x.status)) + '</span><br><select class="stsel" data-id="' + id + '" aria-label="Status">' + STATUSES.map(function (s) { return '<option value="' + s + '"' + (s === x.status ? " selected" : "") + ">" + cap(s) + "</option>"; }).join("") + "</select></td>" +
        '<td class="nw"><button type="button" class="ib" data-a="view" data-id="' + id + '" title="View details">View</button><button type="button" class="ib" data-a="edit" data-id="' + id + '" title="Edit">Edit</button>' +
        (x.phone ? '<a class="ib" href="tel:' + esc(x.phone) + '" title="Call customer">📞</a>' : "") + (x.email ? '<a class="ib" href="mailto:' + esc(x.email) + '" title="Send email">✉️</a>' : "") + '<button type="button" class="ib red" data-a="del" data-id="' + id + '" title="Delete">🗑</button></td></tr>';
    }).join("") || '<tr><td colspan="8" style="text-align:center;padding:30px">No enquiries found.</td></tr>';
    $("enqPager").innerHTML = "<span>Page " + ePage + " of " + pages + '</span><span><button type="button" class="sec sm" data-p="-1"' + (ePage <= 1 ? " disabled" : "") + '>‹ Previous</button> <button type="button" class="sec sm" data-p="1"' + (ePage >= pages ? " disabled" : "") + ">Next ›</button></span>" +
      '<span><label for="perSel" style="display:inline;margin:0">Rows per page</label> <select id="perSel">' + [10, 15, 25, 50, 100].map(function (n) { return "<option" + (n === ePer ? " selected" : "") + ">" + n + "</option>"; }).join("") + "</select></span>";
  }
  function enqById(id) { return ENQ.filter(function (x) { return String(x.id) === String(id); })[0]; }
  function setStatus(id, s) {
    return api("/rest/v1/enquiries?id=eq." + encodeURIComponent(id), { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: s }) })
      .then(function (r) { if (!r.ok) throw new Error("Could not change status"); var x = enqById(id); if (x) x.status = s; toast("Status changed to " + cap(s), "ok"); renderEnq(); loadEnq(true); }).catch(function (e) { toast(e.message, "err"); });
  }
  function viewEnq(id) {
    var x = enqById(id); if (!x) return;
    var xid = esc(x.id);
    openModal('<button type="button" class="mclose">Close</button><h2>Enquiry details</h2><dl class="dl">' +
      [["Customer name", x.name], ["Mobile number", x.phone], ["Email address", x.email], ["City / Location", x.city], ["Enquiry type", x.enquiry_type || "General Enquiry"], ["Solar system requirement", x.requirement], ["Message", x.message], ["Other details", x.extra], ["Submitted from", x.source], ["Submission date", when(x.created_at)], ["Status", cap(x.status)]]
        .map(function (r) { return "<dt>" + r[0] + "</dt><dd>" + esc(r[1] || "-") + "</dd>"; }).join("") + '</dl><div class="macts">' +
      '<button type="button" data-m="new" data-id="' + xid + '" class="sec sm">Mark as New</button><button type="button" data-m="pending" data-id="' + xid + '" class="sec sm">Mark as Pending</button><button type="button" data-m="contacted" data-id="' + xid + '" class="sec sm">Mark as Contacted</button><button type="button" data-m="completed" data-id="' + xid + '" class="sm">Mark as Completed</button>' +
      (x.phone ? '<a class="ib" href="tel:' + esc(x.phone) + '">📞 Call customer</a>' : "") + (x.email ? '<a class="ib" href="mailto:' + esc(x.email) + '">✉️ Send email</a>' : "") + "</div>");
  }
  function editEnq(id) {
    var x = enqById(id); if (!x) return;
    openModal('<button type="button" class="mclose">Close</button><h2>Edit enquiry</h2><form id="eForm" novalidate>' +
      '<label for="eName">Customer name *</label><input id="eName" name="name" value="' + esc(x.name) + '">' +
      '<div class="row"><div><label for="ePhone">Mobile number *</label><input id="ePhone" name="phone" value="' + esc(x.phone) + '"></div><div><label for="eEmail">Email address</label><input id="eEmail" name="email" value="' + esc(x.email) + '"></div></div>' +
      '<div class="row"><div><label for="eCity">City / Location</label><input id="eCity" name="city" value="' + esc(x.city) + '"></div><div><label for="eType">Enquiry type</label><input id="eType" name="enquiry_type" list="tl" value="' + esc(x.enquiry_type || "General Enquiry") + '"><datalist id="tl">' + allTypes().map(function (t) { return '<option value="' + esc(t) + '">'; }).join("") + "</datalist></div></div>" +
      '<label for="eReq">Solar system requirement</label><input id="eReq" name="requirement" value="' + esc(x.requirement) + '"><label for="eMsg">Message</label><textarea id="eMsg" name="message" rows="3">' + esc(x.message) + "</textarea>" +
      '<label for="eStat">Status</label><select id="eStat" name="status">' + STATUSES.map(function (s) { return '<option value="' + s + '"' + (s === x.status ? " selected" : "") + ">" + cap(s) + "</option>"; }).join("") + "</select>" +
      '<p class="msg err" id="eErr"></p><div class="macts"><button type="submit" id="eSave">Save changes</button><button type="button" class="sec mclose" style="float:none">Cancel</button></div></form>');
    $("eForm").onsubmit = function (ev) {
      ev.preventDefault(); var f = ev.target, v = function (n) { return f.elements[n].value.trim(); };
      if (!v("name")) return say("eErr", "Customer name is required.", "err");
      if (!/^[+\d][\d\s-]{6,17}$/.test(v("phone"))) return say("eErr", "Enter a valid mobile number.", "err");
      if (v("email") && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v("email"))) return say("eErr", "Enter a valid email address.", "err");
      var b = $("eSave"); busy(b, true, "Saving...");
      api("/rest/v1/enquiries?id=eq." + encodeURIComponent(id), { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: v("name"), phone: v("phone"), email: v("email"), city: v("city"), enquiry_type: v("enquiry_type") || "General Enquiry", requirement: v("requirement"), message: v("message"), status: v("status") }) })
        .then(function (r) { if (!r.ok) throw new Error("Could not save (" + r.status + ")"); toast("Enquiry updated", "ok"); closeModal(); return loadEnq(true); })
        .catch(function (e) { say("eErr", e.message, "err"); busy(b, false); });
    };
  }
  function delEnq(id) {
    var x = enqById(id); if (!x || !confirm("Delete the enquiry from " + (x.name || "this customer") + " permanently? This cannot be undone.")) return;
    api("/rest/v1/enquiries?id=eq." + encodeURIComponent(id), { method: "DELETE" }).then(function (r) { if (!r.ok) throw new Error("Delete failed"); delete sel[id]; toast("Enquiry deleted", "ok"); return loadEnq(true); }).catch(function (e) { toast(e.message, "err"); });
  }

  /* ---------- export to Excel ---------- */
  /* Cells that start with = + - @ are prefixed with ' so Excel never runs
     a formula typed into a public enquiry form (CSV / formula injection). */
  function cell(v) { v = v == null ? "" : String(v); return /^[=+\-@\t\r]/.test(v) ? "'" + v : v; }
  function exportRows(rows, label) {
    if (!rows.length) return toast("No enquiries to export.", "err");
    var data = rows.map(function (x, i) {
      return { "Sr No": i + 1, "Customer Name": cell(x.name), "Mobile Number": cell(x.phone), "Email Address": cell(x.email), "City / Location": cell(x.city), "Enquiry Type": cell(x.enquiry_type || "General Enquiry"),
        "Solar System Requirement": cell(x.requirement), "Message": cell(x.message), "Other Details": cell(x.extra), "Submission Date": when(x.created_at), "Enquiry Status": cap(x.status), "Submitted From": cell(x.source) };
    });
    var name = "SunGET-Enquiries-" + label + "-" + ymd(new Date());
    if (window.XLSX) {
      var ws = XLSX.utils.json_to_sheet(data); ws["!cols"] = [6, 22, 16, 28, 18, 28, 30, 40, 30, 22, 14, 16].map(function (w) { return { wch: w }; });
      var wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, "Enquiries"); XLSX.writeFile(wb, name + ".xlsx");
    } else { // fallback if the Excel library could not load
      var keys = Object.keys(data[0]), csv = [keys.join(",")].concat(data.map(function (r) { return keys.map(function (k) { return '"' + String(r[k]).replace(/"/g, '""') + '"'; }).join(","); })).join("\r\n");
      download(new Blob(["﻿" + csv], { type: "text/csv" }), name + ".csv");
      toast("Excel library not loaded - downloaded as CSV (opens in Excel).", "err"); return;
    }
    toast(rows.length + " enquiries exported to Excel", "ok");
  }
  function download(blob, filename) {
    var a = document.createElement("a"), u = URL.createObjectURL(blob);
    a.href = u; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(u); }, 1000);
  }
  $("expBtn").onclick = function (e) { e.stopPropagation(); var open = $("expMenu").hidden; $("expMenu").hidden = !open; this.setAttribute("aria-expanded", open ? "true" : "false"); };
  document.addEventListener("click", function () { $("expMenu").hidden = true; $("expBtn").setAttribute("aria-expanded", "false"); });
  $("expMenu").onclick = function (e) {
    var b = e.target.closest("button[data-x]"); if (!b) return; var k = b.dataset.x, rows;
    if (k === "all") rows = ENQ; else if (k === "filtered") rows = getFiltered(); else if (k === "new") rows = ENQ.filter(function (x) { return x.status === "new"; });
    else if (k === "old") rows = ENQ.filter(isOld); else rows = ENQ.filter(function (x) { return sel[x.id]; });
    if (k === "selected" && !rows.length) return toast("Tick the enquiries you want to export first.", "err");
    exportRows(rows, k);
  };

  /* ---------- enquiry events ---------- */
  ["fq", "ftype", "fstat", "fd1", "fd2", "fsort"].forEach(function (id) { $(id).addEventListener(id === "fq" ? "input" : "change", function () { ePage = 1; renderTable(); }); });
  $("fClear").onclick = function () { ["fq", "ftype", "fstat", "fd1", "fd2"].forEach(function (i) { $(i).value = ""; }); $("fsort").value = "new"; eTab = "all"; ePage = 1; renderEnq(); };
  $("enqRefresh").onclick = function () { loadEnq().then(function () { toast("Refreshed", "ok"); }); };
  $("enqTabs").onclick = function (e) { var b = e.target.closest("[data-tab]"); if (b) { eTab = b.dataset.tab; ePage = 1; renderEnq(); } };
  $("enqTypes").onclick = function (e) { var b = e.target.closest("[data-t]"); if (b) { $("ftype").value = b.dataset.t; ePage = 1; renderTable(); window.scrollTo({ top: $("enqBody").offsetTop - 200, behavior: "smooth" }); } };
  $("selAll").onchange = function () { var on = this.checked; getFiltered().slice((ePage - 1) * ePer, ePage * ePer).forEach(function (x) { if (on) sel[x.id] = true; else delete sel[x.id]; }); renderTable(); };
  $("enqBody").onchange = function (e) {
    if (e.target.classList.contains("sc")) { if (e.target.checked) sel[e.target.dataset.id] = true; else delete sel[e.target.dataset.id]; }
    else if (e.target.classList.contains("stsel")) setStatus(e.target.dataset.id, e.target.value);
  };
  $("enqBody").onclick = function (e) { var b = e.target.closest("button[data-a]"); if (!b) return; ({ view: viewEnq, edit: editEnq, del: delEnq })[b.dataset.a](b.dataset.id); };
  $("enqPager").onclick = function (e) { var b = e.target.closest("[data-p]"); if (b) { ePage += +b.dataset.p; renderTable(); } };
  $("enqPager").onchange = function (e) { if (e.target.id === "perSel") { ePer = +e.target.value; ePage = 1; renderTable(); } };
  $("modalBox").onclick = function (e) { var b = e.target.closest("button[data-m]"); if (b) { setStatus(b.dataset.id, b.dataset.m).then(function () { viewEnq(b.dataset.id); }); } };

  /* =====================  GALLERY MANAGEMENT  ===================== */
  var GP = [], GC = [], IMPORTED = false, dragId = null;
  function slugify(s) { return String(s).toLowerCase().replace(/&/g, "and").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "category"; }
  function catName(slug) { var c = GC.filter(function (x) { return x.slug === slug; })[0]; return c ? c.name : slug; }
  function sortGP() { GP.sort(function (a, b) { return (a.sort_order || 0) - (b.sort_order || 0) || new Date(b.created_at) - new Date(a.created_at); }); }
  function catOptions(sel2, withAll) { return (withAll ? '<option value="">All categories</option>' : "") + GC.map(function (c) { return '<option value="' + esc(c.slug) + '"' + (c.slug === sel2 ? " selected" : "") + ">" + esc(c.name) + "</option>"; }).join(""); }

  function loadGal() {
    return Promise.all([
      api("/rest/v1/photos?select=*&order=sort_order.asc,created_at.desc").then(function (r) { return r.json(); }),
      api("/rest/v1/gallery_categories?select=*&order=sort_order.asc").then(function (r) { return r.json(); }),
      api("/rest/v1/page_content?page=eq._gallery&key=eq.imported&select=value").then(function (r) { return r.json(); })
    ]).then(function (res) {
      if (!Array.isArray(res[0]) || !Array.isArray(res[1])) { $("gStats").innerHTML = '<p class="msg err">Gallery tables could not be read. ' + esc(SQL_HINT) + "</p>"; $("gGrid2").innerHTML = ""; return; }
      GP = res[0]; GC = res[1]; IMPORTED = Array.isArray(res[2]) && res[2].length > 0; sortGP(); renderGal(); if (!$("v-home").hidden) renderHome();
    }).catch(function (e) { toast(e.message, "err"); });
  }
  function gView() { var c = $("gfCat").value, s = $("gfStat").value; return GP.filter(function (p) { return (!c || p.cat === c) && (!s || (s === "published") === (p.published !== false)); }); }
  function renderGal() {
    var pub = GP.filter(function (p) { return p.published !== false; }).length;
    $("gStats").innerHTML = [["Total Gallery Images", GP.length], ["Published Images", pub], ["Draft Images", GP.length - pub], ["Gallery Categories", GC.length]].map(function (s) { return '<div class="stat"><b>' + s[1] + "</b><span>" + s[0] + "</span></div>"; }).join("");
    var cur = $("gfCat").value; $("gfCat").innerHTML = catOptions(cur, true); $("gfCat").value = cur;
    $("gImport").hidden = IMPORTED;
    var list = gView();
    $("gGrid2").innerHTML = list.map(function (p) {
      var live = p.published !== false, id = esc(p.id);
      return '<div class="gc" draggable="true" data-id="' + id + '"><img src="' + esc(rel(p.thumb || p.src)) + '" alt="' + esc(p.alt || p.title) + '" draggable="false" loading="lazy"><div class="b"><b>' + esc(p.title) + "</b><small>" + esc(catName(p.cat)) + " · order " + (p.sort_order || 0) + '</small><span class="pill ' + (live ? "published" : "draft") + '">' + (live ? "Published" : "Draft") + "</span>" +
        '<div style="margin-top:8px"><button type="button" class="ib" data-g="edit" data-id="' + id + '">Edit</button><button type="button" class="ib" data-g="pub" data-id="' + id + '">' + (live ? "Unpublish" : "Publish") + '</button><button type="button" class="ib red" data-g="del" data-id="' + id + '">Delete</button>' +
        '<button type="button" class="ib" data-g="left" data-id="' + id + '" title="Move earlier" aria-label="Move earlier">◀</button><button type="button" class="ib" data-g="right" data-id="' + id + '" title="Move later" aria-label="Move later">▶</button></div></div></div>';
    }).join("") || "<p>No images here yet. Click ADD IMAGE.</p>";
  }
  function gById(id) { return GP.filter(function (p) { return String(p.id) === String(id); })[0]; }
  function patchPhoto(id, obj) { return api("/rest/v1/photos?id=eq." + encodeURIComponent(id), { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(obj) }).then(function (r) { if (!r.ok) throw new Error("Could not save (" + r.status + ")"); }); }
  function storagePath(u) { return (u || "").split("/public/gallery/")[1]; }
  function dropFiles(p) { [p.src, p.thumb].forEach(function (u) { var s = storagePath(u); if (s) api("/storage/v1/object/gallery/" + s, { method: "DELETE" }); }); }
  function okImg(f) { return /^image\/(jpeg|png|webp|gif)$/.test(f.type) && f.size <= 25 * 1024 * 1024; }
  function upload2(file, tag) { var id = Date.now() + "-" + tag; return Promise.all([resize(file, 1800, 0.8), resize(file, 800, 0.75)]).then(function (r) { return Promise.all([storageUpload(id + ".webp", r[0].blob), storageUpload(id + "-t.webp", r[1].blob)]).then(function (u) { return { src: u[0], thumb: u[1], w: r[0].w, h: r[0].h }; }); }); }

  function imgForm(p) {
    var e = !!p; p = p || {};
    return '<form id="gForm" novalidate><label for="gFiles">' + (e ? "Change image (optional)" : "Images * (you can choose many)") + '</label><input type="file" id="gFiles" accept="image/jpeg,image/png,image/webp,image/gif"' + (e ? "" : " multiple") + '><div id="gPrev" class="thumbs-prev">' + (e ? '<img src="' + esc(rel(p.thumb || p.src)) + '" alt="" style="width:120px;height:90px">' : "") + "</div>" +
      '<label for="gTitle">Image title' + (e ? " *" : " (blank = file name)") + '</label><input id="gTitle" name="title" value="' + esc(p.title) + '" maxlength="120"><label for="gDesc">Image description</label><textarea id="gDesc" name="description" rows="2" maxlength="300">' + esc(p.description) + "</textarea>" +
      '<div class="row"><div><label for="gCat">Image category *</label><select id="gCat" name="cat">' + catOptions(p.cat || $("gfCat").value) + '</select></div><div><label for="gOrd">Display order (small number = first)</label><input id="gOrd" name="sort_order" type="number" value="' + (p.sort_order != null ? p.sort_order : 0) + '"></div></div>' +
      '<div class="row"><div><label for="gAlt">Image alt text</label><input id="gAlt" name="alt" value="' + esc(p.alt) + '" maxlength="160" placeholder="Describe the picture"></div><div><label for="gPub">Status</label><select id="gPub" name="published"><option value="true"' + (p.published !== false ? " selected" : "") + '>Published</option><option value="false"' + (p.published === false ? " selected" : "") + ">Draft (hidden)</option></select></div></div>" +
      '<p class="msg err" id="gErr"></p><div class="macts"><button type="submit" id="gSave">' + (e ? "Save changes" : "Upload images") + '</button><button type="button" class="sec mclose" style="float:none">Cancel</button></div></form>';
  }
  $("gAdd").onclick = function () {
    if (!GC.length) return toast("Add a category first (Manage categories).", "err");
    openModal('<button type="button" class="mclose">Close</button><h2>Add images</h2>' + imgForm());
    $("gFiles").onchange = function () {
      $("gPrev").innerHTML = "";
      Array.prototype.forEach.call(this.files, function (f) { var i = new Image(); i.alt = ""; i.src = URL.createObjectURL(f); i.onload = function () { URL.revokeObjectURL(i.src); }; $("gPrev").appendChild(i); });
    };
    $("gForm").onsubmit = function (ev) {
      ev.preventDefault(); var f = ev.target, files = Array.prototype.slice.call($("gFiles").files);
      if (!files.length) return say("gErr", "Please choose at least one image.", "err");
      if (!files.every(okImg)) return say("gErr", "Only JPG, PNG, WebP or GIF images up to 25 MB are allowed.", "err");
      var b = $("gSave"), n = 0, order = parseInt(f.elements.sort_order.value, 10) || 0, chain = Promise.resolve(); busy(b, true, "Uploading...");
      files.forEach(function (file, i) {
        chain = chain.then(function () {
          b.innerHTML = '<span class="spin"></span> Uploading ' + (i + 1) + " of " + files.length + "...";
          return upload2(file, i).then(function (u) {
            var t = f.elements.title.value.trim() || file.name.replace(/\.[^.]+$/, "");
            return api("/rest/v1/photos", { method: "POST", headers: { "Content-Type": "application/json", Prefer: "return=minimal" }, body: JSON.stringify({ src: u.src, thumb: u.thumb, w: u.w, h: u.h, cat: f.elements.cat.value, title: t, description: f.elements.description.value.trim(), alt: f.elements.alt.value.trim() || t, sort_order: order + i, published: f.elements.published.value === "true" }) })
              .then(function (r) { if (!r.ok) throw new Error("Could not save details (" + r.status + "). " + SQL_HINT); n++; });
          });
        });
      });
      chain.then(function () { toast(n + " image(s) uploaded", "ok"); closeModal(); }).catch(function (e) { say("gErr", e.message, "err"); busy(b, false); }).then(loadGal);
    };
  };
  function editImg(id) {
    var p = gById(id); if (!p) return;
    openModal('<button type="button" class="mclose">Close</button><h2>Edit image</h2>' + imgForm(p));
    $("gForm").onsubmit = function (ev) {
      ev.preventDefault(); var f = ev.target, file = $("gFiles").files[0];
      if (!f.elements.title.value.trim()) return say("gErr", "Image title is required.", "err");
      if (file && !okImg(file)) return say("gErr", "Only JPG, PNG, WebP or GIF images up to 25 MB are allowed.", "err");
      var b = $("gSave"); busy(b, true, "Saving...");
      var obj = { title: f.elements.title.value.trim(), description: f.elements.description.value.trim(), alt: f.elements.alt.value.trim() || f.elements.title.value.trim(), cat: f.elements.cat.value, sort_order: parseInt(f.elements.sort_order.value, 10) || 0, published: f.elements.published.value === "true" };
      (file ? upload2(file, "r") : Promise.resolve(null)).then(function (u) { if (u) { obj.src = u.src; obj.thumb = u.thumb; obj.w = u.w; obj.h = u.h; } return patchPhoto(id, obj).then(function () { if (u) dropFiles(p); }); })
        .then(function () { toast("Image updated", "ok"); closeModal(); return loadGal(); }).catch(function (e) { say("gErr", e.message, "err"); busy(b, false); });
    };
  }
  function moveImg(id, dir) {
    var v = gView(), i = v.map(function (p) { return String(p.id); }).indexOf(String(id)), j = i + dir; if (i < 0 || j < 0 || j >= v.length) return;
    var item = v.splice(i, 1)[0]; v.splice(j, 0, item); saveOrder(v);
  }
  function saveOrder(v) {
    var jobs = []; v.forEach(function (p, i) { var o = i * 10; if ((p.sort_order || 0) !== o) { p.sort_order = o; jobs.push(patchPhoto(p.id, { sort_order: o })); } });
    sortGP(); renderGal();
    Promise.all(jobs).then(function () { if (jobs.length) toast("Order saved", "ok"); }).catch(function (e) { toast(e.message, "err"); loadGal(); });
  }
  $("gGrid2").onclick = function (e) {
    var b = e.target.closest("button[data-g]"); if (!b) return; var id = b.dataset.id, p = gById(id), a = b.dataset.g;
    if (!p) return;
    if (a === "edit") editImg(id);
    else if (a === "pub") patchPhoto(id, { published: p.published === false }).then(function () { toast(p.published === false ? "Image published" : "Image hidden (draft)", "ok"); return loadGal(); }).catch(function (er) { toast(er.message, "err"); });
    else if (a === "del") { if (!confirm('Delete "' + p.title + '" permanently from the website?')) return; api("/rest/v1/photos?id=eq." + encodeURIComponent(id), { method: "DELETE" }).then(function (r) { if (!r.ok) throw new Error("Delete failed"); dropFiles(p); toast("Image deleted", "ok"); return loadGal(); }).catch(function (er) { toast(er.message, "err"); }); }
    else if (a === "left") moveImg(id, -1); else if (a === "right") moveImg(id, 1);
  };
  /* drag and drop */
  $("gGrid2").addEventListener("dragstart", function (e) { var c = e.target.closest(".gc"); if (!c) return; dragId = c.dataset.id; c.classList.add("drag"); e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", dragId); });
  $("gGrid2").addEventListener("dragover", function (e) { var c = e.target.closest(".gc"); if (!c || !dragId) return; e.preventDefault(); Array.prototype.forEach.call(document.querySelectorAll(".gc.over"), function (x) { x.classList.remove("over"); }); c.classList.add("over"); });
  $("gGrid2").addEventListener("drop", function (e) {
    var c = e.target.closest(".gc"); e.preventDefault(); if (!c || !dragId || c.dataset.id === dragId) return;
    var v = gView(), from = v.map(function (p) { return String(p.id); }).indexOf(dragId), to = v.map(function (p) { return String(p.id); }).indexOf(c.dataset.id);
    if (from < 0 || to < 0) return; var item = v.splice(from, 1)[0]; v.splice(to, 0, item); saveOrder(v);
  });
  $("gGrid2").addEventListener("dragend", function () { dragId = null; Array.prototype.forEach.call(document.querySelectorAll(".gc"), function (x) { x.classList.remove("drag", "over"); }); });
  $("gfCat").onchange = renderGal; $("gfStat").onchange = renderGal;

  /* categories */
  function catsModal() {
    openModal('<button type="button" class="mclose">Close</button><h2>Gallery categories</h2><p class="msg" style="font-weight:500">Rename, reorder, add or delete. To move images between categories use Edit on the image.</p><div id="cList">' +
      GC.map(function (c) { var n = GP.filter(function (p) { return p.cat === c.slug; }).length; return '<div class="crow" data-slug="' + esc(c.slug) + '"><input class="cn" value="' + esc(c.name) + '" maxlength="60" aria-label="Category name"><input class="co" type="number" value="' + (c.sort_order || 0) + '" aria-label="Order"><button type="button" class="ib" data-c="save">Save</button><button type="button" class="ib red" data-c="del" title="' + n + ' images">Delete (' + n + ")</button></div>"; }).join("") +
      '</div><h2 style="font-size:16px;margin-top:18px">Add category</h2><div class="crow"><input id="ncName" placeholder="Category name" maxlength="60" aria-label="New category name"><input id="ncOrd" type="number" value="' + (GC.length * 10 + 10) + '" aria-label="Order"><button type="button" class="ib" id="ncAdd">Add</button><span></span></div>');
  }
  $("gCats").onclick = catsModal;
  $("modalBox").addEventListener("click", function (e) {
    var b = e.target.closest("[data-c],#ncAdd"); if (!b) return;
    if (b.id === "ncAdd") {
      var name = $("ncName").value.trim(); if (!name) return toast("Enter a category name.", "err");
      var slug = slugify(name), base = slug, k = 2; while (GC.some(function (c) { return c.slug === slug; })) slug = base + "-" + k++;
      return api("/rest/v1/gallery_categories", { method: "POST", headers: { "Content-Type": "application/json", Prefer: "return=minimal" }, body: JSON.stringify({ slug: slug, name: name, sort_order: parseInt($("ncOrd").value, 10) || 0 }) })
        .then(function (r) { if (!r.ok) throw new Error("Could not add category"); toast("Category added", "ok"); return loadGal(); }).then(catsModal).catch(function (er) { toast(er.message, "err"); });
    }
    var row = b.closest(".crow"), slug2 = row.dataset.slug;
    if (b.dataset.c === "save") {
      var nm = row.querySelector(".cn").value.trim(); if (!nm) return toast("Name cannot be empty.", "err");
      api("/rest/v1/gallery_categories?slug=eq." + encodeURIComponent(slug2), { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: nm, sort_order: parseInt(row.querySelector(".co").value, 10) || 0 }) })
        .then(function (r) { if (!r.ok) throw new Error("Could not save"); toast("Category saved", "ok"); return loadGal(); }).catch(function (er) { toast(er.message, "err"); });
    } else {
      var n = GP.filter(function (p) { return p.cat === slug2; }).length;
      if (n) return toast("This category has " + n + " image(s). Move them to another category first (Edit image).", "err");
      if (!confirm("Delete this category?")) return;
      api("/rest/v1/gallery_categories?slug=eq." + encodeURIComponent(slug2), { method: "DELETE" }).then(function (r) { if (!r.ok) throw new Error("Could not delete"); toast("Category deleted", "ok"); return loadGal(); }).then(catsModal).catch(function (er) { toast(er.message, "err"); });
    }
  });

  /* import the 30 built-in photos (images/gallery/ (N).jpg) so they can be managed here too */
  $("gImport").onclick = function () {
    if (!confirm("Import the 30 existing website photos into the gallery manager? After this, the gallery page shows only photos managed here.")) return;
    var rows = []; for (var i = 1; i <= 30; i++) rows.push({ src: "/images/gallery/ (" + i + ").jpg", cat: "project", title: "SunGET project", alt: "SunGET project photo " + i, sort_order: 1000 + i * 10, published: true });
    api("/rest/v1/photos", { method: "POST", headers: { "Content-Type": "application/json", Prefer: "return=minimal" }, body: JSON.stringify(rows) })
      .then(function (r) { if (!r.ok) throw new Error("Import failed (" + r.status + ")"); return api("/rest/v1/page_content?on_conflict=page,key", { method: "POST", headers: { "Content-Type": "application/json", Prefer: "resolution=merge-duplicates,return=minimal" }, body: JSON.stringify({ page: "_gallery", key: "imported", kind: "flag", value: "1" }) }); })
      .then(function () { toast("30 photos imported", "ok"); return loadGal(); }).catch(function (e) { toast(e.message, "err"); });
  };

  /* =====================  PAGES: CONTENT & IMAGES  ===================== */
  /* The page's own text and pictures are read from the page file. Same rule is used by sg-content.js on the website. */
  var PAGES = [["index", "Home page", "../index.html"], ["about_us", "About us", "about_us.html"], ["solar-rooftop", "Solar Rooftop", "solar-rooftop.html"],
    ["solar-water-heater", "Solar Water Heater", "solar-water-heater.html"], ["heat-pump", "Heat Pump", "heat-pump.html"],
    ["solar-utility-products", "Solar Utility Products", "solar-utility-products.html"], ["solar-epc", "Solar EPC", "solar-epc.html"],
    ["o-and-m-repair", "O&M Repair", "o-and-m-repair.html"], ["energy-audit", "Energy Audit", "energy-audit.html"],
    ["csr-and-awareness", "CSR and Awareness", "csr-and-awareness.html"], ["esg", "ESG", "esg.html"], ["careers", "Careers", "careers.html"],
    ["certifications", "Certifications", "certifications.html"], ["privacy-policy", "Privacy Policy", "privacy-policy.html"]];
  var NAMES = { h1: "Main heading", h2: "Heading", h3: "Sub-heading", h4: "Small heading", p: "Paragraph", img: "Picture" };
  var curPage = null;
  function initPages() {
    $("pgLiveNote").hidden = window.SG_CONTENT_ENABLED === true;
    $("pageSel").innerHTML = PAGES.map(function (p) { return '<option value="' + p[0] + '">' + esc(p[1]) + "</option>"; }).join("");
    $("pageSel").onchange = loadPage; loadPage();
  }
  function loadPage() {
    var p = PAGES[$("pageSel").selectedIndex]; curPage = p[0];
    $("pgList").innerHTML = ""; say("pgMsg", "Loading page...");
    var pageUrl = new URL(p[2], location.href).href;
    Promise.all([
      fetch(pageUrl).then(function (r) { if (!r.ok) throw new Error("Cannot open " + p[2] + " (" + r.status + "). Keep sun.html in the pgs folder with the other pages."); return r.text(); }),
      api("/rest/v1/page_content?page=eq." + encodeURIComponent(curPage) + "&select=key,value").then(function (r) { return r.json(); })
    ]).then(function (res) {
      var doc = new DOMParser().parseFromString(res[0], "text/html"), root = doc.querySelector("main") || doc.body;
      var els = [].filter.call(root.querySelectorAll("h1,h2,h3,h4,p,img"), function (e) { return e.tagName === "IMG" || (e.children.length === 0 && e.textContent.trim()); });
      var saved = {}; (Array.isArray(res[1]) ? res[1] : []).forEach(function (r) { saved[r.key] = r.value; });
      if (!Array.isArray(res[1])) say("pgMsg", "Content table not found. " + SQL_HINT, "err"); else say("pgMsg", els.length + " items on this page.", "ok");
      $("pgList").innerHTML = els.map(function (e, i) {
        var tag = e.tagName.toLowerCase(), key = tag + ":" + i, has = saved[key] != null, h;
        if (tag === "img") {
          var orig = new URL(e.getAttribute("src") || "", pageUrl).href;
          h = '<img class="pv" src="' + esc(has ? saved[key] : orig) + '" alt=""><input type="file" accept="image/*" aria-label="Choose a new picture">';
        } else {
          h = '<textarea rows="' + (tag === "p" ? 3 : 1) + '" aria-label="' + NAMES[tag] + " " + (i + 1) + '">' + esc(has ? saved[key] : e.textContent.trim()) + "</textarea>";
        }
        return '<div class="pr" data-key="' + key + '" data-kind="' + (tag === "img" ? "image" : "text") + '"><div class="k">' + NAMES[tag] + " #" + (i + 1) + (has ? ' <span class="edited">edited</span>' : "") + "</div>" + h +
          '<div class="acts"><button type="button" class="sm" data-a="save">Save</button>' + (has ? '<button type="button" class="sec sm" data-a="reset">Reset to original</button>' : "") + "</div></div>";
      }).join("");
    }).catch(function (e) { say("pgMsg", e.message, "err"); });
  }
  $("pgList").onclick = function (e) {
    var b = e.target.closest("button[data-a]"); if (!b) return;
    var row = b.closest(".pr"), key = row.dataset.key, kind = row.dataset.kind;
    if (b.dataset.a === "reset") {
      return api("/rest/v1/page_content?page=eq." + encodeURIComponent(curPage) + "&key=eq." + encodeURIComponent(key), { method: "DELETE" }).then(loadPage);
    }
    b.disabled = true; say("pgMsg", "Saving...");
    Promise.resolve().then(function () {
      if (kind === "text") return row.querySelector("textarea").value;
      var f = row.querySelector("input[type=file]").files[0];
      if (!f) throw new Error("Choose a new picture first.");
      if (!okImg(f)) throw new Error("Only JPG, PNG, WebP or GIF images up to 25 MB are allowed.");
      return resize(f, 1600, 0.82).then(function (r) { return storageUpload("pages/" + curPage + "-" + key.replace(":", "") + "-" + Date.now() + ".webp", r.blob); });
    }).then(function (val) {
      return api("/rest/v1/page_content?on_conflict=page,key", { method: "POST", headers: { "Content-Type": "application/json", Prefer: "resolution=merge-duplicates,return=minimal" },
        body: JSON.stringify({ page: curPage, key: key, kind: kind, value: val, updated_at: new Date().toISOString() }) })
        .then(function (r) { if (!r.ok) throw new Error("Could not save (" + r.status + ")"); });
    }).then(function () {
      loadPage();
      setTimeout(function () { say("pgMsg", window.SG_CONTENT_ENABLED === true ? "Saved. It is live on the website." : "Saved (live editing is switched off, so the website does not show it yet).", "ok"); }, 700);
    }).catch(function (err) { say("pgMsg", err.message, "err"); }).then(function () { b.disabled = false; });
  };

  /* ================= UTILITY PRODUCTS: Supabase CRUD =================
     Uses the authenticated admin session. RLS must restrict writes on the
     utility tables to admins. Storage bucket required: products
     (public read, admin upload/delete). */
  var UP = [], UPC = [], UPE = [];
  function upMsg(t, cls) { say("upMsg", t, cls); }
  function upSlug(t) { return String(t || "").toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || ("product-" + Date.now()); }
  function upJson(v, fallback, label) {
    if (v == null || String(v).trim() === "") return fallback;
    try { return JSON.parse(v); } catch (e) { throw new Error("Invalid JSON in the " + (label || "features/specifications") + " field."); }
  }
  function upCSV(rows, filename) {
    if (!rows.length) return toast("Nothing to export", "err");
    var keys = Object.keys(rows[0]), quote = function (v) { var s = v == null ? "" : (typeof v === "object" ? JSON.stringify(v) : String(v)); return '"' + cell(s).replace(/"/g, '""') + '"'; };
    var csv = [keys.map(quote).join(",")].concat(rows.map(function (r) { return keys.map(function (k) { return quote(r[k]); }).join(","); })).join("\r\n");
    download(new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" }), filename);
  }
  function upStorageUpload(file, path) {
    return resize(file, 1800, 0.82).then(function (r) {
      return api("/storage/v1/object/products/" + path, { method: "POST", headers: { "Content-Type": "image/webp", "x-upsert": "true" }, body: r.blob }).then(function (resp) { if (!resp.ok) throw new Error("Product image upload failed (" + resp.status + "). Create the products storage bucket and check its policies."); return C.SUPABASE_URL + "/storage/v1/object/public/products/" + path; });
    });
  }
  function upLoadAll() {
    return Promise.all([
      api("/rest/v1/utility_categories?select=*&order=sort_order.asc").then(function (r) { if (!r.ok) throw new Error("Cannot load categories (" + r.status + ")"); return r.json(); }),
      api("/rest/v1/utility_products?select=*&order=sort_order.asc").then(function (r) { if (!r.ok) throw new Error("Cannot load products (" + r.status + ")"); return r.json(); })
    ]).then(function (x) { UPC = x[0] || []; UP = x[1] || []; });
  }
  function upFind(list, id) { return list.filter(function (x) { return String(x.id) === String(id); })[0]; }
  function upRender() {
    var catSel = $("upFilterCat"), old = catSel.value;
    catSel.innerHTML = '<option value="">All categories</option>' + UPC.map(function (c) { return '<option value="' + esc(c.id) + '">' + esc(c.name) + "</option>"; }).join(""); catSel.value = old;
    var q = $("upSearch").value.toLowerCase().trim(), cat = catSel.value, stat = $("upFilterStatus").value;
    var rows = UP.filter(function (p) { return (!cat || String(p.category_id) === cat) && (!stat || String(!!p.is_published) === stat) && (!q || [p.name, p.short_description, p.description].join(" ").toLowerCase().indexOf(q) > -1); });
    var published = UP.filter(function (p) { return p.is_published; }).length;
    $("upStats").innerHTML = '<div class="stat"><b>' + UP.length + '</b><span>Total products</span></div><div class="stat"><b>' + published + '</b><span>Published</span></div><div class="stat"><b>' + (UP.length - published) + '</b><span>Drafts</span></div><div class="stat"><b>' + UPC.length + "</b><span>Categories</span></div>";
    $("upBody").innerHTML = rows.map(function (p) {
      var c = upFind(UPC, p.category_id), id = esc(p.id);
      return "<tr><td>" + (p.image_url ? '<img class="up-thumb" src="' + esc(rel(p.image_url)) + '" alt="">' : "—") + "</td><td><b>" + esc(p.name) + "</b><br><small>" + esc(p.short_description || "") + "</small></td><td>" + esc(c ? c.name : "—") + "</td><td>" + esc(p.sort_order) + '</td><td><span class="pill ' + (p.is_published ? "published" : "draft") + '">' + (p.is_published ? "Published" : "Draft") + '</span></td><td class="nw"><button type="button" class="ib" data-up="edit" data-id="' + id + '">Edit</button><button type="button" class="ib" data-up="pub" data-id="' + id + '">' + (p.is_published ? "Unpublish" : "Publish") + '</button><button type="button" class="ib red" data-up="del" data-id="' + id + '">Delete</button></td></tr>';
    }).join("") || '<tr><td colspan="6">No products found. Add your first product.</td></tr>';
  }
  function loadUtilityProducts() { upMsg("Loading products..."); return upLoadAll().then(function () { upRender(); upMsg(UP.length + " products loaded.", "ok"); }).catch(function (e) { upMsg(e.message + " " + SQL_HINT, "err"); }); }
  function catOptionsUP(selected) { return UPC.map(function (c) { return '<option value="' + esc(c.id) + '"' + (String(c.id) === String(selected) ? " selected" : "") + ">" + esc(c.name) + "</option>"; }).join(""); }
  function upProductForm(p) {
    p = p || {};
    openModal('<button type="button" class="mclose">Close</button><h2>' + (p.id ? "Edit product" : "Add product") + '</h2><form id="upForm" novalidate>' +
      '<div class="row"><div><label for="pfName">Product name *</label><input id="pfName" name="name" required maxlength="160" value="' + esc(p.name) + '"></div>' +
      '<div><label for="pfCat">Category *</label><select id="pfCat" name="category_id" required><option value="">Select a category</option>' + catOptionsUP(p.category_id) + "</select>" +
      '<div style="display:flex;gap:8px;margin-top:8px"><input id="upNewCatName" placeholder="New category name" maxlength="60" aria-label="New category name"><button type="button" class="sec" id="upCreateCatInline">＋ Add category</button></div><small style="color:#777">You can create a category here without closing this form.</small></div></div>' +
      '<label for="pfShort">Short description</label><textarea id="pfShort" name="short_description" rows="2" maxlength="500">' + esc(p.short_description) + "</textarea>" +
      '<label for="pfDesc">Full description</label><textarea id="pfDesc" name="description" rows="4">' + esc(p.description) + "</textarea>" +
      '<div class="row"><div><label for="pfHl">Highlights (JSON array)</label><textarea id="pfHl" name="highlights" rows="4">' + esc(JSON.stringify(p.highlights || [], null, 2)) + '</textarea></div><div><label for="pfFt">Features (JSON array)</label><textarea id="pfFt" name="features" rows="4">' + esc(JSON.stringify(p.features || [], null, 2)) + "</textarea></div></div>" +
      '<div class="row"><div><label for="pfSp">Specifications (JSON object)</label><textarea id="pfSp" name="specifications" rows="4">' + esc(JSON.stringify(p.specifications || {}, null, 2)) + '</textarea></div><div><label for="pfAp">Applications (JSON array)</label><textarea id="pfAp" name="applications" rows="4">' + esc(JSON.stringify(p.applications || [], null, 2)) + "</textarea></div></div>" +
      '<div class="row"><div><label for="pfImg">Product images (you can select multiple)</label><input id="pfImg" type="file" name="image" accept="image/jpeg,image/png,image/webp" multiple></div><div><label for="pfOrd">Display order</label><input id="pfOrd" name="sort_order" type="number" value="' + (p.sort_order || 0) + '"><label><input name="is_published" type="checkbox" style="width:auto" ' + (p.is_published ? "checked" : "") + "> Published on website</label></div></div>" +
      (p.image_url ? '<p><img src="' + esc(rel(p.image_url)) + '" alt="" style="max-width:180px;max-height:120px;object-fit:cover;border-radius:8px"></p>' : "") +
      '<div id="upFormErr" class="msg err"></div><div class="macts"><button type="submit" id="upSave">Save product</button><button type="button" class="sec mclose">Cancel</button></div></form>');

    $("upCreateCatInline").onclick = function () {
      var input = $("upNewCatName"), name = input.value.trim(), btn = this;
      if (!name) return toast("Enter a category name.", "err");
      if (UPC.some(function (c) { return String(c.name).toLowerCase() === name.toLowerCase(); })) return toast("This category already exists.", "err");
      btn.disabled = true;
      api("/rest/v1/utility_categories", { method: "POST", headers: { "Content-Type": "application/json", Prefer: "return=representation" }, body: JSON.stringify({ name: name, slug: upSlug(name), sort_order: UPC.length * 10, is_active: true }) })
        .then(function (r) { if (!r.ok) return r.text().then(function (t) { throw new Error("Could not add category (" + r.status + "): " + t); }); return r.json(); })
        .then(function (rows) { var created = rows && rows[0]; if (created) { UPC.push(created); return null; } return upLoadAll(); })
        .then(function () {
          var selEl = $("upForm").elements.category_id;
          var added = UPC.filter(function (c) { return String(c.name).toLowerCase() === name.toLowerCase(); })[0];
          selEl.innerHTML = '<option value="">Select a category</option>' + catOptionsUP(added && added.id);
          input.value = ""; upRender(); toast("Category added. It is selected for this product.", "ok");
        }).catch(function (e) { toast(e.message, "err"); }).then(function () { btn.disabled = false; });
    };

    $("upForm").onsubmit = function (ev) {
      ev.preventDefault();
      var f = ev.target, b = $("upSave"), obj;
      if (!f.elements.name.value.trim()) { f.elements.name.focus(); return say("upFormErr", "Product name is required.", "err"); }
      if (!f.elements.category_id.value) { f.elements.category_id.focus(); return say("upFormErr", "Choose a category.", "err"); }
      try {
        obj = { name: f.elements.name.value.trim(), slug: upSlug(f.elements.name.value), category_id: f.elements.category_id.value || null, short_description: f.elements.short_description.value.trim(), description: f.elements.description.value.trim(),
          highlights: upJson(f.elements.highlights.value, [], "Highlights"), features: upJson(f.elements.features.value, [], "Features"), specifications: upJson(f.elements.specifications.value, {}, "Specifications"), applications: upJson(f.elements.applications.value, [], "Applications"),
          sort_order: parseInt(f.elements.sort_order.value, 10) || 0, is_published: f.elements.is_published.checked, updated_at: new Date().toISOString() };
      } catch (err) { return say("upFormErr", err.message, "err"); } // previously threw after disabling the button
      b.disabled = true; b.textContent = "Saving..."; say("upFormErr", "");
      var files = Array.prototype.slice.call(f.elements.image.files || []), productId = p.id, job = Promise.resolve();
      if (files.length) { job = job.then(function () { return upStorageUpload(files[0], Date.now() + "-" + upSlug(f.elements.name.value) + ".webp").then(function (url) { obj.image_url = url; }); }); }
      job.then(function () {
        var url = p.id ? "/rest/v1/utility_products?id=eq." + encodeURIComponent(p.id) : "/rest/v1/utility_products";
        return api(url, { method: p.id ? "PATCH" : "POST", headers: { "Content-Type": "application/json", Prefer: "return=representation" }, body: JSON.stringify(obj) }).then(function (r) {
          if (!r.ok) return r.text().then(function (t) { throw new Error("Save failed (" + r.status + "): " + t); });
          return r.json().then(function (rows) { if (!productId && rows && rows[0]) productId = rows[0].id; });
        });
      }).then(function () {
        if (!files.length || !productId) return;
        var chain = Promise.resolve();
        files.forEach(function (file, i) {
          chain = chain.then(function () {
            return upStorageUpload(file, Date.now() + "-" + i + "-" + upSlug(f.elements.name.value) + ".webp").then(function (url) {
              return api("/rest/v1/utility_product_images", { method: "POST", headers: { "Content-Type": "application/json", Prefer: "return=minimal" }, body: JSON.stringify({ product_id: productId, image_url: url, alt_text: f.elements.name.value, sort_order: i }) })
                .then(function (r) { if (!r.ok) throw new Error("Image uploaded but image record could not be saved (" + r.status + ")"); });
            });
          });
        });
        return chain;
      }).then(function () { closeModal(); toast("Product and images saved", "ok"); return loadUtilityProducts(); })
        .catch(function (e) { say("upFormErr", e.message, "err"); b.disabled = false; b.textContent = "Save product"; });
    };
  }
  $("upAdd").onclick = function () { upProductForm(null); };
  $("upRefresh").onclick = loadUtilityProducts; $("upSearch").oninput = upRender; $("upFilterCat").onchange = upRender; $("upFilterStatus").onchange = upRender;
  $("upBody").onclick = function (e) {
    var b = e.target.closest("button[data-up]"); if (!b) return; var p = upFind(UP, b.dataset.id); if (!p) return;
    if (b.dataset.up === "edit") upProductForm(p);
    if (b.dataset.up === "pub") api("/rest/v1/utility_products?id=eq." + encodeURIComponent(p.id), { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ is_published: !p.is_published, updated_at: new Date().toISOString() }) }).then(function (r) { if (!r.ok) throw new Error("Status update failed"); return loadUtilityProducts(); }).catch(function (er) { toast(er.message, "err"); });
    if (b.dataset.up === "del" && confirm('Delete product "' + p.name + '"? This also deletes its linked image records.')) api("/rest/v1/utility_products?id=eq." + encodeURIComponent(p.id), { method: "DELETE" }).then(function (r) { if (!r.ok) throw new Error("Delete failed"); return loadUtilityProducts(); }).then(function () { toast("Product deleted", "ok"); }).catch(function (er) { toast(er.message, "err"); });
  };
  $("upCats").onclick = function () {
    var list = UPC.map(function (c) { return c.name + " (" + c.slug + ")"; }).join("\n");
    var name = prompt("Add a category name. Existing categories:\n" + list); if (!name || !name.trim()) return;
    api("/rest/v1/utility_categories", { method: "POST", headers: { "Content-Type": "application/json", Prefer: "return=minimal" }, body: JSON.stringify({ name: name.trim(), slug: upSlug(name), sort_order: UPC.length * 10, is_active: true }) })
      .then(function (r) { if (!r.ok) throw new Error("Category add failed (" + r.status + ")"); toast("Category added", "ok"); return loadUtilityProducts(); }).catch(function (er) { toast(er.message, "err"); });
  };
  $("upExport").onclick = function () { upCSV(UP, "sunget-utility-products.csv"); };
  $("upImport").onchange = function () {
    var file = this.files[0], input = this; if (!file) return;
    var reader = new FileReader();
    reader.onload = function () {
      var lines = String(reader.result).replace(/^﻿/, "").split(/\r?\n/).filter(Boolean);
      if (lines.length < 2) return toast("CSV is empty", "err");
      var head = lines.shift().split(",").map(function (x) { return x.trim().replace(/^"|"$/g, ""); });
      var jobs = [], skipped = 0;
      lines.forEach(function (line, n) {
        var vals = line.match(/("(?:[^"]|"")*"|[^,]*)(,|$)/g) || [], row = {};
        head.forEach(function (k, i) { row[k] = (vals[i] || "").replace(/,$/, "").replace(/^"|"$/g, "").replace(/""/g, '"'); });
        if (!row.name || !row.category_id) { skipped++; return; }
        var body;
        try {
          body = { name: row.name, slug: row.slug || upSlug(row.name), category_id: row.category_id, short_description: row.short_description || "", description: row.description || "",
            highlights: upJson(row.highlights, []), features: upJson(row.features, []), specifications: upJson(row.specifications, {}), applications: upJson(row.applications, []),
            image_url: row.image_url || null, is_published: String(row.is_published) === "true", sort_order: parseInt(row.sort_order, 10) || 0 };
        } catch (e) { jobs.push(Promise.resolve({ ok: false, line: n + 2 })); return; }
        jobs.push(api("/rest/v1/utility_products", { method: "POST", headers: { "Content-Type": "application/json", Prefer: "return=minimal" }, body: JSON.stringify(body) })
          .then(function (r) { return { ok: r.ok, line: n + 2 }; }, function () { return { ok: false, line: n + 2 }; }));
      });
      Promise.all(jobs).then(function (res) {
        var ok = res.filter(function (r) { return r.ok; }).length, bad = res.filter(function (r) { return !r.ok; });
        toast(ok + " product(s) imported" + (bad.length ? ", " + bad.length + " failed (rows " + bad.map(function (r) { return r.line; }).join(", ") + ")" : "") + (skipped ? ", " + skipped + " skipped (no name/category_id)" : ""), bad.length ? "err" : "ok");
        return loadUtilityProducts();
      });
    };
    reader.readAsText(file);
    input.value = "";
  };
  function loadUtilityEnquiries() {
    say("upeMsg", "Loading enquiries...");
    return api("/rest/v1/utility_product_enquiries?select=*&order=created_at.desc").then(function (r) { if (!r.ok) throw new Error("Cannot load product enquiries (" + r.status + ")"); return r.json(); }).then(function (rows) {
      UPE = rows || []; var counts = { new: 0, pending: 0, contacted: 0, completed: 0 };
      UPE.forEach(function (x) { if (counts[x.status] != null) counts[x.status]++; });
      $("upeStats").innerHTML = '<div class="stat"><b>' + UPE.length + "</b><span>Total product enquiries</span></div>" + Object.keys(counts).map(function (k) { return '<div class="stat"><b>' + counts[k] + "</b><span>" + k + "</span></div>"; }).join("");
      upeRender(); say("upeMsg", UPE.length + " enquiries loaded.", "ok");
    }).catch(function (e) { say("upeMsg", e.message + " " + SQL_HINT, "err"); });
  }
  function upeRender() {
    var q = $("upeSearch").value.toLowerCase().trim(), st = $("upeStatus").value;
    var rows = UPE.filter(function (x) { return (!st || x.status === st) && (!q || [x.name, x.phone, x.product_name, x.email].join(" ").toLowerCase().indexOf(q) > -1); });
    $("upeBody").innerHTML = rows.map(function (x) {
      var id = esc(x.id);
      return "<tr><td>" + esc(whenShort(x.created_at)) + "</td><td>" + esc(x.name) + "</td><td>" + esc(x.phone) + (x.email ? "<br>" + esc(x.email) : "") + "</td><td>" + esc(x.product_name) + "</td><td>" + esc(x.message || "") + '</td><td><select data-uestatus="' + id + '" aria-label="Status">' + STATUSES.map(function (k) { return "<option" + (x.status === k ? " selected" : "") + ">" + k + "</option>"; }).join("") + '</select></td><td><button type="button" class="ib red" data-uedelete="' + id + '">Delete</button></td></tr>';
    }).join("") || '<tr><td colspan="7">No product enquiries found.</td></tr>';
  }
  $("upeSearch").oninput = upeRender; $("upeStatus").onchange = upeRender; $("upeRefresh").onclick = loadUtilityEnquiries; $("upeExport").onclick = function () { upCSV(UPE, "sunget-product-enquiries.csv"); };
  $("upeBody").onchange = function (e) { var id = e.target.dataset.uestatus; if (!id) return; api("/rest/v1/utility_product_enquiries?id=eq." + encodeURIComponent(id), { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: e.target.value }) }).then(function (r) { if (!r.ok) throw new Error("Status update failed"); toast("Enquiry status updated", "ok"); return loadUtilityEnquiries(); }).catch(function (er) { toast(er.message, "err"); }); };
  $("upeBody").onclick = function (e) { var id = e.target.dataset.uedelete; if (!id || !confirm("Delete this enquiry?")) return; api("/rest/v1/utility_product_enquiries?id=eq." + encodeURIComponent(id), { method: "DELETE" }).then(function (r) { if (!r.ok) throw new Error("Delete failed"); return loadUtilityEnquiries(); }).catch(function (er) { toast(er.message, "err"); }); };

  /* ===================== CAREERS & PLACEMENT ===================== */
  var CAR = [], PLC = [], CST = STATUSES;
  function loadCareers() {
    say("crMsg", "Loading...");
    return Promise.all([
      api("/rest/v1/career_applications?select=*&order=created_at.desc").then(function (r) { return r.json(); }),
      api("/rest/v1/placement_requests?select=*&order=created_at.desc").then(function (r) { return r.json(); })
    ]).then(function (x) {
      if (!Array.isArray(x[0]) || !Array.isArray(x[1])) throw new Error("Careers tables could not be read. " + SQL_HINT);
      CAR = x[0]; PLC = x[1]; renderCareers(); say("crMsg", CAR.length + " applications, " + PLC.length + " institutions.", "ok");
    }).catch(function (e) { say("crMsg", e.message, "err"); });
  }
  function stSel(t, id, cur) { return '<select data-cst="' + t + '" data-id="' + esc(id) + '" aria-label="Status">' + CST.map(function (s) { return "<option" + (s === cur ? " selected" : "") + ">" + s + "</option>"; }).join("") + "</select>"; }
  function renderCareers() {
    var q = $("crSearch").value.toLowerCase().trim();
    var hit = function (o) { return !q || JSON.stringify(o).toLowerCase().indexOf(q) > -1; };
    var newC = CAR.filter(function (x) { return x.status === "new"; }).length, newP = PLC.filter(function (x) { return x.status === "new"; }).length;
    $("crStats").innerHTML = [["Applications", CAR.length], ["New applications", newC], ["Institutions", PLC.length], ["New institutions", newP]].map(function (s) { return '<div class="stat"><b>' + s[1] + "</b><span>" + s[0] + "</span></div>"; }).join("");
    $("crBody").innerHTML = CAR.filter(hit).map(function (x) {
      var id = esc(x.id);
      return "<tr><td>" + esc(whenShort(x.created_at)) + "</td><td><b>" + esc(x.name) + "</b><br><small>" + esc(x.phone) + "<br>" + esc(x.email) + "<br>" + esc(x.city || "") + "</small></td><td>" + esc(x.role || "-") + "<br><small>" + esc(x.experience || "") + "</small></td><td>" + esc(x.qualification || "-") + "<br><small>" + esc(x.college || "") + " " + esc(x.passing_year || "") + '</small></td><td style="max-width:220px">' + esc(x.message || "") + "</td><td>" + stSel("career_applications", x.id, x.status) + '</td><td class="nw">' +
        (x.resume_path ? '<button type="button" class="ib" data-cr="resume" data-id="' + id + '">Resume</button>' : "") + (x.phone ? '<a class="ib" href="tel:' + esc(x.phone) + '" aria-label="Call">☎</a>' : "") + '<button type="button" class="ib red" data-cr="del" data-t="career_applications" data-id="' + id + '">Delete</button></td></tr>';
    }).join("") || '<tr><td colspan="7">No applications yet.</td></tr>';
    $("plBody").innerHTML = PLC.filter(hit).map(function (x) {
      var id = esc(x.id);
      return "<tr><td>" + esc(whenShort(x.created_at)) + "</td><td><b>" + esc(x.institution) + "</b><br><small>" + esc(x.inst_type || "") + " " + esc(x.city || "") + "</small></td><td>" + esc(x.contact_name) + "<br><small>" + esc(x.designation || "") + "<br>" + esc(x.phone) + "<br>" + esc(x.email) + "</small></td><td>" + esc(x.courses || "-") + "<br><small>" + esc(x.students || "") + "</small></td><td>" + esc(x.mode || "-") + "<br><small>" + esc(x.message || "") + "</small></td><td>" + stSel("placement_requests", x.id, x.status) + '</td><td class="nw">' +
        (x.phone ? '<a class="ib" href="tel:' + esc(x.phone) + '" aria-label="Call">☎</a>' : "") + '<button type="button" class="ib red" data-cr="del" data-t="placement_requests" data-id="' + id + '">Delete</button></td></tr>';
    }).join("") || '<tr><td colspan="7">No institution requests yet.</td></tr>';
  }
  $("crSearch").oninput = renderCareers; $("crRefresh").onclick = loadCareers;
  $("v-careers").onchange = function (e) {
    var t = e.target.dataset.cst; if (!t || ["career_applications", "placement_requests"].indexOf(t) < 0) return;
    api("/rest/v1/" + t + "?id=eq." + encodeURIComponent(e.target.dataset.id), { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: e.target.value }) })
      .then(function (r) { if (!r.ok) throw new Error("Status update failed"); toast("Status updated", "ok"); return loadCareers(); }).catch(function (er) { toast(er.message, "err"); });
  };
  $("v-careers").onclick = function (e) {
    var b = e.target.closest("button[data-cr]"); if (!b) return;
    if (b.dataset.cr === "del") {
      var t = b.dataset.t; if (["career_applications", "placement_requests"].indexOf(t) < 0) return;
      if (!confirm("Delete this record permanently?")) return;
      var row = (t === "career_applications" ? CAR : PLC).filter(function (x) { return String(x.id) === b.dataset.id; })[0];
      api("/rest/v1/" + t + "?id=eq." + encodeURIComponent(b.dataset.id), { method: "DELETE" }).then(function (r) {
        if (!r.ok) throw new Error("Delete failed");
        if (row && row.resume_path) api("/storage/v1/object/resumes/" + encodeURIComponent(row.resume_path), { method: "DELETE" });
        toast("Deleted", "ok"); return loadCareers();
      }).catch(function (er) { toast(er.message, "err"); });
    } else if (b.dataset.cr === "resume") {
      var c = CAR.filter(function (x) { return String(x.id) === b.dataset.id; })[0]; if (!c) return;
      api("/storage/v1/object/authenticated/resumes/" + encodeURIComponent(c.resume_path)).then(function (r) { if (!r.ok) throw new Error("Could not open resume (" + r.status + ")"); return r.blob(); })
        .then(function (bl) { download(bl, (c.name || "resume").replace(/\W+/g, "_") + "-" + c.resume_path); })
        .catch(function (er) { toast(er.message, "err"); });
    }
  };

  /* ===================== OPEN ROLES (Careers page) ===================== */
  var RL = [];
  function loadRoles() {
    say("rlMsg", "Loading...");
    return api("/rest/v1/career_roles?select=*&order=sort_order.asc,created_at.desc")
      .then(function (r) { return r.json(); })
      .then(function (rows) {
        if (!Array.isArray(rows)) throw new Error("Table career_roles could not be read. " + SQL_HINT);
        RL = rows; renderRoles(); say("rlMsg", rows.length + " roles.", "ok");
      }).catch(function (e) { say("rlMsg", e.message, "err"); });
  }
  function renderRoles() {
    $("rlBody").innerHTML = RL.map(function (r) {
      var id = esc(r.id);
      return "<tr><td>" + esc(r.sort_order || 0) + "</td><td><b>" + esc(r.title) + "</b><br><small>" + esc(r.summary || "") + "</small></td><td>" + esc(r.department || "-") +
        '</td><td><span class="pill ' + (r.is_open ? "published" : "draft") + '">' + (r.is_open ? "Open" : "Closed") + "</span></td>" +
        '<td class="nw"><button type="button" class="ib" data-rl="edit" data-id="' + id + '">Edit</button><button type="button" class="ib" data-rl="tog" data-id="' + id + '">' + (r.is_open ? "Close" : "Reopen") +
        '</button><button type="button" class="ib red" data-rl="del" data-id="' + id + '">Delete</button></td></tr>';
    }).join("") || '<tr><td colspan="5">No roles yet. Click ADD ROLE.</td></tr>';
  }
  function roleForm(r) {
    r = r || {};
    openModal('<button type="button" class="mclose">Close</button><h2>' + (r.id ? "Edit role" : "Add role") + '</h2><form id="rlForm" novalidate>' +
      '<label for="rfTitle">Role title *</label><input id="rfTitle" name="title" maxlength="120" value="' + esc(r.title) + '">' +
      '<div class="row"><div><label for="rfDept">Department / label</label><input id="rfDept" name="department" maxlength="60" placeholder="Engineering" value="' + esc(r.department) + '"></div>' +
      '<div><label for="rfOrd">Display order (small = first)</label><input id="rfOrd" name="sort_order" type="number" value="' + (r.sort_order || 0) + '"></div></div>' +
      '<label for="rfSum">Short description</label><textarea id="rfSum" name="summary" rows="2" maxlength="300">' + esc(r.summary) + "</textarea>" +
      '<label for="rfReq">Requirements (one per line)</label><textarea id="rfReq" name="requirements" rows="4">' + esc(r.requirements) + "</textarea>" +
      '<label for="rfOpen">Status</label><select id="rfOpen" name="is_open"><option value="true"' + (r.is_open !== false ? " selected" : "") + '>Open (visible)</option><option value="false"' + (r.is_open === false ? " selected" : "") + ">Closed (hidden)</option></select>" +
      '<p class="msg err" id="rlErr"></p><div class="macts"><button type="submit" id="rlSave">Save role</button><button type="button" class="sec mclose" style="float:none">Cancel</button></div></form>');
    $("rlForm").onsubmit = function (ev) {
      ev.preventDefault(); var f = ev.target;
      if (!f.elements.title.value.trim()) return say("rlErr", "Role title is required.", "err");
      var obj = { title: f.elements.title.value.trim(), department: f.elements.department.value.trim(), summary: f.elements.summary.value.trim(),
        requirements: f.elements.requirements.value.trim(), sort_order: parseInt(f.elements.sort_order.value, 10) || 0, is_open: f.elements.is_open.value === "true" };
      var b = $("rlSave"); busy(b, true, "Saving...");
      api("/rest/v1/career_roles" + (r.id ? "?id=eq." + encodeURIComponent(r.id) : ""), { method: r.id ? "PATCH" : "POST", headers: { "Content-Type": "application/json", Prefer: "return=minimal" }, body: JSON.stringify(obj) })
        .then(function (x) { if (!x.ok) throw new Error("Could not save (" + x.status + ")"); toast("Role saved", "ok"); closeModal(); return loadRoles(); })
        .catch(function (e) { say("rlErr", e.message, "err"); busy(b, false); });
    };
  }
  $("rlAdd").onclick = function () { roleForm(null); };
  $("rlRefresh").onclick = loadRoles;
  $("rlBody").onclick = function (e) {
    var b = e.target.closest("button[data-rl]"); if (!b) return;
    var r = RL.filter(function (x) { return String(x.id) === b.dataset.id; })[0]; if (!r) return;
    if (b.dataset.rl === "edit") roleForm(r);
    else if (b.dataset.rl === "tog")
      api("/rest/v1/career_roles?id=eq." + encodeURIComponent(r.id), { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ is_open: !r.is_open }) })
        .then(function (x) { if (!x.ok) throw new Error("Update failed"); toast(r.is_open ? "Role closed" : "Role reopened", "ok"); return loadRoles(); }).catch(function (er) { toast(er.message, "err"); });
    else if (b.dataset.rl === "del" && confirm('Delete "' + r.title + '" permanently?'))
      api("/rest/v1/career_roles?id=eq." + encodeURIComponent(r.id), { method: "DELETE" })
        .then(function (x) { if (!x.ok) throw new Error("Delete failed"); toast("Role deleted", "ok"); return loadRoles(); }).catch(function (er) { toast(er.message, "err"); });
  };

  show();
})();
