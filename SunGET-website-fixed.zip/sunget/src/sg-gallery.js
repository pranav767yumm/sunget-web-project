/* =========================================================
   GALLERY LOADER (src/sg-gallery.js)  - NOT CURRENTLY USED

   pgs/gallery.html now has its own asynchronous loader built in, so
   this file is not included on any page. It is kept so nothing that
   referenced it breaks. The old version used a *synchronous*
   XMLHttpRequest, which froze the page while it waited for Supabase;
   this version is asynchronous and fires a "sunget:gallery-ready"
   event on the grid when it has added the photos.
   ========================================================= */
(function () {
  "use strict";
  var c = window.SG_CONFIG || {};
  var g = document.getElementById("gGrid");
  if (!g || !c.SUPABASE_URL || !c.SUPABASE_ANON_KEY) return;

  function esc(t) {
    return String(t == null ? "" : t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  fetch(c.SUPABASE_URL + "/rest/v1/photos?select=*&published=eq.true&order=sort_order.asc,created_at.desc", {
    headers: { apikey: c.SUPABASE_ANON_KEY }
  })
    .then(function (r) { if (!r.ok) throw new Error("photos " + r.status); return r.json(); })
    .then(function (rows) {
      if (!rows.length) return;
      g.insertAdjacentHTML("afterbegin", rows.map(function (p) {
        return '<button type="button" class="g-item" data-cat="' + esc(p.cat) + '" data-full="' + esc(p.src) + '">' +
          '<img src="' + esc(p.thumb || p.src) + '" alt="' + esc(p.alt || p.title) + '" loading="lazy" decoding="async" />' +
          '<span class="g-zoom" aria-hidden="true">+</span>' +
          '<span class="g-cap"><strong>' + esc(p.title) + "</strong><em>" + esc(p.description || p.place || "") + "</em></span></button>";
      }).join(""));
      g.dispatchEvent(new CustomEvent("sunget:gallery-ready"));
    })
    .catch(function () { /* if anything fails, the normal gallery still shows */ });
})();
