"""Usage: pip install playwright && python3 tools/test_site.py   (needs Google Chrome or `playwright install chromium`)

Browser tests for the corrected SunGET site.
Runs headless Chrome against a local static server. All Supabase calls are
intercepted and answered by mocks (no real database is touched); every other
external request (fonts, Unsplash, CDNs) is answered with an empty response so
the tests do not depend on the network. Missing local images (the images/
folder is not part of the project) are expected 404s and are reported
separately from real errors."""
import json, re, sys, threading, http.server, functools, pathlib, time
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
SHOTS = ROOT / "tools" / "test-shots"; SHOTS.mkdir(parents=True, exist_ok=True)
PORT = 8765
BASE = f"http://127.0.0.1:{PORT}"
SUPA = "lsfwdoyqxlblvxlxwmbi.supabase.co"

class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
srv = http.server.ThreadingHTTPServer(("127.0.0.1", PORT), functools.partial(Quiet, directory=str(ROOT)))
threading.Thread(target=srv.serve_forever, daemon=True).start()

PAGES = ["index.html"] + ["pgs/" + p.name for p in sorted((ROOT / "pgs").glob("*.html"))]
results = []   # (test, ok, detail)
def rec(name, ok, detail=""):
    results.append((name, bool(ok), detail)); print(("PASS " if ok else "FAIL ") + name + (" — " + detail if detail else ""))

state = {"mode": "ok", "posts": []}
ROLES = [{"id": 1, "title": "Solar Design Engineer", "department": "Engineering", "summary": "Design rooftop plants", "requirements": "AutoCAD\nPVsyst", "is_open": True}]
PRODUCTS = [{"id": "p1", "name": "Solar Street Light", "category_id": "c1", "short_description": "All-in-one 30W", "description": "Full description", "highlights": ["Auto dusk-dawn"], "features": ["IP65"], "specifications": {"Power": "30 W"}, "applications": ["Roads"], "is_published": True, "sort_order": 1, "image_url": "javascript:alert(1)"}]
PCATS = [{"id": "c1", "name": "Lighting", "is_active": True}]

def supabase(route, request):
    url = request.url; method = request.method
    if state["mode"] == "fail" and method == "POST":
        return route.fulfill(status=500, body='{"message":"mock failure"}', content_type="application/json")
    if method == "POST":
        try: body = request.post_data_json
        except Exception: body = request.post_data
        state["posts"].append({"url": url, "body": body, "headers": request.headers})
        if "/auth/v1/token" in url:
            return route.fulfill(status=200, content_type="application/json", body=json.dumps({"access_token": "test-jwt", "user": {"email": "a@b.c"}}))
        return route.fulfill(status=201, body="", headers={"access-control-allow-origin": "*"})
    if "/rest/v1/career_roles" in url: data = ROLES
    elif "/rest/v1/utility_products" in url: data = PRODUCTS
    elif "/rest/v1/utility_categories" in url: data = PCATS
    else: data = []
    return route.fulfill(status=200, content_type="application/json", body=json.dumps(data), headers={"access-control-allow-origin": "*"})

def external(route, request):
    u = request.url
    if SUPA in u: return supabase(route, request)
    if u.startswith(BASE): return route.continue_()
    ct = "text/css" if "css" in u else ("application/javascript" if u.endswith(".js") else "image/svg+xml")
    body = "" if ct != "image/svg+xml" else '<svg xmlns="http://www.w3.org/2000/svg" width="4" height="3"/>'
    return route.fulfill(status=200, body=body, content_type=ct)

def new_page(ctx):
    pg = ctx.new_page()
    pg.errors, pg.missing = [], []
    pg.on("pageerror", lambda e: pg.errors.append("pageerror: " + str(e)))
    def on_console(m):
        if m.type == "error" and "Failed to load resource" not in m.text: pg.errors.append("console: " + m.text)
    pg.on("console", on_console)
    pg.on("response", lambda r: pg.missing.append(r.url) if r.status == 404 else None)
    pg.route("**/*", external)
    return pg

with sync_playwright() as p:
    browser = p.chromium.launch(**({"executable_path": "/usr/bin/google-chrome"} if pathlib.Path("/usr/bin/google-chrome").exists() else {}), headless=True, args=["--no-sandbox"])

    # ---------- 1. every page loads without JS errors, desktop + mobile ----------
    img404 = set(); other404 = set()
    for vp_name, vp in [("desktop", {"width": 1366, "height": 900}), ("tablet", {"width": 820, "height": 1100}), ("mobile", {"width": 390, "height": 844})]:
        ctx = browser.new_context(viewport=vp, is_mobile=(vp_name == "mobile"), has_touch=(vp_name != "desktop"))
        for path in PAGES:
            pg = new_page(ctx)
            pg.goto(f"{BASE}/{path}", wait_until="load"); pg.wait_for_timeout(600)
            overflow = pg.evaluate("document.documentElement.scrollWidth - window.innerWidth")
            for u in pg.missing: (img404 if "/images/" in u else other404).add(u.replace(BASE, ""))
            rec(f"load {path} [{vp_name}]", not pg.errors and overflow <= 1, "; ".join(pg.errors) + (f" horizontal overflow {overflow}px" if overflow > 1 else ""))
            if path in ("index.html", "pgs/solar-rooftop.html", "pgs/gallery.html", "pgs/careers.html", "pgs/solar-utility-products.html", "pgs/about_us.html"):
                pg.screenshot(path=str(SHOTS / f"{path.replace('/', '_')}-{vp_name}.png"), full_page=False)
            pg.close()
        ctx.close()
    rec("no missing local files other than images/", not other404, ", ".join(sorted(other404)))

    # ---------- 2. mobile menu + calculator ----------
    ctx = browser.new_context(viewport={"width": 390, "height": 844}, is_mobile=True, has_touch=True)
    for path in ["index.html", "pgs/heat-pump.html", "pgs/privacy-policy.html", "pgs/solar-utility-products.html"]:
        pg = new_page(ctx); pg.goto(f"{BASE}/{path}"); pg.wait_for_timeout(300)
        pg.click("#menuToggle"); pg.wait_for_timeout(350)
        opened = pg.evaluate("(() => { const m = document.getElementById('mobileMenu'); return (m.classList.contains('active') || m.classList.contains('open')) && m.getBoundingClientRect().height > 50 })()")
        exp = pg.get_attribute("#menuToggle", "aria-expanded")
        pg.keyboard.press("Escape"); pg.wait_for_timeout(300)
        closed = pg.evaluate("!document.getElementById('mobileMenu').classList.contains('active')")
        rec(f"mobile menu opens/closes {path}", opened and exp == "true" and closed and not pg.errors, "; ".join(pg.errors))
        # links inside the mobile menu resolve to real files
        hrefs = pg.eval_on_selector_all("#mobileMenu a[href]", "els => els.map(e => e.href)")
        bad = [h for h in hrefs if h.startswith(BASE) and not (ROOT / h.replace(BASE + "/", "").split("#")[0]).exists()]
        rec(f"mobile menu links valid {path}", not bad, ", ".join(bad))
        pg.close()
    ctx.close()

    ctx = browser.new_context(viewport={"width": 1366, "height": 900})
    for path in ["index.html", "pgs/careers.html", "pgs/gallery.html"]:
        pg = new_page(ctx); pg.goto(f"{BASE}/{path}"); pg.wait_for_timeout(300)
        pg.click(".nav .open-calc-btn"); pg.wait_for_timeout(300)
        on = pg.evaluate("document.getElementById('calcModal').classList.contains('active')")
        wa_before = pg.get_attribute("#calcWaBtn", "aria-disabled")
        pg.fill("#calcMonthlyUnits", "300"); pg.click("#calcForm [type=submit]"); pg.wait_for_timeout(200)
        wa_after = pg.get_attribute("#calcWaBtn", "aria-disabled"); wa_href = pg.get_attribute("#calcWaBtn", "href") or ""
        wa_disabled = (wa_before, wa_after, wa_href[:40])
        pg.keyboard.press("Escape"); pg.wait_for_timeout(300)
        off = pg.evaluate("!document.getElementById('calcModal').classList.contains('active')")
        rec(f"calculator opens, computes, enables WhatsApp, Escape closes {path}", on and off and wa_before == "true" and wa_after is None and "wa.me/919881855770" in wa_href and not pg.errors, f"whatsapp-button-disabled-before-calc={wa_disabled}; " + "; ".join(pg.errors))
        pg.close()

    # ---------- 3. lead forms (success + failure) ----------
    lead_pages = [p for p in PAGES if 'data-sg-enquiry' in (ROOT / p).read_text()]
    for path in lead_pages:
        for mode in ("ok", "fail"):
            state["mode"] = mode; state["posts"].clear()
            pg = new_page(ctx); pg.goto(f"{BASE}/{path}"); pg.wait_for_timeout(300)
            url_before = pg.url
            f = "form[data-sg-enquiry]"
            pg.fill(f + " [name=name]", "Test Customer")
            pg.fill(f + " [name=phone]", "+91 98765 43210")
            if pg.query_selector(f + " [name=email]"): pg.fill(f + " [name=email]", "test@example.com")
            pg.click(f + " button[type=submit]"); pg.wait_for_timeout(900)
            toast = pg.evaluate("(() => { const t = document.getElementById('toast'); return t ? {text: t.textContent.trim(), err: t.classList.contains('is-error'), shown: getComputedStyle(t).display !== 'none' && getComputedStyle(t).visibility !== 'hidden'} : null })()")
            same_url = pg.url == url_before
            if mode == "ok":
                post = next((x for x in state["posts"] if "/rest/v1/enquiries" in x["url"]), None)
                body = post["body"] if post else {}
                ok = post and body.get("phone") == "9876543210" and body.get("name") == "Test Customer" and toast and toast["shown"] and not toast["err"] and same_url
                rec(f"lead form saves {path}", ok and not pg.errors, f"type={body.get('enquiry_type') if body else None} toast={toast and toast['text'][:50]!r} " + "; ".join(pg.errors))
            else:
                ok = toast and toast["shown"] and toast["err"] and same_url
                rec(f"lead form shows error on failure {path}", ok, f"toast={toast and toast['text'][:60]!r}")
            pg.close()
    state["mode"] = "ok"

    # validation: invalid phone must not post
    state["posts"].clear()
    pg = new_page(ctx); pg.goto(f"{BASE}/pgs/solar-rooftop.html"); pg.wait_for_timeout(300)
    pg.fill("form[data-sg-enquiry] [name=name]", "X Y"); pg.fill("form[data-sg-enquiry] [name=phone]", "12345")
    pg.click("form[data-sg-enquiry] button[type=submit]"); pg.wait_for_timeout(500)
    rec("lead form rejects invalid phone (no request sent)", not any("/enquiries" in x["url"] for x in state["posts"]))
    # honeypot
    pg.fill("form[data-sg-enquiry] [name=phone]", "9876543210"); pg.evaluate("document.querySelector('form[data-sg-enquiry] [name=website]').value='spam'")
    pg.click("form[data-sg-enquiry] button[type=submit]"); pg.wait_for_timeout(500)
    rec("lead form honeypot blocks bots (no request sent)", not any("/enquiries" in x["url"] for x in state["posts"]))
    # estimator form must not submit / navigate
    url0 = pg.url
    pg.evaluate("document.getElementById('rtEstimator').requestSubmit ? document.getElementById('rtEstimator').requestSubmit() : document.getElementById('rtEstimator').dispatchEvent(new Event('submit', {cancelable:true}))")
    pg.wait_for_timeout(400)
    rec("rooftop estimator does not submit/reload", pg.url == url0 and not any("/enquiries" in x["url"] for x in state["posts"]))
    pg.close()

    # rooftop subsidy pro-rata (PM Surya Ghar: 30k/kW up to 2 kW, 18k for 3rd kW, cap 78k); bill → kW at ₹9/unit, 120 units/kW
    pg = new_page(ctx); pg.goto(f"{BASE}/pgs/solar-rooftop.html"); pg.wait_for_timeout(300)
    got = {}
    for bill in ("1080", "2160", "2700", "3240", "5400", "4000"):
        pg.fill("#rtEstimator input[type=number]", bill); pg.dispatch_event("#rtEstimator input[type=number]", "input"); pg.wait_for_timeout(80)
        got[bill] = (pg.inner_text("#rtKw"), pg.inner_text("#rtSub"))
    want = {"1080": ("1 kW", "₹30,000"), "2160": ("2 kW", "₹60,000"), "2700": ("2.5 kW", "₹69,000"), "3240": ("3 kW", "₹78,000"), "5400": ("5 kW", "₹78,000")}
    ok = all(got[k] == v for k, v in want.items())
    rec("rooftop estimator size + subsidy (1/2/2.5/3/5 kW → 30k/60k/69k/78k/78k)", ok, json.dumps(got, ensure_ascii=False))
    pg.close()

    # tabs keyboard (rooftop)
    pg = new_page(ctx); pg.goto(f"{BASE}/pgs/solar-rooftop.html"); pg.wait_for_timeout(300)
    first = pg.query_selector(".rt-tab"); first.focus(); pg.keyboard.press("ArrowRight"); pg.wait_for_timeout(150)
    sel = pg.evaluate("(() => { const t = document.activeElement; return t.classList.contains('rt-tab') && t.getAttribute('aria-selected') === 'true' && !document.getElementById(t.getAttribute('aria-controls')).hidden })()")
    rec("service-page tabs work with arrow keys", sel)
    pg.close()

    # ---------- 4. index hero form ----------
    state["posts"].clear()
    pg = new_page(ctx); pg.goto(f"{BASE}/index.html"); pg.wait_for_timeout(400)
    pg.fill("#heroLeadForm [name=name]", "Hero Test"); pg.fill("#heroLeadForm [name=whatsapp]", "9876543210")
    pg.fill("#heroLeadForm [name=email]", "h@example.com"); pg.fill("#heroLeadForm [name=pincode]", "411041")
    pg.evaluate("document.querySelectorAll('#heroLeadForm input[name=bill]')[1].checked = true; document.querySelector('#heroLeadForm [name=terms_agree]').checked = true")
    consent_default = pg.evaluate("document.querySelector('#heroLeadForm [name=terms_agree]').defaultChecked")
    pg.click("#heroLeadForm button[type=submit]"); pg.wait_for_timeout(800)
    post = next((x for x in state["posts"] if "/rest/v1/enquiries" in x["url"]), None)
    msg = pg.inner_text("#heroFormMsg")
    rec("index hero form saves lead", post and post["body"].get("email") == "h@example.com" and "Thank you" in msg, msg[:80])
    rec("index consent checkbox is not pre-ticked", consent_default is False)
    pg.close()

    # ---------- 5. careers ----------
    state["posts"].clear()
    pg = new_page(ctx); pg.goto(f"{BASE}/pgs/careers.html"); pg.wait_for_timeout(600)
    roles_ok = "Solar Design Engineer" in pg.inner_text("#rolesGrid") and pg.evaluate("[...document.querySelectorAll('#careerForm select[name=role] option')].some(o => o.value === 'Solar Design Engineer')")
    rec("careers: open roles load into grid and select", roles_ok)
    f = "#careerForm "
    pg.fill(f + "[name=name]", "Cand"); pg.fill(f + "[name=phone]", "9876543210"); pg.fill(f + "[name=email]", "c@example.com")
    pg.select_option(f + "[name=qualification]", index=1); pg.select_option(f + "[name=experience]", index=1); pg.select_option(f + "[name=role]", index=1)
    pg.set_input_files(f + "[name=resume]", files=[{"name": "cv.exe", "mimeType": "application/octet-stream", "buffer": b"MZ"}])
    pg.check(f + "[name=consent]"); pg.click(f + "button[type=submit]"); pg.wait_for_timeout(400)
    rejected = "PDF or Word" in pg.inner_text("#careerForm .sg-msg") and not state["posts"]
    rec("careers: non-PDF/Word resume rejected before upload", rejected)
    pg.set_input_files(f + "[name=resume]", files=[{"name": "cv.pdf", "mimeType": "application/pdf", "buffer": b"%PDF-1.4"}])
    pg.click(f + "button[type=submit]"); pg.wait_for_timeout(800)
    up = any("/storage/v1/object/resumes/" in x["url"] for x in state["posts"]); sv = any("/rest/v1/career_applications" in x["url"] for x in state["posts"])
    rec("careers: application uploads resume and saves row", up and sv and "Thank you" in pg.inner_text("#careerForm .sg-msg"))
    pg.close()
    # roles failure fallback
    pg = new_page(ctx)
    pg.route(f"**/{SUPA}/rest/v1/career_roles*", lambda r, q: r.fulfill(status=500, body="{}"))
    pg.goto(f"{BASE}/pgs/careers.html"); pg.wait_for_timeout(600)
    rec("careers: roles load failure shows a message (not 'Loading…' forever)", "could not be loaded" in pg.inner_text("#rolesGrid"))
    pg.close()

    # ---------- 6. gallery ----------
    pg = new_page(ctx); pg.goto(f"{BASE}/pgs/gallery.html"); pg.wait_for_timeout(800)
    n = pg.evaluate("document.querySelectorAll('#gGrid .g-item').length")
    rec("gallery: falls back to 30 built-in photos when admin has none", n == 30, f"{n} items")
    srcs = pg.evaluate("[...document.querySelectorAll('#gGrid .g-item img')].slice(0,2).map(i => i.getAttribute('src'))")
    rec("gallery: built-in photo paths are relative to /pgs/", all(s.startswith("../images/gallery/") for s in srcs), str(srcs))
    pg.click("#gGrid .g-item >> nth=0"); pg.wait_for_timeout(200)
    o1 = pg.evaluate("document.getElementById('lb').classList.contains('open')")
    pg.keyboard.press("ArrowRight"); c2 = pg.inner_text("#lbCount")
    pg.keyboard.press("Escape"); pg.wait_for_timeout(100)
    o2 = pg.evaluate("document.getElementById('lb').classList.contains('open')")
    rec("gallery: lightbox opens, arrow-key navigates, Escape closes", o1 and c2.startswith("2 /") and not o2 and not pg.errors, c2 + " " + "; ".join(pg.errors))
    pg.close()
    pg = new_page(ctx)
    pg.route(f"**/{SUPA}/rest/v1/photos*", lambda r, q: r.fulfill(status=200, content_type="application/json", body=json.dumps([{"id": 9, "src": "javascript:alert(1)", "title": "bad"}, {"id": 8, "src": "https://example.com/a.jpg", "title": "Good <b>x</b>", "cat": "project"}])))
    pg.route(f"**/{SUPA}/rest/v1/page_content*", lambda r, q: r.fulfill(status=200, content_type="application/json", body='[{"value":"1"}]'))
    pg.goto(f"{BASE}/pgs/gallery.html"); pg.wait_for_timeout(800)
    info = pg.evaluate("({n: document.querySelectorAll('#gGrid .g-item').length, html: document.getElementById('gGrid').innerHTML})")
    rec("gallery: admin photos only after import; unsafe URLs dropped; titles escaped", info["n"] == 1 and "javascript:" not in info["html"] and "<b>x</b>" not in info["html"], f"{info['n']} items")
    pg.close()

    # ---------- 7. utility products ----------
    state["posts"].clear()
    pg = new_page(ctx); pg.goto(f"{BASE}/pgs/solar-utility-products.html"); pg.wait_for_timeout(700)
    html = pg.inner_html("#upGrid")
    rec("utility products: list renders from REST API (no supabase-js SDK)", "Solar Street Light" in html and "javascript:" not in html and not pg.evaluate("!!window.supabase"))
    pg.click("[data-details=p1] >> nth=0"); pg.wait_for_timeout(200)
    det = pg.evaluate("document.getElementById('upDetailOverlay').classList.contains('open')")
    pg.click("#upDetailContent [data-tab=specs]"); specs = pg.inner_text("#upTabPanel")
    rec("utility products: details dialog + specs tab", det and "30 W" in specs, specs[:40])
    pg.click("#upDetailContent [data-contact]"); pg.wait_for_timeout(150)
    pg.fill("#upName", "Buyer"); pg.fill("#upPhone", "98765"); pg.click("#upSubmit"); pg.wait_for_timeout(200)
    bad_phone = "valid" in pg.inner_text("#upFormMsg") and not state["posts"]
    pg.fill("#upPhone", "+91 98765 43210"); pg.click("#upSubmit"); pg.wait_for_timeout(600)
    post = next((x for x in state["posts"] if "utility_product_enquiries" in x["url"]), None)
    rec("utility products: enquiry validates phone, then saves with product name", bad_phone and post and post["body"]["product_name"] == "Solar Street Light" and post["body"]["phone"] == "9876543210", pg.inner_text("#upFormMsg"))
    pg.keyboard.press("Escape")
    toolbar_top = pg.evaluate("getComputedStyle(document.querySelector('.up-toolbar')).top")
    rec("utility products: sticky toolbar sits below nav", toolbar_top == "62px", toolbar_top)
    pg.close()

    # ---------- 8. certifications ----------
    pg = new_page(ctx); pg.goto(f"{BASE}/pgs/certifications.html"); pg.wait_for_timeout(300)
    pg.focus(".cert-preview-box >> nth=1"); pg.keyboard.press("Enter"); pg.wait_for_timeout(150)
    on = pg.evaluate("document.getElementById('lightboxModal').classList.contains('active') && document.getElementById('lightboxImg').getAttribute('src').endsWith('img2.png')")
    pg.keyboard.press("Escape"); pg.wait_for_timeout(100)
    off = pg.evaluate("!document.getElementById('lightboxModal').classList.contains('active')")
    focus_back = pg.evaluate("document.activeElement.classList.contains('cert-preview-box')")
    pg.click(".ps-btn[data-act=next]"); pg.wait_for_timeout(700)
    cnt = pg.inner_text(".ps-count")
    rec("certifications: keyboard-open certificate, Escape closes, focus returns; press stack advances", on and off and focus_back and cnt.startswith("Article 2"), cnt)
    pg.close()

    # ---------- 9. about ----------
    pg = new_page(ctx); pg.goto(f"{BASE}/pgs/about_us.html"); pg.wait_for_timeout(500)
    info = pg.evaluate("({team: document.querySelectorAll('#teamGrid > *').length, note: !!document.querySelector('.ab-note'), careers: document.querySelector('#careers .btn').getAttribute('href'), badsrc: [...document.images].filter(i => /\\/$/.test(i.getAttribute('src')||'')).length, abs: [...document.images].filter(i => (i.getAttribute('src')||'').startsWith('/images')).length})")
    rec("about: team renders, no internal edit note, careers button → careers.html, no broken/absolute image paths", info["team"] > 0 and not info["note"] and info["careers"] == "careers.html" and info["badsrc"] == 0 and info["abs"] == 0, json.dumps(info))
    pg.close()

    # ---------- 10. admin ----------
    state["posts"].clear()
    pg = new_page(ctx); pg.goto(f"{BASE}/pgs/sun.html"); pg.wait_for_timeout(300)
    pg.fill("#em", "admin@example.com"); pg.fill("#pw", "secret"); pg.press("#pw", "Enter"); pg.wait_for_timeout(800)
    app_visible = pg.evaluate("!document.getElementById('app').hidden")
    cards = pg.evaluate("document.querySelectorAll('#homeCards .hc').length")
    auth_hdr = any(x for x in state["posts"] if "/auth/v1/token" in x["url"])
    rec("admin: Enter key logs in (mocked auth) and dashboard renders", app_visible and cards == 10 and auth_hdr and not pg.errors, f"cards={cards} " + "; ".join(pg.errors))
    pg.click("aside .mi[data-v=pages]"); pg.wait_for_timeout(800)
    note = pg.evaluate("!document.getElementById('pgLiveNote').hidden"); items = pg.inner_text("#pgMsg")
    rec("admin: Pages editor loads page items and warns live editing is off", note and "items on this page" in items, items)
    pg.click("aside .gh >> nth=2"); pg.click("aside .mi[data-v=products]"); pg.wait_for_timeout(500)
    pg.click("#upAdd"); pg.fill("#pfName", "X"); pg.select_option("#pfCat", "c1"); pg.fill("#pfFt", "[not json"); pg.click("#upSave"); pg.wait_for_timeout(200)
    err = pg.inner_text("#upFormErr"); btn_ok = pg.evaluate("!document.getElementById('upSave').disabled")
    rec("admin: invalid JSON in product form shows error, button not stuck", "Invalid JSON" in err and btn_ok and not pg.errors, err)
    pg.close()

    ctx.close(); browser.close()

srv.shutdown()
passed = sum(1 for r in results if r[1]); print(f"\n{passed}/{len(results)} passed")
print("missing images (expected, images/ not in project):", len(img404))
json.dump({"results": results, "img404": sorted(img404)}, open(ROOT / "tools" / "test-results.json", "w"), indent=1)
