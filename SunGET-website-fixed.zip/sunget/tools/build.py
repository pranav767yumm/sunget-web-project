#!/usr/bin/env python3
"""Assemble the SunGET pages: inserts the shared head tags, navigation,
footer and toast into every page so they are identical and the links are
correct for the page's folder.

Usage (from the project root):  python3 tools/build.py
Edit the page sources in tools/pages/, never the generated index.html / pgs/*.html
(they are overwritten on every build). Pages without markers (pgs/sun.html) are copied as-is."""
import re, pathlib, html

SRC = pathlib.Path(__file__).parent / "pages"
OUT = pathlib.Path(__file__).resolve().parent.parent  # project root
SITE = "https://www.sungetsolarinfra.com"

HEAD = """<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="theme-color" content="#0b6b49" />
    <link rel="icon" href="{R}images/logo.png" />
    <link rel="canonical" href="{CANON}" />
    <meta property="og:type" content="website" />
    <meta property="og:site_name" content="SunGET Solar Infra" />
    <meta property="og:title" content="{TITLE}" />
    <meta property="og:description" content="{DESC}" />
    <meta property="og:url" content="{CANON}" />
    <meta property="og:image" content="{SITE}/images/logo.png" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&amp;family=Manrope:wght@600;700;800&amp;display=swap" rel="stylesheet" />"""

NAV = """<nav class="nav" aria-label="Main">
  <div class="container navin">
    <a href="{R}index.html" class="brand-link" aria-label="SunGET Solar Infra home">
      <img class="normal_logo" src="{R}images/logo.png" alt="SunGET Solar Infra Pvt. Ltd." />
    </a>

    <!-- Desktop Navigation Links -->
    <div class="links">
      <div class="dropdown">
        <button type="button" class="dropdown-toggle" aria-haspopup="true">Solutions <span class="caret" aria-hidden="true"></span></button>
        <div class="dropdown-menu">
          <a href="{P}solar-rooftop.html">Solar Rooftops</a>
          <a href="{P}solar-water-heater.html">Solar Water Heater</a>
          <a href="{P}heat-pump.html">Heat Pump</a>
          <a href="{P}solar-utility-products.html">Solar Utility Products</a>
          <a href="{P}solar-epc.html">Solar EPC</a>
          <a href="{P}o-and-m-repair.html">O&amp;M Repair</a>
          <a href="{P}energy-audit.html">Energy Audit</a>
          <a href="{P}esg.html">ESG Solutions</a>
          <a href="{P}csr-and-awareness.html">CSR and Awareness</a>
        </div>
      </div>

      <div class="dropdown">
        <button type="button" class="dropdown-toggle" aria-haspopup="true">About <span class="caret" aria-hidden="true"></span></button>
        <div class="dropdown-menu">
          <a href="{P}about_us.html">Our Team</a>
          <a href="{P}gallery.html">Project Gallery</a>
          <a href="{P}certifications.html">Certifications</a>
          <a href="{P}careers.html">Careers and Placement</a>
        </div>
      </div>

      <a href="{PROCESS}">Process</a>
      <a href="{CONTACT}">Contact</a>
      <a class="btn light open-calc-btn" href="#" role="button">Solar Calculator 🧮</a>
    </div>

    <!-- Hamburger Toggle Button -->
    <button class="hamburger-btn" id="menuToggle" type="button" aria-label="Toggle navigation menu" aria-expanded="false" aria-controls="mobileMenu">
      <span class="bar"></span>
      <span class="bar"></span>
      <span class="bar"></span>
    </button>
  </div>

  <!-- Mobile Menu -->
  <div class="mobile-menu" id="mobileMenu">
    <div class="container mobile-menu-inner">
      <div class="mobile-group">
        <div class="mobile-group-head">
          <a class="mobile-link">Solutions</a>
          <button class="mobile-sub-toggle" type="button" aria-label="Show Solutions options" aria-expanded="false"></button>
        </div>
        <div class="mobile-sub">
          <a href="{P}solar-rooftop.html">Solar Rooftops</a>
          <a href="{P}solar-water-heater.html">Solar Water Heater</a>
          <a href="{P}heat-pump.html">Heat Pump</a>
          <a href="{P}solar-utility-products.html">Solar Utility Products</a>
          <a href="{P}solar-epc.html">Solar EPC</a>
          <a href="{P}o-and-m-repair.html">O&amp;M Repair</a>
          <a href="{P}energy-audit.html">Energy Audit</a>
          <a href="{P}esg.html">ESG Solutions</a>
          <a href="{P}csr-and-awareness.html">CSR and Awareness</a>
        </div>
      </div>

      <div class="mobile-group">
        <div class="mobile-group-head">
          <a class="mobile-link" href="{P}about_us.html">About</a>
          <button class="mobile-sub-toggle" type="button" aria-label="Show About options" aria-expanded="false"></button>
        </div>
        <div class="mobile-sub">
          <a href="{P}about_us.html">Our Team</a>
          <a href="{P}gallery.html">Project Gallery</a>
          <a href="{P}certifications.html">Certifications</a>
          <a href="{P}careers.html">Careers and Placement</a>
        </div>
      </div>

      <a class="mobile-link" href="{PROCESS}">Process</a>
      <a class="mobile-link" href="{CONTACT}">Contact</a>
      <a class="btn light open-calc-btn" href="#" role="button">Solar Calculator 🧮</a>
      <a class="btn full" href="{CONTACT}" id="mobileCta">Get a Quote</a>
    </div>
  </div>
</nav>"""

FOOTER = """<footer class="sg-footer">
      <div class="container">
        <div class="sg-grid">
          <div class="sg-brand">
            <p>
              SunGET Solar Infra Pvt. Ltd. is a premier Pune-based solar energy company providing consultancy, EPC and audit services with excellence and a proven track record. Our mission is to create awareness, educate and contribute towards India's Net Zero 2070 goal.
            </p>
            <div class="sg-badges" aria-label="Certifications">
              <span class="sg-badge sg-badge--iso">
                <img src="{R}images/FOOTER%20(1).jpeg" alt="ISO certification logo" loading="lazy" />
              </span>
              <span class="sg-badge sg-badge--government">
                <img src="{R}images/FOOTER%20(2).jpeg" alt="Government approval logo" loading="lazy" />
              </span>
            </div>
            <div class="sg-follow">
              <span class="sg-follow-label">Follow Us</span>
              <div class="sg-social">
                <a href="https://www.facebook.com/sungetsolarinfra" target="_blank" rel="noopener noreferrer" aria-label="Facebook" title="Facebook">
                  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M14 8.5V6.8c0-.8.2-1.3 1.4-1.3H17V2.2C16.7 2.15 15.8 2 14.7 2 12.3 2 10.7 3.4 10.7 6.1v2.4H8v3.6h2.7V22H14v-9.9h2.7l.4-3.6H14z"/></svg>
                </a>
                <a href="https://www.instagram.com/sunget_solar_infra/" target="_blank" rel="noopener noreferrer" aria-label="Instagram" title="Instagram">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.3" cy="6.7" r="1.1" fill="currentColor" stroke="none"/></svg>
                </a>
                <a href="https://www.linkedin.com/company/sunget-solar-infra-private-limited" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn" title="LinkedIn">
                  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="2.5" y="9" width="4" height="12"/><circle cx="4.5" cy="4.8" r="2.2"/><path d="M10 9h3.8v1.7c.6-1.1 1.9-2 3.7-2 3.4 0 4.5 2.1 4.5 5.2V21h-4v-6c0-1.5-.4-2.6-1.9-2.6S14 13.5 14 15v6h-4z"/></svg>
                </a>
                <a href="https://www.youtube.com/@sungetsolarinfrapvt.ltd.9794" target="_blank" rel="noopener noreferrer" aria-label="YouTube" title="YouTube">
                  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M21.6 7.2a2.5 2.5 0 0 0-1.8-1.8C18.2 5 12 5 12 5s-6.2 0-7.8.4A2.5 2.5 0 0 0 2.4 7.2C2 8.8 2 12 2 12s0 3.2.4 4.8a2.5 2.5 0 0 0 1.8 1.8C5.8 19 12 19 12 19s6.2 0 7.8-.4a2.5 2.5 0 0 0 1.8-1.8C22 15.2 22 12 22 12s0-3.2-.4-4.8zM10 15V9l5.2 3z"/></svg>
                </a>
                <a href="https://wa.me/919881855770" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp" title="WhatsApp">
                  <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.6L3 21l4.5-1.2A9 9 0 1 0 12 3z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M9 8.5c.2 2.8 3 5.8 6.2 6.5l1.3-1.5-2.2-1.1-.9.8c-.9-.4-1.9-1.4-2.3-2.3l.8-.9-1.1-2.2z" fill="currentColor"/></svg>
                </a>
                <!-- X (Twitter): add your profile URL (e.g. https://x.com/yourhandle) and uncomment.
                <a href="https://x.com/YOUR_HANDLE" target="_blank" rel="noopener noreferrer" aria-label="X (Twitter)" title="X (Twitter)">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M4 4h4.5L20 20h-4.5z"/><path d="M4 20l6.8-7.6M20 4l-6.8 7.6" stroke-linecap="round"/></svg>
                </a> -->
              </div>
            </div>
          </div>

          <nav class="sg-col" aria-label="Quick links">
            <h4>Quick Links</h4>
            <ul>
              <li><a href="{HOME}#solutions">Solar Solutions</a></li>
              <li><a href="{HOME}#about">Why Choose Us</a></li>
              <li><a href="{PROCESS}">How It Works</a></li>
              <li><a class="open-calc-btn" href="#" role="button">Solar Calculator 🧮</a></li>
              <li><a href="{CONTACT}">Get a Quote</a></li>
            </ul>
          </nav>

          <nav class="sg-col" aria-label="Company and legal">
            <h4>Company &amp; Legal</h4>
            <ul>
              <li><a href="{P}about_us.html">About SunGET</a></li>
              <li><a href="{P}careers.html">Careers</a></li>
              <li><a href="{P}certifications.html">Certifications</a></li>
              <li><a href="{P}privacy-policy.html">Privacy Policy</a></li>
              <li><a href="{CONTACT}">Contact Support</a></li>
            </ul>
          </nav>

          <div class="sg-col sg-contact">
            <h4>Get in Touch</h4>
            <div class="sg-contact-card">
              <div class="sg-contact-item">
                <span class="sg-ico" aria-hidden="true">📍</span>
                <div>
                  <strong>Office</strong>
                  <a href="https://maps.app.goo.gl/QCPUaeTf7yaCP7Gq7" target="_blank" rel="noopener noreferrer">Renuka Industries Estate, Opp. Abhiruchi Parisar, Narhe, Pune - 411041</a>
                </div>
              </div>
              <div class="sg-contact-item">
                <span class="sg-ico" aria-hidden="true">🏢</span>
                <div>
                  <strong>Registered</strong>
                  <span>Keshavsut Rd, Sadashiv Peth, Pune - 411030</span>
                </div>
              </div>
              <div class="sg-contact-item">
                <span class="sg-ico" aria-hidden="true">📞</span>
                <div><a href="tel:+919881855770">(+91) 98818 55770</a></div>
              </div>
              <div class="sg-contact-item">
                <span class="sg-ico" aria-hidden="true">✉️</span>
                <div><a href="mailto:sales@sungetsolarinfra.com">sales@sungetsolarinfra.com</a></div>
              </div>
            </div>
          </div>
        </div>

        <div class="sg-bottom">
          <span>© 2026 SunGET Solar Infra Pvt. Ltd. All rights reserved.</span>
          <div class="sg-bottom-links">
            <a href="{P}privacy-policy.html">Privacy Policy</a>
          </div>
        </div>
      </div>
    </footer>"""

TOAST = '<div class="toast" id="toast" role="status" aria-live="polite">Thanks! Your enquiry has been received.</div>'


def build(src: pathlib.Path):
    rel = src.name if src.name == "index.html" else "pgs/" + src.name
    text = src.read_text(encoding="utf-8")
    is_index = rel == "index.html"
    R = "" if is_index else "../"
    P = "pgs/" if is_index else ""
    HOME = "" if is_index else "../index.html"
    has_contact = 'id="contact"' in text
    v = {
        "R": R, "P": P, "HOME": HOME, "SITE": SITE,
        "CONTACT": "#contact" if has_contact else HOME + "#contact",
        "PROCESS": "#process" if is_index else "../index.html#process",
        "CANON": SITE + "/" + ("" if is_index else rel),
    }
    t = re.search(r"<title>(.*?)</title>", text, re.S)
    d = re.search(r'<meta\s+name="description"\s+content="(.*?)"', text, re.S)
    v["TITLE"] = html.escape(html.unescape(t.group(1).strip()), quote=True) if t else "SunGET Solar Infra"
    v["DESC"] = html.escape(html.unescape(" ".join(d.group(1).split())), quote=True) if d else ""

    def fill(tpl):
        for k, val in v.items():
            tpl = tpl.replace("{" + k + "}", val)
        return tpl

    text = text.replace("<!--@HEAD-->", fill(HEAD))
    text = text.replace("<!--@NAV-->", fill(NAV))
    text = text.replace("<!--@FOOTER-->", fill(FOOTER))
    text = text.replace("<!--@TOAST-->", TOAST)
    text = text.replace("{R}", R).replace("{P}", P)
    left = re.findall(r"<!--@\w+-->", text)
    assert not left, (src.name, left)
    dest = OUT / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(text, encoding="utf-8")
    return rel


if __name__ == "__main__":
    for f in sorted(SRC.glob("*.html")):
        print("built", build(f))
